#!/usr/bin/env python3

#
#  Copyright (C) 2019-2020  XC Software (Shenzhen) Ltd.
#


#
# Usage demo;
#   python3 fastagent.py -c config.json -jh jaeger_host
#   config,
#   task

import argparse
# Global inclusion, sys library
# json is used for Parsing JSON, may not be disabled
import logging
import datetime
import json
import re
import sys
import time
import uuid
from logging.handlers import RotatingFileHandler

from common.VersionUtils import VersionComparer

from XcalGlobals import *
from common import CommonGlobals
from common.CommonGlobals import use_jaeger, jaeger_ready
from common.ConfigObject import ConfigObject
from components.XcalConnect import Connector
from common.XcalException import XcalException
from common.XcalLogger import XcalLogger
from components.XcalTasks import TaskRunner


class AgentArgumentParser(object):
    def __init__(self, logger: XcalLogger):
        self.logger = logger

    def parse_config(self):
        parser = argparse.ArgumentParser(description="fastAgent for client-side prescan operation")
        # All Arguments
        parser.add_argument("-config", type=argparse.FileType('r'),
                            help="specify location for config file")  # Specifying config file's path
        parser.add_argument("-task", required=False,
                            help="specify task to perform")  # Specifying the task to be done
        parser.add_argument("-jh", "-jaegerhost", required=False,
                            help="specify server to report to")  # Specifying the jaeger host
        parser.add_argument("-jp", "-jaegerport", required=False,
                            help="specify server to report to")  # Specifying the jaeger port
        parser.add_argument("-v", "--verbose", action="store_true",
                            help="increase output verbosity")
        args = parser.parse_args()

        self.logger.trace("Parsed Args ", args)
        return args


# An infinite Loop to poll tasks from server and create TaskRunner
class AgentTaskManager(object):
    def __init__(self, logger: XcalLogger, global_ctx):
        self.logger = logger
        self.global_ctx = global_ctx
        self.correct_displayed = False

    def process(self):
        while True:
            try:
                self.get_new_tasks()
            except json.JSONDecodeError as err:
                logging.exception(err)
            except KeyboardInterrupt as e:
                raise e
            except BaseException as err:
                logging.error("### AgentTaskManager Exception START ###")
                logging.exception(err)
                logging.error("### AgentTaskManager Exception END ###")

            # Sleep for several seconds and poll again...
            time.sleep(int(self.global_ctx.get("pollSpan")))

    def check_scan_service_version(self):
        """
        check whether this agent service is compatible with scan service
        :return: true or false
        """
        matched = False
        try:
            scan_service_version = Connector(self.logger, self.global_ctx.get("apiServer")).get_scan_service_version(self.global_ctx)
        except XcalException as err:
            self.logger.debug("check_scan_service_version", "failed, error message: %s" % str(err))
            logging.warning("check scan service version failed, please check whether xcal-server(scan service) is available")
            if self.global_ctx.get("skipServerVersionMismatch", "NO") == "NO":
                self.correct_displayed = False
            return matched
        else:   # get information from scan service version
            acceptable_versions = self.global_ctx.get("matchingScanServiceVersion")
            for one_version in acceptable_versions:
                # Matching in region / exact
                if VersionComparer.version_exact_or_range_compare(scan_service_version, one_version):
                    matched = True
                    break

        if not matched:
            logging.warning("scan and agent service version mismatch, please update XcalAgent or XcalScan, "
                            "or specify matchingScanServiceVersion in run.conf, acceptable ScanService version: %s" %
                            str(self.global_ctx.get("matchingScanServiceVersion")))
            if self.global_ctx.get("skipServerVersionMismatch", "NO") == "NO":
                raise KeyboardInterrupt()

        return matched

    def get_new_tasks(self):
        connector = Connector(self.logger, self.global_ctx.get("apiServer"))
        task_info = None
        try:
            matched = self.check_scan_service_version()
            if matched:
                task_info = connector.poll_task(self.global_ctx).json()
        except XcalException as err:
            self.logger.debug("get_new_tasks", "error message: %s" % str(err))
            time.sleep(self.global_ctx.get("reconnectSpan"))
            self.correct_displayed = False
            # poll task will call scan service. And scan service internally will call web service.
            # login success means web service is available, then here failed reason is scan service is not available
            # login failed means web service is not available
            # while if both web service and scan service is not available, show web service is not available here
            result = connector.login(self.global_ctx)
            if result is not None:
                logging.warning(
                    "server cannot be reached, please check whether xcal-server is available or network is reachable")
            elif 400 <= result.status_code < 500:
                logging.warning("login failed, please check whether your username password is correct")
                sys.exit(1)
            elif 500 <= result.status_code < 600:
                logging.warning("get new tasks failed, please check whether xcal-server(web service) is available")
            else:
                # login success here means get new tasks failed due to scan service is not available
                logging.warning("get new tasks failed, please check whether xcal-server(scan service) is available")
                self.global_ctx["agentToken"] = result.json().get("accessToken")
        else:
            if task_info is not None and task_info.get("status") == "ok":
                self.run_task(task_info)

    def run_task(self, task_info: dict):
        log = XcalLogger("AgentTaskManager", "run_task")
        if task_info.get("jobCount") is not None and task_info.get("jobCount") > 0:
            log.info("Received Task Info, processing ...", task_info)

            # Starting Jobs
            for one_job in task_info.get("jobs"):
                TaskRunner(log, self.global_ctx).async_entry(self.global_ctx, one_job)
        else:
            if not self.correct_displayed:
                log.trace("Connected to server, polling continuously ...", "")
                self.correct_displayed = True
        log.finish()


# Continuously Running Daemon for monitoring... etc.
class AgentEnvironmentChecker(object):
    def __init__(self, logger: XcalLogger, global_ctx: dict):
        self.logger = logger
        self.global_ctx = global_ctx

    def start(self):
        pass


class AgentDaemon(object):
    def __init__(self, logger: XcalLogger = None):
        if logger is None:
            logger = XcalLogger("AgentDaemon", "__init__")
        self.logger = logger
        self.global_ctx = None

    def entry(self):
        try:
            # Init tracer
            with XcalLogger("AgentDaemon", "entry", real_tracer=False) as log:
                self.logger = log
                args = AgentArgumentParser(log).parse_config()
                self.main_process(log, args)
        except KeyboardInterrupt:
            Connector(log, self.global_ctx.get("apiServer")).report_agent_status(self.global_ctx, "terminate")
            logging.warning('Exit request, Bye!')
            sys.exit(1)
        except SystemExit:
            logging.warning('Bye!')
            sys.exit(1)
        except BaseException as err:
            # need full exception information when error occurred
            # Do not raise error inside, otherwise infinite loop occurs
            logging.exception(err)

    def update_token(self):
        while True:
            result = Connector(self.logger, self.global_ctx.get("apiServer")).login(self.global_ctx)
            if result is None:
                logging.warning(
                    "server cannot be reached, please check whether xcal-server is available or network is reachable")
                sys.exit(1)
            elif 400 <= result.status_code < 500:
                logging.debug("update_token, login failed, error message: %s" % result.content)
                logging.warning(
                    "login failed, please check whether xcal-server is available or your username password is correct")
                sys.exit(1)
            elif 500 <= result.status_code < 600:
                logging.debug("update_token login failed, error message: %s" % result.content)
                logging.warning(
                    "login failed, please check whether xcal-server is available")
                time.sleep(5)
                continue
            else:
                self.global_ctx["agentToken"] = result.json().get("accessToken")
                break

    @staticmethod
    def url_is_valid(url: str):
        regex = re.compile(
            r'^(?:http)s?://'  # http:// or https://
            r'(?:(?:[A-Z0-9](?:[A-Z0-9-]{0,61}[A-Z0-9])?\.)+(?:[A-Z]{2,6}\.?|[A-Z0-9-]{2,}\.?)|'  # domain...
            r'localhost|'  # localhost...
            r'\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3})'  # ...or ip
            r'(?::\d+)?'  # optional port
            r'(?:/?|[/?]\S+)$', re.IGNORECASE)

        if re.match(regex, url) is None:
            return False
        else:
            return True

    def main_process(self, logger: XcalLogger, args):
        # Reset Jaeger ...
        logger.reset(args)
        # Initialize, maybe reroute the jaeger host
        self.global_ctx = self.global_init(args)

        if not AgentDaemon.url_is_valid(str(self.global_ctx.get("apiServer").get("url"))):
            logging.warning("invalid server url %s" % str(self.global_ctx.get("apiServer").get("url")))
            sys.exit(1)

        logging.log(XcalLogger.XCAL_TRACE_LEVEL, "Configured Server              .... %s" % (str(self.global_ctx.get("apiServer").get("url"))))
        logging.log(XcalLogger.XCAL_TRACE_LEVEL, "Configured Agent Name          .... %s" % (str(self.global_ctx.get("agentName"))))
        logging.log(XcalLogger.XCAL_TRACE_LEVEL, "Configured User Name           .... %s" % (str(self.global_ctx.get("userName"))))
        logging.log(XcalLogger.XCAL_TRACE_LEVEL, "Configured Agent Install Dir   .... %s" % (str(self.global_ctx.get("xcalAgentInstallDir"))))
        logging.log(XcalLogger.XCAL_TRACE_LEVEL, "Accepting ScanService Version  .... %s" % (str(self.global_ctx.get("matchingScanServiceVersion"))))
        logging.log(XcalLogger.XCAL_TRACE_LEVEL, "Supported Job Queue Name       .... %s" % (str(self.global_ctx.get("supportedJobQueueName"))))

        self.update_token()

        if args.task == "preprocess":
            logger.trace("Performing single-run preprocess, not impl. quitting...", ())
        elif args.task == "setup":
            logger.trace("Performing Setup Check", "...")
            AgentEnvironmentChecker(logger, self.global_ctx).start()
        else:
            logger.trace("Performing Task Manager Cycling", "")
            logger.trace("Starting to connect to server", "")
            AgentTaskManager(logger, self.global_ctx).process()

        logger.info("Everything Finished", ())

    def global_init(self, args):
        """
        The global init process which merges the user's configuration with default value.
        Set up the logging level in the CommonGlobals
        :param args: the argument parsed by the above AgentArgumentParser
        :return: the result global_ctx (Global Settings Context)
        """
        global_ctx = DEFAULT_CONFIG.copy()
        if args.config is not None:
            global_ctx = ConfigObject.merge_two_dicts(DEFAULT_CONFIG.copy(), json.load(args.config))
        self.global_ctx = global_ctx

        if args.verbose is True:
            CommonGlobals.log_level = logging.DEBUG
            logging.getLogger().setLevel(CommonGlobals.log_level)

        elif global_ctx.get("logLevel") is not None:
            conf_level = global_ctx.get("logLevel")
            if conf_level == "DEBUG":
                CommonGlobals.log_level = logging.DEBUG
            elif conf_level == "INFO":
                CommonGlobals.log_level = logging.INFO
            elif conf_level == "TRACE":
                CommonGlobals.log_level = XcalLogger.XCAL_TRACE_LEVEL
            elif conf_level == "WARN":
                CommonGlobals.log_level = logging.WARN
            elif conf_level == "ERROR":
                CommonGlobals.log_level = logging.ERROR
            else:
                CommonGlobals.log_level = logging.WARNING

            logging.getLogger().setLevel(CommonGlobals.log_level)
        self.global_ctx["xcalAgentInstallDir"] = os.path.dirname(os.path.dirname(__file__))
        self.global_ctx["agentId"] = str(uuid.uuid1())

        # If it wasn't routed, verify if it could be re-routed
        if not jaeger_ready and use_jaeger:
            if global_ctx is not None and 'jaegerHost' in global_ctx and global_ctx.get('jaegerHost') is not None:
                CommonGlobals.report_host = global_ctx["jaegerHost"]
            if global_ctx is not None and 'jaegerPort' in global_ctx and global_ctx.get('jaegerPort') is not None:
                CommonGlobals.report_port = global_ctx["jaegerPort"]
            if global_ctx is not None and ('jaegerHost' in global_ctx or 'jaegerPort' in global_ctx):
                XcalLogger("AgentDaemon", "global_init", real_tracer=True)

        return global_ctx


# All Processes
if __name__ == "__main__":
    start_time = datetime.datetime.now()
    work_dir = os.curdir
    logging.getLogger('').handlers = []
    logFormatter = '[%(asctime)20s] [%(levelname)10s] %(message)s'
    logging.basicConfig(format=logFormatter, level=CommonGlobals.log_level)
    logging.addLevelName(XcalLogger.XCAL_TRACE_LEVEL, "TRACE")

    rootLogger = logging.getLogger()
    fileHandler = RotatingFileHandler(os.path.join(work_dir, AGENT_LOG_FILE_NAME), maxBytes = 50000000, backupCount = 10)
    fileHandler.setFormatter(logging.Formatter(logFormatter))
    rootLogger.addHandler(fileHandler)

    logging.log(XcalLogger.XCAL_TRACE_LEVEL, "Checking XcalAgent Version     .... %s " % AGENT_VERSION)
    logging.log(XcalLogger.XCAL_TRACE_LEVEL, "Starting XcalAgent Daemon on   .... %s" % (str(start_time)))
    AgentDaemon().entry()
