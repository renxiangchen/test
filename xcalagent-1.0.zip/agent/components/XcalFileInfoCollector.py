#
#  Copyright (C) 2019-2020  XC Software (Shenzhen) Ltd.
#


import os
import json
import logging
import ntpath

import XcalGlobals
from common.HashUtility import HashUtility
from common.XcalException import XcalException
from common.FileUtility import FileUtility
from common.CommonGlobals import TaskErrorNo, GIT_METADATA_FILE_NAME
from common.XcalLogger import XcalLogger
import subprocess


def _file_lines(filename):
    """
    Get number of lines of the file
    :param filename: file path
    :return: the number of lines of the file. If file cannot find or cannot be read, return 0.
    """
    if not os.path.isfile(filename):
        logging.error("[_file_lines] %s not found" % filename)
        return 0

    if not os.access(filename, os.R_OK):
        logging.error("[_file_lines] %s cannot be read" % filename)
        return 0

    i = -1
    with open(filename, 'rb') as f:     # open file in binary mode to avoid the decode error
        for i, l in enumerate(f):
            pass
    return i + 1


def _getmtime_nano(filename):
    """Return the last modification time of a file in nanoseconds, reported by os.stat()."""
    return os.stat(filename).st_mtime_ns


def get_git_commit_id(project_path, log):
    # TODO: need to improve with gitpython library.
    utility = FileUtility(log)
    utility.goto_dir(project_path)
    commit_id = subprocess.check_output("git rev-parse HEAD", shell=True).strip().decode('utf-8')
    utility.goback_dir()
    return commit_id


def _get_source_code_zip_file_id(upload_results, step_config):
    """

    :param upload_results:
    :param step_config:
    :return: the file info id of the source code archive
    """
    for upload_result in upload_results:
        if step_config.get('sourceCodeArchiveName') == upload_result.get('filename') and \
                'fileId' in upload_result:
            return upload_result['fileId']
    else:
        raise XcalException("XcalFileInfoCollector", "_get_source_code_archive_file_id",
                            'no fileId exists in upload results', TaskErrorNo.E_FILE_INFO_NO_FILEID)


def _get_filename_depth_map(project_path):
    filename_depth_map = dict()
    base_depth = project_path.count(os.sep)
    # traverse the project path, include the symbolic links
    for root, dirs, filenames in os.walk(project_path, followlinks = True):
        depth = root.count(os.sep) - base_depth
        filename_depth_map[root] = depth
        for filename in filenames:
            filename_depth_map[os.path.join(root, filename)] = depth + 1

    return filename_depth_map


def _get_parent_path(relative_path: str, depth: int):
    """

    :param relative_path:
    :param depth:
    :return:
    """
    if depth == 0:
        return None
    elif depth == 1:
        return os.sep
    else:
        return os.path.dirname(relative_path)


def generate_directory_file_info(project_path, directory, filename_depth_map, file_num, version):
    """
    generate the file info of the directory
    :param project_path: the whole project path
    :param directory: the directory whose file info will be generated
    :param filename_depth_map: the directory name depth map
    :param file_num: file number
    :param version: git commit id or zero for directory type
    :return: a dict which contains the directory file info
    """
    depth = filename_depth_map.get(directory)
    if directory != project_path:
        relative_path = os.path.relpath(directory, project_path)
    else:
        relative_path = os.sep
    file = {'fileId': str(file_num),
            'fileName': os.path.basename(directory),
            'type': "DIRECTORY",
            'depth': str(depth),
            'parentPath': _get_parent_path(relative_path, depth),
            'filePath': directory,
            'relativePath': relative_path,
            'version': str(version),
            'checksum': str(0),
            'fileSize': str(0),
            'noOfLines': str(0)
            }
    return file


def generate_file_info_by_traverse_project_path(project_path, filename_depth_map, is_vcs_project, log):
    """

    :param project_path:
    :param filename_depth_map:
    :param is_vcs_project:
    :param log:
    :return:
    """
    version = 0
    if is_vcs_project:
        version = get_git_commit_id(project_path, log)

    number_of_files_without_permission = 0
    total_line_num = 0
    file_num = 0
    files = []

    # traverse the project path, include the symbolic links
    for root, dirs, filenames in os.walk(project_path, followlinks = True):
        # no need to collect the file info of .git
        if GIT_METADATA_FILE_NAME in dirs:
            dirs.remove(GIT_METADATA_FILE_NAME)

        file_num += 1
        dir_file_info = generate_directory_file_info(project_path, root, filename_depth_map, file_num, version)
        files.append(dir_file_info)

        for filename in filenames:
            file_num += 1
            file_path = os.path.join(root, filename)
            if not os.access(file_path, os.R_OK):
                number_of_files_without_permission += 1
            relative_path = os.path.relpath(file_path, project_path)

            if not is_vcs_project:
                version = _getmtime_nano(file_path)

            depth = filename_depth_map.get(os.path.join(root, filename))
            files.append({'fileId': str(file_num),
                          'fileName': filename,
                          'type': "FILE",
                          'depth': str(depth),
                          'parentPath': _get_parent_path(relative_path, depth),
                          'filePath': file_path,
                          'relativePath': relative_path,
                          'version': str(version),
                          'checksum': str(HashUtility.get_crc32_checksum(file_path)),
                          'fileSize': str(os.path.getsize(file_path)),
                          'noOfLines': str(_file_lines(file_path))
                          })
            total_line_num += _file_lines(file_path)

    return files, number_of_files_without_permission, total_line_num


def generate_file_info_by_analyse_file(project_path, filename_depth_map, file_name, is_vcs_project, log):
    """
    
    :param project_path:
    :param filename_depth_map:
    :param file_name: 
    :param is_vcs_project: 
    :param log: 
    :return: 
    """""
    version = 0
    if is_vcs_project:
        version = get_git_commit_id(project_path, log)

    number_of_files_without_permission = 0
    total_line_num = 0
    file_num = 0
    files = []

    # traverse the project path, include the symbolic links
    for root, dirs, filenames in os.walk(project_path, followlinks = True):
        # no need to collect the file info of .git
        if GIT_METADATA_FILE_NAME in dirs:
            dirs.remove(GIT_METADATA_FILE_NAME)

        file_num += 1
        dir_file_info = generate_directory_file_info(project_path, root, filename_depth_map, file_num, version)
        files.append(dir_file_info)

    with open(file_name) as json_file:
        source_code_files = json.load(json_file)
        if not isinstance(source_code_files, list) or len(source_code_files) == 0:
            raise XcalException("XcalFileInfoCollector", "generate_file_info_by_analyse_file",
                                "invalid content in file %s" % file_name,
                                TaskErrorNo.E_COMMON_INVALID_CONTENT)
        utility = FileUtility(log)
        utility.goto_dir(project_path)
        file_path_set = set()
        for source_code_file in source_code_files:
            # file path may contain .., normpath can make the path canonical
            source_code_file = os.path.normpath(source_code_file)
            if not os.path.exists(source_code_file):
                log.warn("generate_file_info_by_analyse_file", "source code file %s does not exist" % source_code_file)
                raise XcalException("XcalFileInfoCollector", "generate_file_info_by_analyse_file",
                                    "source code file %s does not exist" % source_code_file,
                                    TaskErrorNo.E_COMMON_FILE_NOT_EXIST)

            if source_code_file not in file_path_set:   # defensive, avoid add duplicate file info
                if source_code_file.startswith(project_path):
                    file_num += 1
                    file_path = source_code_file
                    if not os.access(file_path, os.R_OK):
                        number_of_files_without_permission += 1
                    relative_path = os.path.relpath(file_path, project_path)

                    if not is_vcs_project:
                        version = _getmtime_nano(file_path)

                    depth = filename_depth_map.get(source_code_file)
                    files.append({'fileId': str(file_num),
                                  'fileName': ntpath.basename(file_path),
                                  'type': "FILE",
                                  'depth': str(depth),
                                  'parentPath': _get_parent_path(relative_path, depth),
                                  'filePath': file_path,
                                  'relativePath': relative_path,
                                  'version': str(version),
                                  'checksum': str(HashUtility.get_crc32_checksum(file_path)),
                                  'fileSize': str(os.path.getsize(file_path)),
                                  'noOfLines': str(_file_lines(file_path))
                                  })
                    total_line_num += _file_lines(file_path)
                else:
                    log.warn("generate_file_info_by_analyse_file",
                             "source code file %s does not belong to %s" % (source_code_file, project_path))
                file_path_set.add(source_code_file)

        utility.goback_dir()

    return files, number_of_files_without_permission, total_line_num


def generate_file_info(project_path, job_config, step_config, log: XcalLogger = None):
    """
    generate the files information of the project
    :param log:
    :param step_config: Current Step's Information, as defined by AgentInvoker in ScanService
    :param job_config: Current Job's Info
    :param project_path: where the source code root path
    :return: file_info dictionary content
    """
    log.debug("generate_file_info", "project_path: %s" % project_path)

    project_path = os.path.normpath(project_path)   # get the canonical project path. will change \\ to \ on windows
    if not os.path.isdir(project_path) or not os.path.exists(project_path):
        raise XcalException("XcalFileInfoCollector", "generate_file_info", "project_path not exists",
                            TaskErrorNo.E_FILE_INFO_PJ_NULL)

    input_filename = step_config.get("inputFileName")  # information of the source code files which are preprocessed

    is_vcs_project = False
    if step_config.get("sourceStorageType").lower() == "gitlab" or step_config.get(
            "sourceStorageType").lower() == "github":
        is_vcs_project = True

    filename_depth_map = _get_filename_depth_map(project_path)
    file_info = {}
    if input_filename is None or not os.path.exists(input_filename):
        # if source_files.json not exists, collect all the file information in project_path.
        files, number_of_files_without_permission, total_line_num = generate_file_info_by_traverse_project_path(project_path, filename_depth_map, is_vcs_project, log)
    else:
        files, number_of_files_without_permission, total_line_num = generate_file_info_by_analyse_file(project_path, filename_depth_map, input_filename, is_vcs_project, log)

    if step_config.get("sourceStorageName") == "agent" and step_config.get("uploadSource"):
        file_info['sourceType'] = "volume_upload"
        if 'uploadResults' not in job_config:
            raise XcalException("XcalFileInfoCollector", "generate_file_info", 'no uploadResults exists in job_config',
                                TaskErrorNo.E_FILE_INFO_NO_UPLOADRESULTS)
        upload_results = job_config['uploadResults']
        source_code_zip_file_id = _get_source_code_zip_file_id(upload_results, step_config)
        file_info['sourceCodeFileId'] = source_code_zip_file_id
    else:
        file_info['sourceType'] = step_config.get("sourceStorageName")
        file_info['sourceCodeFileId'] = step_config.get('sourceCodeFileId')

    dirs = [file_item for file_item in files if file_item.get("type") == "DIRECTORY"]

    file_info['files'] = files
    file_info['gitlabProjectId'] = step_config.get("gitlabProjectId")
    file_info['gitUrl'] = step_config.get('gitUrl')
    file_info['osType'] = XcalGlobals.os_info
    file_info['numberOfFiles'] = str(len(files) - len(dirs))
    file_info['numberOfDirs'] = str(len(dirs))
    file_info['totalLineNum'] = str(total_line_num)
    file_info['numberOfFilesWithoutPermission'] = str(number_of_files_without_permission)
    return file_info


def generate_file(project_path, job_config, step_config, destination_path=None, filename=None,
                  log: XcalLogger = None):
    """
    generate the file which contains the file information of the project
    :param log:
    :param project_path: project path
    :param job_config:  Job's configuration, containing all steps, defined in AgentInvoker
    :param step_config: Step's configuration, singled step defined in the task's configuration
    :param destination_path: where to save the file
    :param filename: filename of the generated file
    :return: generated file path
    """
    utility = FileUtility(log)
    if destination_path is not None:
        os.makedirs(destination_path, exist_ok=True)
        utility.goto_dir(destination_path)
    else:
        destination_path = os.getcwd()
        utility.goto_dir(destination_path)

    if project_path is None:
        raise XcalException("XcalFileInfoCollector", "generate_file", "project_path is None",
                            TaskErrorNo.E_FILE_INFO_PJ_NULL)

    if filename is None:
        filename = 'fileInfo.json'

    try:
        project_file_info = generate_file_info(project_path, job_config, step_config, log)
    except BaseException as err:
        logging.exception(err)
        raise XcalException("XcalFileInfoCollector", "generate_file", "get_file_info failed",
                            TaskErrorNo.E_FILE_INFO_GATHER_FAIL)

    if os.path.exists(filename):
        os.remove(filename)

    with open(filename, 'w') as outfile:
        json.dump(project_file_info, outfile, indent=1)

    utility.goback_dir()

    return os.path.join(destination_path, filename)
