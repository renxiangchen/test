import time

import pygit2
from common.CommonGlobals import Stage, Status, TaskErrorNo, Percentage
from common.XcalLogger import XcalLogger
from components.XcalConnect import Connector


class GitProgressCallbacks(pygit2.RemoteCallbacks):

    def __init__(self, credentials=None, certificate=None, index_percent: int = 0, logger: XcalLogger = None,
                 global_ctx: dict = None, job_config: dict = None, interval: int = 5):
        pygit2.RemoteCallbacks.__init__(credentials, certificate)
        self.index_percent = index_percent
        self.logger = logger
        self.global_ctx = global_ctx
        self.job_config = job_config
        self.interval = interval    # interval time(seconds) to report the progress to web service
        self.last_time = time.monotonic()
        self.report_obj = Connector(logger, global_ctx.get("apiServer"))

    def transfer_progress(self, stats):
        index_percent = stats.indexed_objects / stats.total_objects
        format_index_percent = int(100 * index_percent)
        operation_name = "clone progress: "
        message = "{:.0%} ({}/{})".format(index_percent, stats.indexed_objects, stats.total_objects)
        # when index_percent is changed, print the clone progress info(useful for small projects)
        if self.index_percent != format_index_percent:
            self.index_percent = format_index_percent
            self.logger.trace(operation_name, message)

        # every interval seconds print and report clone progress info(useful for big projects and poor network)
        current_time = time.monotonic()
        if current_time > self.last_time + self.interval:
            self.last_time = current_time
            self.report_obj.report_status(self.global_ctx, self.job_config, Stage.FETCH_SOURCE, Status.PROCESSING,
                                          TaskErrorNo.SUCCESS, Percentage.MIDDLE,
                                          message = operation_name + message)
            self.logger.trace(operation_name, message)


