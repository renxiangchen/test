#
#  Copyright (C) 2019-2020  XC Software (Shenzhen) Ltd.
#

import unittest

from components.XcalFileInfoCollector import generate_file_info


class Test(unittest.TestCase):
    def setUp(self):
        self.scan_task_id = "1234"
        self.project_path_not_exist = "/xxx/xxx/xx"

    def test_get_file_info_ok(self):
        #TODO: need to implement
        pass

    def test_get_file_info_where_project_path_not_exist(self):
        file_info = generate_file_info(self.scan_task_id, self.project_path_not_exist, {}, {})
        self.assertEqual(file_info, None)

    def test_generate_file(self):
        # TODO: need to implement
        pass