#
#  Copyright (C) 2019-2020  XC Software (Shenzhen) Ltd.
#


import os
import platform
import sys
import glob

from common.XcalLogger import XcalLogger
from common.CommandLineUtility import CommandLineUtility
from common.XcalException import *
from common.CommonGlobals import TaskErrorNo
from util.XcalPluginInstaller import PluginInstaller

CHECK_COMMAND_TIMEOUT = 30.0
LOG_FILE = "agent_install.log"

INFO = "[INFO]:"
WARN = "[WARNING]:"
ERROR = "[ERROR]:"


class XcalAgentModuleSetupper(object):
    def __init__(self, agent_type):
        self.logger = XcalLogger("XcalAgentModuleSetupper", "__init__")
        self.current_os = platform.platform()
        self.current_py = sys.executable
        self.agent_type = agent_type

    def module_setup(self):
        agent_dir = os.getcwd()

        if ("Windows").casefold() in self.current_os.casefold():
            return
        else:
            xcalbuild_dir = os.path.join(agent_dir, "xcalbuild")
            if not (os.path.exists(xcalbuild_dir) and os.path.isdir(xcalbuild_dir)):
                raise XcalException("XcalAgentModuleSetupper", "module_setup",
                                    "Missing xcalbuild folder, please check consistency.",
                                    TaskErrorNo.E_COMPONENT_MISSING)
            else:
                bear_installed = os.path.join(agent_dir, "BEAR_INSTALLED")
                if os.path.exists(bear_installed):
                    pass
                else:
                    if os.getuid() != 0:
                        cmd_prefix = "sudo "  # grand sudo privilege
                    else:
                        cmd_prefix = ""

                    print(INFO, "Installing bear...")
                    bear_dir = os.path.join(os.path.join(xcalbuild_dir, "linux"), "bear")
                    os.chdir(bear_dir)
                    bear_build_dir = os.path.join(bear_dir, "build")
                    if not (os.path.exists(bear_build_dir) and os.path.isdir(bear_build_dir)):
                        os.mkdir(bear_build_dir)
                    os.chdir(bear_build_dir)
                    res = CommandLineUtility.bash_execute("cmake ..", timeout=CHECK_COMMAND_TIMEOUT,
                                                          logger=self.logger, logfile=LOG_FILE)
                    if res != 0:
                        raise XcalException("XcalAgentModuleSetupper", "module_setup",
                                            "cmake .. failed",
                                            TaskErrorNo.E_BEAR_INSTALLATION_FAILED)
                        
                    res = CommandLineUtility.bash_execute("make", timeout=CHECK_COMMAND_TIMEOUT,
                                                          logger=self.logger, logfile=LOG_FILE)
                    if res != 0:
                        raise XcalException("XcalAgentModuleSetupper", "module_setup",
                                            "make failed",
                                            TaskErrorNo.E_BEAR_INSTALLATION_FAILED)
                    res = CommandLineUtility.bash_execute("%s make install" % (cmd_prefix),
                                                          timeout=CHECK_COMMAND_TIMEOUT,
                                                          logger=self.logger, logfile=LOG_FILE)
                    if res != 0:
                        raise XcalException("XcalAgentModuleSetupper", "module_setup",
                                            "%s make install failed" % (cmd_prefix),
                                            TaskErrorNo.E_BEAR_INSTALLATION_FAILED)

                    with open(bear_installed, 'a'):  # Equivalent to touch BEAR_INSTALLED
                        os.utime(bear_installed, None)

                    os.chdir(agent_dir)
                    print(INFO, "XcalBuild installation finished.")

                    if self.agent_type == 'c':
                        return

                ## Java
                ## Check JAVA_HOME:
                java_home = os.getenv("JAVA_HOME")
                if java_home is None or java_home == "":
                    raise XcalException("XcalAgentModuleSetupper", "module_setup",
                                        "Environment variable JAVA_HOME is not set properly.",
                                        TaskErrorNo.E_JAVA_HOME_NOT_FOUND)
                feutil_dir = os.path.join(agent_dir, "feutil")
                if not (os.path.exists(feutil_dir) and os.path.isdir(feutil_dir)):
                    raise XcalException("XcalAgentModuleSetupper", "module_setup",
                                        "Missing feutil folder, please check consistency.",
                                        TaskErrorNo.E_COMPONENT_MISSING)
                plugin_dir = os.path.join(agent_dir, "plugin")
                if not (os.path.exists(plugin_dir) and os.path.isdir(plugin_dir)):
                    raise XcalException("XcalAgentModuleSetupper", "module_setup",
                                        "Missing plugin folder, please check consistency.",
                                        TaskErrorNo.E_COMPONENT_MISSING)
                maven_plugin_dir = os.path.join(plugin_dir, "maven-plugin")
                if not (os.path.exists(maven_plugin_dir) and os.path.isdir(maven_plugin_dir)):
                    raise XcalException("XcalAgentModuleSetupper", "module_setup",
                                        "Missing maven-plugin folder, please check consistency.",
                                        TaskErrorNo.E_COMPONENT_MISSING)
                gradle_plugin_dir = os.path.join(plugin_dir, "gradle-plugin")
                if not (os.path.exists(gradle_plugin_dir) and os.path.isdir(gradle_plugin_dir)):
                    raise XcalException("XcalAgentModuleSetupper", "module_setup",
                                        "Missing gradle-plugin folder, please check consistency.",
                                        TaskErrorNo.E_COMPONENT_MISSING)

                maven_pom = glob.glob(os.path.join(maven_plugin_dir, "*.xml"))
                maven_plugin = glob.glob(os.path.join(maven_plugin_dir, "*.jar"))
                gradle_pom = glob.glob(os.path.join(gradle_plugin_dir, "*.xml"))
                gradle_plugin = glob.glob(os.path.join(gradle_plugin_dir, "*.jar"))

                # Since there will be only one pom file and one jar in the result of glob above.
                if not (os.path.exists(maven_pom[0]) and os.path.exists(maven_plugin[0]) and
                        os.path.exists(gradle_pom[0]) and os.path.exists(gradle_plugin[0])):
                    raise XcalException("XcalAgentModuleSetupper", "module_setup",
                                        "Missing plugin file, please check consistency.",
                                        TaskErrorNo.E_COMPONENT_MISSING)

                PluginInstaller(maven_pom[0], gradle_pom[0], maven_plugin[0],
                                gradle_plugin[0]).plugin_installation_wrapper()
                os.chdir(agent_dir)

