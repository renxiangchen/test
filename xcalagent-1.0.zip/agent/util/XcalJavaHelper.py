#
#  Copyright (C) 2019-2020  XC Software (Shenzhen) Ltd.
#

from common.XcalLogger import XcalLogger


class JfeHelper(object):
    def __init__(self, logger: XcalLogger):
        self.logger = logger

    def is_jfe_on_server(self, global_ctx:dict, job_config:dict):
        if (global_ctx.get("jfeOnServer", "NO") == "YES"):
            return True
        else:
            task_config = job_config.get("taskConfig", {})
            user_config = task_config.get("configContent", {})
            nojfe = user_config.get("jfeOnServer", "NO")
        return nojfe == "YES"
