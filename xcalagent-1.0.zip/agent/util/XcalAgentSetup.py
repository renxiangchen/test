#
#  Copyright (C) 2019-2020  XC Software (Shenzhen) Ltd.
#


import os
import sys
import platform
import shutil

from util.DependencyCheck import DependencyChecker
from util.XcalAgentModuleSetupper import XcalAgentModuleSetupper
from common.XcalLogger import XcalLogger
from common.CommandLineUtility import CommandLineUtility
from common.XcalException import *
from common.CommonGlobals import TaskErrorNo

INFO = "[INFO]:"
WARN = "[WARNING]:"
ERR = "[ERROR]:"
SUCCESS = "[SUCCESS]:"


class XcalAgentSetup(object):
    def __init__(self, agent_type):
        self.current_os = platform.platform()
        self.current_py = sys.executable
        self.agent_type = agent_type
        print(INFO, "[CurrentOS]: %s, [PythonInterpreter]: %s" % (self.current_os, self.current_py))

    def dependency_check(self):
        DependencyChecker(self.agent_type).dependency_check_wrapper()

    def setting_up(self):
        XcalAgentModuleSetupper(self.agent_type).module_setup()

    def create_workdir(self):
        agent_dir = os.getcwd()
        workdir = os.path.join(agent_dir, "workdir")
        run_conf = os.path.join(workdir, "run.conf")

        conf_example = os.path.join(os.path.join(agent_dir, "conf-example"), "test_global.conf")
        if not (os.path.exists(workdir) and os.path.isdir(workdir)):
            print(INFO, "Making workdir.")
            os.mkdir(workdir)
            print(INFO, "Copying run.conf.")
            shutil.copyfile(conf_example, run_conf)
        else:
            if not os.path.exists(run_conf):
                print(INFO, "Copying run.conf.")
                shutil.copyfile(conf_example, run_conf)
            else:
                print(INFO, "Skip workdir making.")

        print(SUCCESS, "Please configure your run.conf before launching xcalagent")


if __name__ == "__main__":
    assert len(sys.argv) > 1
    assert (sys.argv[1] == "c" or sys.argv[1] == "java" or sys.argv[1] == "combined")

    try:
        agent_type = sys.argv[1]
        agent_setup = XcalAgentSetup(agent_type)
        agent_setup.dependency_check()
        agent_setup.setting_up()
        agent_setup.create_workdir()
    except KeyboardInterrupt as e:
        print(WARN + "Installation canceled.")
