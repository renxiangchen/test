#
#  Copyright (C) 2019-2020  XC Software (Shenzhen) Ltd.
#

import platform
import os
import sys

from enum import Enum

from common.XcalLogger import XcalLogger
from common.CommandLineUtility import CommandLineUtility
from common.XcalException import *
from common.CommonGlobals import TaskErrorNo

# Required libs

REQUIRED_SYS_LIBS = {
    "c": ["pip3", "make", "cmake"],
    "java": ["java", "mvn"],
    "combined": ["pip3", "make", "cmake", "java", "mvn"],
}
REQUIRED_PY_LIBS = {
    "c": ["requests", "pygit2"],
    "java": ["requests", "lxml", "pygit2"],
    "combined": ["requests", "lxml", "pygit2"],
}

WINDOWS_PY_LIBS = ["requests", "pygit2"]

REQUIRED_MEMORY_BYTE = {
    "c": 1073741824,  # 1 Gigabyte
    "java": 4294967296,  # 4 Gigabyte
    "combined": 1073741824,  # 1 Gigabyte
}

AGENT_CHECK_TYPE = ["java", "c", "combined"]
PLATFORM = platform.platform()
USED_PIP = "pip3"
CHECK_COMMAND_TIMEOUT = 4.0
LOG_FILE = "agent_install.log"

INFO = "[INFO]: "
WARN = "[WARNING]: "
ERROR = "[ERROR]: "


class LibType(Enum):
    SYS_LIB = "sys_lib"
    PY_LIB = "py_lib"


class HintGiver(object):
    def __init__(self, lib: str = not None, lib_type: LibType = not None):
        self.lib = lib
        self.lib_type = lib_type

    def hint(self):
        if self.lib_type == LibType.SYS_LIB:
            hinter = ""
            if ("Darwin").casefold() in PLATFORM.casefold():  # Mac
                hinter = "sudo brew install " + self.lib
            elif ("Ubuntu").casefold() in PLATFORM.casefold() or (
                    "Debian").casefold() in PLATFORM.casefold():  # Ubuntu Debian
                hinter = "sudo apt install " + self.lib
            elif ("CentOS").casefold() in PLATFORM.casefold() or (
                    "Fedora").casefold() in PLATFORM.casefold():  # CentOS Fedora
                hinter = "sudo yum install " + self.lib

            return hinter

        elif self.lib_type == LibType.PY_LIB:
            hinter = USED_PIP + " install " + self.lib
            return hinter


class DependencyChecker(object):
    def __init__(self, agent_type: str = not None):
        self.logger = XcalLogger("Dependency Checker", "__init__")
        self.agent_type = agent_type

    def sys_lib_checker(self, sys_lib):
        print(INFO + "Detecting if " + sys_lib + " installed...")
        res = CommandLineUtility.bash_execute("which " + sys_lib, timeout=CHECK_COMMAND_TIMEOUT, logfile=LOG_FILE,
                                              # TODO: Remove which function
                                              logger=self.logger)
        if res != 0:
            print(ERROR + "Detecting if " + sys_lib + " installed...failed")
            raise XcalException("Dependency Checker", "Check " + sys_lib, sys_lib + " not installed",
                                TaskErrorNo.E_SYS_DEPENDENCY_NOT_EXIST, HintGiver(sys_lib, LibType.SYS_LIB).hint())
        else:
            print(INFO + "Detecting if " + sys_lib + " installed...ok")

    def py_lib_checker(self, py_lib):
        converted_py_lib = str.replace(py_lib, "-", "_")
        if py_lib == 'gitpython':
            converted_py_lib = 'git'
            
        print(INFO + "Detecting if " + py_lib + " installed...")
        res = CommandLineUtility.bash_execute("\"%s\" -c \"import %s\"" % (sys.executable, converted_py_lib),
                                              timeout=CHECK_COMMAND_TIMEOUT,
                                              logfile=LOG_FILE, logger=self.logger)
        if res != 0:
            print(ERROR + "Detecting if " + py_lib + " installed...failed")
            raise XcalException("Dependency Checker", "Check " + py_lib, py_lib + " not installed",
                                TaskErrorNo.E_PY_DEPENDENCY_NOT_EXIST, HintGiver(py_lib, LibType.PY_LIB).hint())
        else:
            print(INFO + "Detecting if " + py_lib + " installed...ok")

    def memory_check(self): # Optional
        print(INFO + "Checking if available memory sufficient...")
        try:
            psutil = __import__("psutil")
            mem = psutil.virtual_memory()
            avail_mem = mem.available
            if avail_mem < REQUIRED_MEMORY_BYTE[self.agent_type]:
                raise XcalException("Dependency Checker", "Memory requirement check",
                                    "Available memory: %dB, require %dB"
                                    % (avail_mem, REQUIRED_MEMORY_BYTE[self.agent_type]),
                                    TaskErrorNo.E_NO_SUFFICIENT_MEMORY)
            print(INFO + "Checking if available memory sufficient...ok")
        except ImportError as err:
            print(WARN + "python lib psutil not found. Could not check if memory available.")
            print(INFO + "Minimum memory request is %dB" % (REQUIRED_MEMORY_BYTE[self.agent_type]))
            return

    def dependency_check_wrapper(self):
        try:
            print(INFO + "Start Checking Xcal Agent Dependencies...")

            if self.agent_type not in AGENT_CHECK_TYPE:
                raise XcalException("Dependency Checker", "dependency_check", "agent check type not support",
                                    TaskErrorNo.E_AGENT_CHECK_TYPE_NOT_SUPPORT)

            # print(INFO + "Current operating system: " + PLATFORM)
            print(INFO + "Current checking agent type: " + self.agent_type)

            # Check sys libs
            if ("Windows").casefold() in PLATFORM.casefold():
                pass
            else:
                if len(REQUIRED_SYS_LIBS[self.agent_type]) != 0:
                    for sys_lib in REQUIRED_SYS_LIBS[self.agent_type]:
                        self.sys_lib_checker(sys_lib)

            # Check py libs
            if ("Windows").casefold() in PLATFORM.casefold():
                if len(WINDOWS_PY_LIBS) != 0:
                    for py_lib in WINDOWS_PY_LIBS:
                        self.py_lib_checker(py_lib)
            else:
                if len(REQUIRED_PY_LIBS[self.agent_type]) != 0:
                    for py_lib in REQUIRED_PY_LIBS[self.agent_type]:
                        self.py_lib_checker(py_lib)

            print(INFO + "Start Checking Xcal Agent Dependencies...ok")

            self.memory_check()
        except XcalException as e:
            exception_printer = XcalExceptionPrinter(e)
            exception_printer.print_error()
            print(INFO + "Start Checking Xcal Agent Dependencies...failed")
            exit(1)
