#
#  Copyright (C) 2019-2020  XC Software (Shenzhen) Ltd.
#


import xml.etree.ElementTree as ET
import os
import sys

from common.CommandLineUtility import CommandLineUtility
from common.XcalException import *
from common.CommonGlobals import TaskErrorNo
from common.XcalLogger import XcalLogger

INFO = "[INFO]: "
WARN = "[WARNING]: "
ERROR = "[ERROR]: "

INSTALL_PLUGIN_TYPE = ["maven", "gradle"]

COMMAND_TIMEOUT = 600.0
LOG_FILE = "agent_install.log"


# TODO: Generalize

class PluginInstaller(object):
    def __init__(self, maven_pom_loc, gradle_pom_loc, maven_plugin_jar, gradle_plugin_jar):
        self.maven_pom_loc = maven_pom_loc
        self.gradle_pom_loc = gradle_pom_loc
        self.maven_plugin_jar = maven_plugin_jar
        self.gradle_plugin_jar = gradle_plugin_jar
        self.logger = XcalLogger("XcalPluginInstaller", "__init__")

    def check_plugin_installation_status(self, plugin_type, ret: int):
        if ret != 0:
            print(INFO + "Installing %s plugin, groupId: %s, artifactId: %s, version: %s...failed" % (
                plugin_type, groupId, artifactId, version))
            raise XcalException("XcalPluginInstaller", "install_plugin",
                                "%s plugin installation failed" % (plugin_type),
                                TaskErrorNo.E_PLUGIN_INSTALLATION_FAILED)
        else:
            print(INFO + "Installing %s plugin, groupId: %s, artifactId: %s, version: %s...ok" % (
                plugin_type, groupId, artifactId, version))

    def install_plugin(self, plugin_type):
        if plugin_type == "maven":
            root = ET.parse(self.maven_pom_loc).getroot()
        elif plugin_type == "gradle":
            root = ET.parse(self.gradle_pom_loc).getroot()
        else:
            raise XcalException("XcalPluginInstaller", "install_plugin", "Plugin type not support",
                                TaskErrorNo.E_PLUGIN_TYPE_NOT_SUPPORT)

        namespace = root.tag.replace("project", "")

        global groupId, artifactId, version
        groupId = root.find(namespace + "groupId").text
        artifactId = root.find(namespace + "artifactId").text
        version = root.find(namespace + "version").text

        print(INFO + "Installing %s plugin, groupId: %s, artifactId: %s, version: %s..." % (
            plugin_type, groupId, artifactId, version))

        if plugin_type == "maven":
            ret = CommandLineUtility.bash_execute(
                "mvn install:install-file -DgroupId=%s -DartifactId=%s -Dversion=%s -Dfile=%s -Dpackaging=jar -DpomFile=%s" %
                (groupId, artifactId, version, self.maven_plugin_jar, self.maven_pom_loc), timeout=COMMAND_TIMEOUT,
                logfile=LOG_FILE, logger=self.logger)

            self.check_plugin_installation_status(plugin_type, ret)

        elif plugin_type == "gradle":
            ret = CommandLineUtility.bash_execute(
                "mvn install:install-file -DgroupId=%s -DartifactId=%s -Dversion=%s -Dfile=%s -Dpackaging=jar -DgeneratePom=true" %
                (groupId, artifactId, version, self.gradle_plugin_jar), timeout=COMMAND_TIMEOUT,
                logfile=LOG_FILE, logger=self.logger)

            self.check_plugin_installation_status(plugin_type, ret)

        else:
            raise XcalException("XcalPluginInstaller", "install_plugin", "Plugin type not support",
                                TaskErrorNo.E_PLUGIN_TYPE_NOT_SUPPORT)

    def plugin_installation_wrapper(self):
        try:
            print(INFO + "Installing Xcal-Java-Plugins...")
            for plugin_type in INSTALL_PLUGIN_TYPE:
                self.install_plugin(plugin_type)
            print(INFO + "Installing Xcal-Java-Plugins...ok")

        except XcalException as e:
            exception_printer = XcalExceptionPrinter(e)
            exception_printer.print_error()
            print(INFO + "Installing Xcal-Java-Plugins...failed")
            exit(1)
