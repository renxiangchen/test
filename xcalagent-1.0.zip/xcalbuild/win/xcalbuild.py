#
#  Copyright (C) 2019-2020  XC Software (Shenzhen) Ltd.
#

#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# 蟆法!

from os.path import dirname, join, normpath, abspath, basename
from shutil import copyfile
import time
import os
import re
import sys
import json
import logging
import tarfile
import hashlib
import chardet
import argparse
import platform
import xml.dom.minidom

version = '0.1.1'

xcalLauncher = '\"' + join(dirname(sys.argv[0]), 'XcalLauncher.exe') + '\"'
xcalLauncher64 = '\"' + join(dirname(sys.argv[0]), 'XcalLauncher64.exe') + '\"'
is_VS = False
is_IAR = False
is_SILI = False
prevs = "\"C:\\Program Files (x86)\\Microsoft Visual Studio 14.0\\Common7\\Tools\\VsDevCmd.bat\" && "
iar_stdarg = " -Dva_list=__builtin_va_list -Dva_start=__builtin_va_start \
                -Dva_end=__builtin_va_end -Dva_arg=__builtin_va_arg \
                -Dva_copy=__builtin_va_copy "
sili_script = '\"' + join(dirname(sys.argv[0]), \
                'AN1121SW\\an1121_headless_builds\\PythonScripts\\BuildExistingProject_v2.py') + '\"'

preprocess = 'preprocess'
property_key = ["version",
                "project",
                "vcs_tool",
                "vcs_url",
                "vcs_token",
                "vcs_branch",
                "vcs_version",
                "src_root_dir",
                "build_root_dir",
                "configure_command",
                "build_command",
                "c_compiler",
                "c_extra_flags",
                "cxx_compiler",
                "cxx_extra_flags",
                "assembler",
                "as_extra_flags",
                "archiver",
                "ar_extra_flags",
                "linker",
                "ld_extra_flags",
                "compile_only",
                "dependencies",
                "c_scan_options",
                "cxx_scan_options"]

PATTERNS_C = (
    re.compile(r'^.*([^-]*-)*[mg]cc(-?\d+(\.\d+){0,2})?$'),
    re.compile(r'^.*([^-]*-)*clang(-\d+(\.\d+){0,2})?$'), 
    re.compile(r'^.*(|i)cc.*$'),
    re.compile(r'^.*(g|)xlc$'),
    re.compile(r'^.*(CC).*$'),
    re.compile(r'^(CL.exe)$'),
    re.compile(r'^(ArmClang).*$'),
)

PATTERNS_CXX = (
    re.compile(r'^.*(c\+\+|cxx)$'),
    re.compile(r'^.*([^-]*-)*[mg]\+\+(-?\d+(\.\d+){0,2})?$'),
    re.compile(r'^.*([^-]*-)*clang\+\+(-\d+(\.\d+){0,2})?$'),
    re.compile(r'^.*icpc$'),
    re.compile(r'^.*(g|)xl(C|c\+\+)$'),
)

PATTERNS_AS = (
    re.compile(r'^.*(asm|Asm).*$'),
    re.compile(r'^.*(as)$'),
)

PATTERNS_AR = (
    re.compile(r'^.*(Lib.exe|ArmAr|iarchive.exe|ArInp.bat).*$'),
)

PATTERNS_LD = (
    re.compile(r'^.*(link|Link).*$'),
    re.compile(r'^.*ld.exe$'),
)

def mkdir(path):
    if not os.path.exists(path):
        os.makedirs(path)

def get_compiler_type(compiler):
    if any(pattern.match(compiler) for pattern in PATTERNS_C):
        return 'c'
    elif any(pattern.match(compiler) for pattern in PATTERNS_CXX):
        return 'cxx'
    elif any(pattern.match(compiler) for pattern in PATTERNS_AR):
        return 'ar'
    elif any(pattern.match(compiler) for pattern in PATTERNS_AS):
        return 'as'
    elif any(pattern.match(compiler) for pattern in PATTERNS_LD):
        return 'ld'
    else:
        return 'unknown'

parser = argparse.ArgumentParser(description="")
parser.add_argument("-i",
                    "--source",
                    help="directory of source code",
                    type=str)
parser.add_argument("-c",
                    "--IDEcpr",
                    help="directory IDE compiler",
                    type=str)
parser.add_argument("--cdb",
                    help="directory of the cdb",
                    type=str)
parser.add_argument("-o",
                    "--output",
                    help="directory of the output",
                    type=str,
                    default=".")
parser.add_argument("-v", "--version", action="store_true")
parser.add_argument("--debug", action="store_true")

if parser.parse_args().version:
    print('version: ' + version)
    exit(0)

if not parser.parse_args().source:
    parser.error(message='missing directory of source code')
if not parser.parse_args().output:
    parser.error(message='missing directory of output')
if not parser.parse_args().IDEcpr:
    parser.error(message='missing directory IDE compiler')
elif basename(parser.parse_args().IDEcpr).lower() == 'msbuild.exe':
    is_VS = True
elif basename(parser.parse_args().IDEcpr).lower() == 'iarbuild.exe':
    is_IAR = True
elif basename(parser.parse_args().IDEcpr).lower() == 'runscript.bat':
    is_SILI = True

mkdir(parser.parse_args().output)
logging.basicConfig(level=10,
                    filename=join(parser.parse_args().output, 'xcalbuild.log'),
                    filemode='w',
                    format='%(asctime)s - %(pathname)s[line:%(lineno)d] - %(levelname)s: %(message)s')

logging.info('raw command: %s', sys.argv)
os.chdir(parser.parse_args().output)
sourcedir = parser.parse_args().source
if sourcedir[-1] == '\\':
    sourcedir = sourcedir[:-1]
IDEcpr = parser.parse_args().IDEcpr
output = os.path.abspath(join(parser.parse_args().output, preprocess))
for i in os.listdir('.'):
    if re.match(r'^compilation-database\..*\.json$', i) and not parser.parse_args().cdb:
        os.remove(i)
    elif re.match(r'^xcl\..*\.dir$', i):
        os.system('rd /s/q ' + i)

if '32' in platform.architecture()[0]:
    if is_VS:
        build_command = xcalLauncher + " \"" + IDEcpr + '\" \"' + sourcedir + \
                        '\" /t:Clean,Build /p:Configuration=Release /p:Platform=x86'
    elif is_IAR:
        build_command = xcalLauncher + " \"" + IDEcpr + '\" \"' + sourcedir + '\" -build \"' \
                        + xml.dom.minidom.parse(sourcedir).documentElement.getElementsByTagName('name')[0].firstChild.data + '\"'
    elif is_SILI:
        build_command = xcalLauncher + " \"" + IDEcpr + '\" ' + \
                         ' -data \"' + os.path.split(sourcedir)[0] + '\" ' + sili_script + \
                         ' \"' + os.path.split(sourcedir)[1] + '\" -cfg \"GNU ARM v7.2.1 - Release\"'
    else: # keil
        build_command = xcalLauncher + " \"" + IDEcpr + '\" -r -j0 \"' + sourcedir + '\"'
else:
    if is_VS:
        build_command = xcalLauncher64 + " \"" + IDEcpr + '\" \"' + sourcedir + \
                        '\" /t:Clean,Build /p:Configuration=Release /p:Platform=x64'
    elif is_IAR:
        build_command = xcalLauncher + " \"" + IDEcpr + '\" \"' + sourcedir + '\" -build \"' \
                        + xml.dom.minidom.parse(sourcedir).documentElement.getElementsByTagName('name')[0].firstChild.data + '\"'
    elif is_SILI:
        build_command = xcalLauncher64 + " \"" + IDEcpr + '\" ' + \
                        ' -data \"' + os.path.split(sourcedir)[0] + '\" ' + sili_script + \
                        ' \"' + os.path.split(sourcedir)[1] + '\" -cfg \"GNU ARM v7.2.1 - Release\"'
    else: # keil
        build_command = xcalLauncher + " \"" + IDEcpr + '\" -r -j0 \"' + sourcedir + '\"'
logging.info(build_command)
if not parser.parse_args().cdb:
    logging.info('xcalLauncher: %s', os.popen(build_command).read())
cdb_name = ''
for i in os.listdir('.'):
    if re.match(r'^compilation-database\..*\.json$', i):
        cdb_name = i
        break

if parser.parse_args().cdb:
    cdb_name = parser.parse_args().cdb

if cdb_name == '':
    logging.error('cdb: ???')
    exit(1)
logging.info('cdb name: %s', cdb_name)

logging.info("output: " + output)
if os.path.exists(output):
    os.system('rd /s/q ' + output)

compile_commands = {}
link_commands = {}
source_files = []

if chardet.detect(open(cdb_name, 'rb').read())['confidence'] < 0.1:
    logging.error('can\'t decode cdb....')
    print('can\'t decode cdb....')
    exit(1)
compilation_database = json.load(open(cdb_name, encoding='utf-8'))
for i in range(len(compilation_database)):
    # 由 raw_command 变 command 是一段蟆法
    # 蟆法开始
    raw_command =  compilation_database[i]['command'].strip()
    if "Temp" in raw_command:
        # continue
        pass
    tag_dir = []
    head = -1
    for j in range(0, len(raw_command)):
        if head == -1 and raw_command[j] == '\"':
            head = j
        elif head != -1 and raw_command[j] == '\"':
            tag_dir.append([head, j])
            head = -1
    split_index = []
    for j in range(0, len(raw_command)):
        if raw_command[j] == ' ':
            ok = True
            for k in tag_dir:
                if j < k[1] and j > k[0]:
                    ok = False
                    break
            if ok:
                split_index.append(j)
    command = []
    if any(split_index):
        command.append(raw_command[0:split_index[0]].strip())
        for j in range(1, len(split_index)):
            command.append(raw_command[split_index[j-1]:split_index[j]].strip())
        command.append(raw_command[split_index[-1]:].strip())
    else:
        command.append(raw_command)
    command = [j for j in command if j != '' and j != ' ' and j != '--IDE2']
    for j in range(len(command)):
        if not ' ' in command[j]:
            command[j] = command[j].replace('\"', '')
    logging.debug('command: %s', command)
    # 蟆法结束

    directory = compilation_database[i]['directory'].strip()
    compiler = command[0].replace('\"','')
    cpr_type = get_compiler_type(basename(compiler))
    if cpr_type == 'unknown':
        logging.warning('compiler type : %s', cpr_type)
        continue
    cur_dict = {}
    cur_dict['compiler'] = compiler
    cur_dict['directory'] = directory
    cur_dict['cpr_type'] = cpr_type

    if cpr_type == 'ld' or cpr_type == 'ar':
        if is_VS:
            target = ''
            for c in command:
                if len(c) > 4 and c[:5] == '/OUT:':
                    target = basename(c[5:]).replace('\"','')
                    break
            if target == '':
                continue
            files = []
            others = []
            for c in command:
                if basename(c).replace('\"','').split('.')[-1] == 'obj' \
                    and basename(c).replace('\"','') != target:
                    files.append(basename(c).replace('\"',''))
                elif c[0] != '/':
                    others.append(c)

        else: # keil
            if '-o' in command:
                target = basename(command[command.index("-o")+1]).replace('\"','')
            elif '--create' in command:
                target = basename(command[command.index("--create")+1]).replace('\"','')
            else:
                continue
            files = []
            others = []
            for c in command:
                if basename(c).replace('\"','').split('.')[-1] == 'o' \
                    and basename(c).replace('\"','') != target:
                    files.append(basename(c).replace('\"',''))
                elif c[0] != '-':
                    others.append(c)

        cur_dict['options'] = ' '.join(command[1:])
        cur_dict['files'] = files 
        cur_dict['others'] = others
        link_commands[target] = cur_dict
    elif cpr_type == 'c' or cpr_type == 'cxx' or cpr_type == 'as':
        options = ''
        # 扩展名
        file_extension = ['c', 'cpp', 's', 'cc', 'C', 'S', 'cxx']
        if is_VS:
            source2output = {}
            for c in command:
                if '.' in basename(c).replace('\"','') and \
                    (basename(c).replace('\"','').split('.')[-1] in file_extension):
                    source2output[c] = ''.join(basename(c).replace('\"','')).split('.')[0]+'.obj'
                    if c.split('.')[-1] in ['s', 'S']:
                        cpr_type = 'as'
            for c in command:
                if len(c) > 2 and c[:3] == '/Fo':
                    continue
                elif basename(c).replace('\"','').split('.')[-1] in file_extension:
                    continue
                elif basename(c).replace('\"','') == basename(compiler):
                    continue
                options = options + c + ' '
            for c, obj in source2output.items():
                tmp_dict = {}
                tmp_dict['compiler'] = compiler
                tmp_dict['directory'] = directory
                tmp_dict['cpr_type'] = cpr_type
                tmp_dict['options'] = options
                tmp_dict['output_file'] = obj
                tmp_dict['source_file'] = normpath(c)
                compile_commands[obj] = tmp_dict
        else: # keil/iar
            source_file = ''
            output_file = ''
            j = 0
            while j < len(command):
                c = command[j]
                if basename(c).replace('\"','').split('.')[-1] in file_extension:
                    if c == 'c' or (j > 0 and command[j - 1] == '-main-file-name'):
                        j += 1
                        continue
                    source_file = c
                    if source_file.split('.')[-1] in ['s', 'S']:
                        cur_dict['cpr_type'] = 'as'
                    if is_IAR:
                        output_file = ''.join(basename(source_file).replace('\"','')).split('.')[0]+'.o'
                    else:
                        output_file = basename(command[command.index("-o")+1]).replace('\"','') \
                            if '-o' in command else ''.join(basename(source_file).replace('\"','')).split('.')[0]+'.o'
                    break #####
                else:
                    j += 1
            for c in command:
                if '-o' in command and c == command[command.index('-o')+1]:
                    continue
                if '--preprocess' in command and c == command[command.index('--preprocess')+1]:
                    continue
                if '--preprocess=n' in command and c == command[command.index('--preprocess=n')+1]:
                    continue
                elif len(c) > 2 and c[:3] == '-MF': 
                    continue
                if c == source_file:
                    continue
                elif basename(c).replace('\"','') not in ['-c', '-o', '--preprocess', \
                    '--preprocess=n', output_file, basename(compiler), compiler]:
                    options = options + c + ' '
            cur_dict['options'] = options
            cur_dict['output_file'] = output_file
            cur_dict['source_file'] = normpath(source_file)
            compile_commands[output_file] = cur_dict
if parser.parse_args().debug:
    open('compile_commands.json', 'w').write(json.dumps(compile_commands, indent=4))
    open('link_commands.json', 'w').write(json.dumps(link_commands, indent=4))

for key in link_commands.keys():
    target = link_commands[key]
    linker = target['compiler']
    for file in target['files']:
        if not file in compile_commands.keys():
            logging.warning("fail to find file: " + file)
            continue
        pwd = os.getcwd()
        os.chdir(compile_commands[file]['directory'])
        compile_command = compile_commands[file]
        mkdir(join(output, key + '.dir', preprocess))
        if compile_command['cpr_type'] == 'as':
            command = 'copy ' + compile_command['source_file'] + ' ' + join(output, key + '.dir', \
                        preprocess, basename(compile_command['source_file']).replace('\"', ''))
            logging.info('command: %s', command)
            os.system(command)
        else:
            source_files.append(normpath(join(compile_command['directory'], compile_command['source_file'].replace('\"', ''))))
            if basename(compile_command['source_file']).replace('\"', '').split('.')[-1] == 'c':
                i_file_name = join(output, key + '.dir', preprocess, \
                                basename(compile_command['source_file']).replace('\"', '') + '.i')
            else:
                i_file_name = join(output, key + '.dir', preprocess, \
                                basename(compile_command['source_file']).replace('\"', '') + '.ii')
            if is_VS:
                command = prevs + '\"' + compile_command['compiler'] + '\" /EP ' + compile_command['options'] \
                        + compile_command['source_file'] + ' /Fo:\"' + i_file_name + '\"'
                logging.info('command is %s', command)
                open(i_file_name, 'w').write(os.popen(command).read())
            elif is_IAR:
                command = '\"' + compile_command['compiler'] + '\" --preprocess=n \"' + i_file_name + '\" ' \
                        + compile_command['options'] + compile_command['source_file'] + iar_stdarg
                logging.info('command: %s', command)
                ####### fixme:随便给了两个数，可以支持 1.5w 个字符的 command.
                # 切的时候不能从引号内切开.
                if len(command) > 7666:
                    idx = 7666
                    while idx < 8000:
                        if command.count('"', 0, idx) % 2 == 0:
                            break
                        idx += 1
                    open('cmd.bat', 'w').write(command[:idx] + '^\n' + command[idx:])
                    os.popen('cmd.bat').read()
                else:
                    os.popen(command).read()
            elif is_SILI:
                command = '\"' + compile_command['compiler'] + '\" -E ' \
                            + compile_command['options'] + compile_command['source_file'] + ' -o \"' \
                            + i_file_name + '\"'
                logging.info('command: %s', command)
                os.popen(command).read()
            else: # keil
                if re.match(r'^.*(ArmClang).*$', compile_command['compiler']):
                    command = '\"' + compile_command['compiler'] + '\" ' + compile_command['options'] + ' -E ' \
                            + compile_command['source_file'] + ' -o \"' + i_file_name  + '\"'
                else:
                    command = '\"' + compile_command['compiler'] + '\" -E --no_implicit_include ' \
                            + compile_command['options'] + compile_command['source_file'] + ' -o \"'\
                            + i_file_name + '\"'
                logging.info('command: %s', command)
                os.popen(command).read()
            if os.path.exists(i_file_name):
                if is_SILI:
                    tmp_cont = ''
                    for line in open(i_file_name, 'r', encoding="utf-8").readlines():
                        if line[0] == '#' and line.count('\"') == 2 and line.count('<') == 0:
                            path = line[line.find('\"')+1:line.rfind('\"')]
                            line = line.replace(path, normpath(abspath(path))).replace('\\', '\\\\')
                        tmp_cont += line
                    open(i_file_name, 'w', encoding="utf-8").write(tmp_cont)
                else:
                    tmp_file = open(i_file_name, 'r', encoding="utf-8")
                    tmp_cont = ''
                    for line in tmp_file.readlines():
                        if len(line) > 5 and line[:6] == '#line ':
                            # 去掉换行符
                            tmp_dir = ' '.join(line.split(' ')[2:])[:-1]
                            line = line.replace(tmp_dir, '\"' + normpath(abspath(tmp_dir[1:-1])).replace('\\', '\\\\') + '\"')
                        # TODO:
                        if not re.match(r'^.*#.*include.*(\"|<)stdarg\.h(\"|>).*$', line):
                            tmp_cont += line
                    open(i_file_name, 'w', encoding="utf-8").write(tmp_cont)
                    tmp_file.close()
        os.chdir(pwd)

    property_dict = dict.fromkeys(property_key, "")
    if target['cpr_type'] == 'ar':
        property_dict["archiver"] = linker
        property_dict["ar_extra_flags"] = target['options']
    elif target['cpr_type'] == 'ld':
        property_dict["linker"] = linker
        property_dict["ld_extra_flags"] = target['options']
        property_dict['dependencies'] = []
        for j in target['others']:
            j = basename(j).replace('\"','')
            if j != key and (j in link_commands.keys() or (len(j) > 1 and j[:2] == '-l' and j[2:] in link_commands.keys())):
                property_dict['dependencies'].append(j)
        property_dict['dependencies'] = ' '.join(property_dict['dependencies'])
    if len(target['files']) > 0:
        for file in target['files']:
            if not file in compile_commands.keys():
                continue
            if compile_commands[file]['cpr_type'] == 'c':
                property_dict['c_compiler'] = compile_commands[file]['compiler']
                property_dict['c_extra_flags'] = compile_commands[file]['options']
                if '32' in platform.architecture()[0] and (not '-m32' in compile_commands[file]['options']):
                    property_dict['c_extra_flags'] += ' -m32 '
                if '-std=c99' in compile_commands[file]['options'] and '-std=c99' not in property_dict['c_scan_options']:
                    property_dict['c_scan_options'] += ' -std=c99 '
            elif compile_commands[file]['cpr_type'] == 'cxx':
                property_dict['c_compiler'] = compile_commands[file]['compiler']
                property_dict['cxx_extra_flags'] = compile_commands[file]['options']
                if '32' in platform.architecture()[0] and (not '-m32' in compile_commands[file]['options']):
                    property_dict['cxx_extra_flags'] += ' -m32 '
            elif compile_commands[file]['cpr_type'] == 'as':
                property_dict['as_compiler'] = compile_commands[file]['compiler']
                property_dict['as_extra_flags'] = compile_commands[file]['options']
                if '32' in platform.architecture()[0] and (not '-m32' in compile_commands[file]['options']):
                    property_dict['as_extra_flags'] += ' -m32 '
    if is_IAR:
        property_dict['c_scan_options'] += '-Wf,-fiar -m32 -std=c99 -std=gnu99'
        property_dict['cxx_scan_options'] += '-Wf,-fiar -m32'
    elif is_SILI:
        property_dict['c_scan_options'] += '-m32 -std=gnu99'
        property_dict['cxx_scan_options'] += '-m32 -std=gnu99'
    elif not is_VS: ## keil
        property_dict['c_scan_options'] += ' -Wf,-fkeil -m32 '
        property_dict['cxx_scan_options'] += '-Wf,-fkeil -m32 '
    if os.path.exists(join(output, key + ".dir")):
        propertyFile = open(join(output, key + '.dir', 'xcalibyte.properties'), "w")
        for item in property_dict.items():
            propertyFile.write(str(item[0]) + '=' + str(item[1]) + '\n')
        propertyFile.close()
        tune_file = open(join(output, key + '.dir', 'xcalibyte.properties'),'r')
        result = tune_file.read()
        result = result.replace(r'\r\n',r'\n')
        tune_file.close()
        tune_file = open(join(output, key + '.dir', 'xcalibyte.properties'),'wb')
        tune_file.write(result.encode())
        tune_file.close()
mkdir(output)
open(join(output, 'xcalibyte.properties'), "w")

with open(join(output, 'checksum.sha1'), "w") as checksumSha1:
    logging.info('generate checksum.sha1')
    for dirpath, dirnames, filenames in os.walk(output):
        for filename in filenames:
            if filename == 'checksum.sha1':
                continue
            file = join(dirpath, filename)
            sha1 = hashlib.sha1(open(file, "rb").read()).hexdigest()
            checksumSha1.write(sha1 + ' ' + file + '\n')

source_files = list(set(source_files))
open(join(parser.parse_args().output, 'source_files.json'), 'w').write(json.dumps(source_files))

with tarfile.open(output + '.tar.gz', "w:gz") as tar:
    try:
        tar.add(output, arcname='')
    except Exception as exception:
        logging.error('FAILED: %s', exception)
# copyfile('', join(parser.parse_args().output, 'preprocess.tar.gz'))

logging.info("done(=_=)")
print("done(=_=)")
