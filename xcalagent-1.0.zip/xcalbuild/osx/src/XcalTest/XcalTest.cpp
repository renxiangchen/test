/*
 *  Copyright (C) 2019-2020  XC Software (Shenzhen) Ltd.
 */


#include <cstdio>
#include <cassert>
#include <cstring>
#include <unistd.h>
#include <dlfcn.h>
#include <stdlib.h>

#include "injector.h"

int main(int argc, char* argv[])
{
  if (argc < 3) {
    fprintf(stderr, "XcalTest: usage XcalTest [proc_name] [lib]\n");
    return 0;
  }

  char path[4096];
  realpath(argv[2], path);
  fprintf(stderr, "XcalTest: %s\n", path);

  Injector inj;
  pid_t pid = inj.getProcessByName(argv[1]);
  if (!pid) {
      fprintf(stderr, "XcalTest: process %s not found\n", argv[1]);
      return 0;
  }
  fprintf(stderr, "XcalTest: pid: %u\n", pid);
  
  inj.inject(pid, path);

  int i = 0;
  while (i++ < 30) {
    fprintf(stderr, ".");
    sleep(1);
  }
  fprintf(stderr, "\n");
  return 0;
}
