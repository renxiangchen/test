README
========

funchook is taken from funchook
https://github.com/kubo/funchook

GPL-v2 license with link exception. no change on source code
