README
========

InitHelper is taken from osxinj/osxinj
https://github.com/scen/osxinj

MIT license. no change on source code.

