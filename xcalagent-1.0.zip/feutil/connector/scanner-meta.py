#!/usr/bin/env python3
# encoding: utf-8

# Xcalibyte Vulnerability Static Analyzer Java Version 1.0
# Copyright (c) 2018-2019 Xcalibyte Limited
# Confidential under the terms of the NDA between Xcalibyte and the licensee.
# For the use of the licensee only. Internal use only. No redistribution.

# Module Name: scanner-meta.py
# dump engine and ruleset information into file
# usage:
# scanner-meta.py <scanner> <output-file>

# std library
import getopt
import sys
import os
import subprocess

def usage(prog):
    """
    print usage
    """
    print(prog + ": dump scanner engine and ruleset information into file")
    print("Usage: " + prog + " -h | <scanner> <output-file>")
    print("  -h: print this usage")
    print("  <scanner>: the scanner to be dumped")
    print("  <output_file>: the file to be written")

# main
if __name__ == "__main__":
    # parse parameters
    prog_name = os.path.basename(sys.argv[0])
    dir_root  = os.path.dirname(os.path.abspath(sys.argv[0]))
    scanner = None
    output_file = None

    if len(sys.argv) > 1 and sys.argv[1] == "-h":
        usage(prog_name)
        sys.exit(1)

    if len(sys.argv) != 3:
        usage(prog_name)
        sys.exit(1)

    scanner = sys.argv[1]
    output_file = sys.argv[2]

    scanner_dir = os.path.join(dir_root, scanner)
    if not os.path.isdir(scanner_dir):
        print("Error: not find the scanner `" + scanner + "'")
        sys.exit(2)

    meta_file = os.path.join(scanner_dir, "meta.py")
    if not os.path.isfile(meta_file):
        print("Error: not find meta.py in " + scanner_dir)
        sys.exit(2)

    sys.path.append(dir_root)

    args = [ meta_file, "-o", output_file ]
    subprocess.run(args)

