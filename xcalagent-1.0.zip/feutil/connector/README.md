# scanner-connector

connector to 3rd party scanners, include spotbugs, oclint, etc
========

1. Supported 3rd party scanners
   The following 3rd party scanners are supported:
   * OCLint   http://oclint.org/
   * Spotbugs https://spotbugs.github.io/

2. Download and installation
   * Download installation package from in-house-SDLC:
     http://10.10.3.12:8888/cephfs/in-house-SDLC/oclint-latest.tar.gz
     http://10.10.3.12:8888/cephfs/in-house-SDLC/spotbugs-latest.tar.gz
   * Unpack the tarball in installation location
     $ make <directory-to-install>
     $ cd <directory-to-install>
     $ tar xf <name>-latest.tar.gz
   * The following directory shown after installation:
     + <directory-to-install>
       - scanner-meta.py     generate meta info
       - scanner-run.py      run 3rd party scanner
       + model               Model for Xcalibyte engine/ruleset/rule/issue meta info
       + utils               Utilities
       + <name>              spotbugs/oclint, contains wrapper and scanner

3. Meta info
   `scanner-meta.py' is used to generate meta info
   $ <directory-to-install>/scanner-meta.py
   Usage: scanner-meta.py -h | <scanner> <output-file>
     -h: print this usage
     <scanner>: the scanner to be dumped
     <output_file>: the file to be written

   Example: generate meta info for oclint:
   $ <directory-to-install>/scanner-meta.py oclint oclint-meta.json

4. Run scanner
   `scanner-run.py' is used to scan a directory and generate the report
   $ <directory-to-install>/scanner-run.py
   scanner-run.py: run scanner with input directory
    Usage: scanner-run.py -h | -s <scanner> -o <output-file> -l <log-file> <input-dir> -- <extra-scanner-options>
      -h:               print this usage
      -s <scanner>:     specify the scanner to be used
      -o <output-file>: specify the final report file
      -l <log-file>:    specify the log file
      <input-dir>:      specify the input directory to be scanned
      -- <extra-scanner-options>:
                        extra scanner options to be passed to scanner directly

   Example: scan all .i/.ii in a directory and enable Clang static analyzer
   $ <directory-to-install>/scanner-run.py -s oclint -o oclint-scan-result.json -l oclint-scan.log <directory-to-scan> -- -enable-clang-static-analyzer

5. Python libs requirement
   * third party lib:
     * lxml https://lxml.de/installation.html
   * builtin lib:
     * enum
     * io
     * xml
     * base64
     * datetime
     * decimal
     * getopt
     * json
     * logging
     * os
     * re
     * subprocess
     * sys
     * traceback
     * warnings
