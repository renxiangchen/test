#!/usr/bin/env python3
# encoding: utf-8

# Xcalibyte Vulnerability Static Analyzer
# Copyright (c) 2018-2019 Xcalibyte Limited
# Confidential under the terms of the NDA between Xcalibyte and the licensee.
# For the use of the licensee only. Internal use only. No redistribution.

# Module Name: scan_base.py
# base class for scan command which take directory as input and generate a single xcalibyte json report file

# std library
import getopt
import sys
import os
import subprocess
import logging
import datetime

# connector libraries
from utils import file_utils

class BaseScanner():
    """
    base class for scan service
    private attributes:
        _prog_name:           program name
        _script_dir:          directory where the script is
        _input_dir:           input directory where the files to be scanned are
        _output_dir:          output directory where the intermediate and final result files are
        _logger:              logger object
        _logger_stream:       logger stream object
        _scanner_opts:        scanner options passed from top level script
        _scanner_output:      is the scanner output in stdout or file
        _scanner_output_file: scanner output file name
        _final_output_file:   final output file name
        _keep:                keep intermediate files for debugging
    private methods:
        _prepare:             parse cmd options and do initialization
        _run_scanner:         run scanner
        _run_converter:       run result converter
    subclass methods:
        _cleanup:             cleanup intermediate files
        _scan_cmd:            return the scan command
        _conv_cmd:            return the convert command
    public methods:
        usage:                print usage
        run:                  run prepare, scanner and converter
    """
    # scanner output is stdout
    SCANNER_OUTPUT_STDOUT = 1
    # scanner output is file
    SCANNER_OUTPUT_FILE   = 2

    def __init__(self):
        """
        initialization
        """
        pass

    def __str__(self):
        """
        convert self into string
        """
        ret = ""
        for key, value in self.__dict__.items():
            if key == "_log_file" or key == "_logger_stream" or key == "_logger":
                continue
            ret += "\t" + key + ":\t"
            ret += str(value) + "\n"
        return ret

    def usage(self):
        """
        print usage
        """
        print(self._prog_name + ": scan files in directory and generate json file for Xcalibyte framework")
        print("Usage: " + self._prog_name + " -h | -l <log_file> -o <output_file> <input_dir> -- <scanner_options>")
        print("  -h: print this usage")
        print("  -l <log_file>: write log into <log_file>")
        print("  -o <output_file>: write report into <output_file>")
        print("  <input_dir>: directory contains the input files to be scanned")


    def _prepare(self, argv):
        """
        parse arguments
        """
        assert self._scanner_output == BaseScanner.SCANNER_OUTPUT_STDOUT or \
               self._scanner_output == BaseScanner.SCANNER_OUTPUT_FILE

        # parse parameters
        self._prog_name = os.path.basename(argv[0])
        self._script_dir = os.path.dirname(os.path.abspath(__file__))
        self._input_dir = None
        self._log_file = None
        self._logger = None
        self._scanner_opts = None
        self._scanner_output_file = None
        self._final_output_file = None
        self._keep = False

        try:
            options, args = getopt.getopt(argv[1:], "hko:l:")
            for name, value in options:
                if name == "-h":
                    self.usage()
                    return 1
                elif name == "-k":
                    self._keep = True
                elif name == "-o":
                    self._final_output_file = value
                elif name == "-l":
                    self._log_file = value
            if len(args) > 0:
                self._input_dir = args[0]
            if len(args) > 2 and args[1] == '--':
                self._scanner_opts = args[2:]
        except getopt.GetoptError as e:
            sys.stderr.write("Error: " + str(e) + ". Please run `" + self._prog_name + " -h' for more details.\n")
            return 1
        # check if input_dir/output_file is specified
        if self._input_dir is None or \
           self._final_output_file is None:
            self.usage()
            return 1

        # check if input_dir contains full oclint binaries
        if not os.path.isdir(self._input_dir):
            sys.stderr.write("Error: `" + self._input_dir + "' is not a directory, please check.\n")
            return 2

        # set and check output_dir
        self._output_dir = os.path.dirname(os.path.abspath(self._final_output_file))
        if not os.path.isdir(self._output_dir):
            sys.stderr.write("Error: `" + self._output_dir + "' doesn't exist.\n")
            return 2

        # initialize the log
        if self._log_file is None or \
           not os.path.isdir(os.path.dirname(os.path.abspath(self._log_file))):
            log_file_name = self._prog_name + ".log" if self._log_file is None \
                                                     else os.path.basename(self._log_file)
            self._log_file = os.path.join(self._output_dir, log_file_name)
            sys.stderr.write("Warning: log is written to `" + self._log_file + "'.\n")

        # check if log file can be written
        try:
            self._logger_stream = open(self._log_file, "a")
            self._logger = logging.getLogger(self._prog_name)
            self._logger.setLevel(logging.INFO)
            handler = logging.StreamHandler(self._logger_stream)
            handler.setFormatter(logging.Formatter('[%(asctime)s] %(levelname)s %(message)s'))
            self._logger.addHandler(handler)
            self._logger.info(self._prog_name + " started.")
        except IOError as e:
            sys.stderr.write("Error: failed to open `" + self._log_file + "' for write.\n")
            return 3

        time_str = datetime.datetime.now().strftime('%y%m%d%H%M%S')
        sof_name = self._prog_name + "-" + time_str + "-scan.out"
        self._scanner_output_file = os.path.join(self._output_dir, sof_name)

        # return 0
        return 0


    def _run_scanner(self, args):
        """
        run scanner with subprocess.
        """
        try:
            # run scanner
            if self._scanner_output == BaseScanner.SCANNER_OUTPUT_STDOUT:
                out_file = open(self._scanner_output_file, "w")
                err_file = self._logger_stream
            else:
                out_file = self._logger_stream
                err_file = subprocess.STDOUT
        except IOError as e:
            self._logger.error("failed to open `" + self._scanner_output_file + "'.\n")
            self._logger.error(str(e), exc_info = True)
            return 1

        try:
            # start sub process
            ret = subprocess.run(args, stdout = out_file, stderr = err_file)
            if ret.returncode != 0:
                self._logger.error("program `" + args[0] + "' returns " + str(ret.returncode) + ".\n")
                return ret.returncode

        except Exception as e:
            self._logger.error("failed to execute + `" + args[0] + "'.\n")
            self._logger.error(str(e), exc_info = True)
            return 2
        finally:
            # close out file
            if self._scanner_output == BaseScanner.SCANNER_OUTPUT_STDOUT:
                out_file.close()
        # return 0
        return 0

    def _run_converter(self, args):
        """
        run converter with subprocess
        """
        try:
            out_file = self._logger_stream
            err_file = subprocess.STDOUT
            ret = subprocess.run(args, stdout = out_file, stderr = err_file)
            if ret.returncode != 0:
                self._logger.error("program `" + args[0] + "' returns " + str(ret.returncode) + ".\n")
                return ret.returncode
        except Exception as e:
            self._logger.error("failed to execute + `" + args[0] + "'.\n")
            self._logger.error(str(e), exc_info = True)
            return 2
        # return 0
        return 0

    def _cleanup(self, retcode):
        """
        do cleanup. retcode == 0 means program completed successfully
        """
        if self._keep == True:
            return
        if os.path.isfile(self._scanner_output_file):
            os.remove(self._scanner_output_file)


    def run(self, argv):
        """
        run scanner and result converter
        """
        ret = 0;
        try:
            ret = self._prepare(argv)
            if ret != 0:
                return ret
            self._logger.info(self._prog_name + " prepare scanner done:\n" + str(self))

            scan_cmd = self._scan_cmd()
            if scan_cmd is None or len(scan_cmd) < 1:
                return 1

            self._logger.info(self._prog_name + " run scanner started :\n\t" + " ".join(scan_cmd) + "\n")
            ret = self._run_scanner(scan_cmd)
            self._logger.info(self._prog_name + " run scanner done: returns " + str(ret) + "\n")

            if ret != 0:
                return ret

            conv_cmd = self._conv_cmd()
            if conv_cmd is None or len(conv_cmd) < 1:
                return 1
            
            self._logger.info(self._prog_name + " run converter started:\n\t" + " ".join(conv_cmd) + "\n")
            ret = self._run_converter(conv_cmd)
            self._logger.info(self._prog_name + " run converter done: returns " + str(ret) + "\n")
            return ret

        except Exception as e:
            if not self._logger is None:
                self._logger.error(self._prog_name + " scan failed: " + str(e), exc_info = True)
                ret = 1
            else:
                raise e
        finally:
            self._logger.info(self._prog_name + " scan done. returns " + str(ret))
            self._cleanup(ret)
            self._logger_stream.flush()
            logging.shutdown()

        # return 0
        return 0;


