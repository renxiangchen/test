#!/usr/bin/env python3
# encoding: utf-8

# Xcalibyte Vulnerability Static Analyzer Java Version 1.0
# Copyright (c) 2018-2019 Xcalibyte Limited
# Confidential under the terms of the NDA between Xcalibyte and the licensee.
# For the use of the licensee only. Internal use only. No redistribution.

# Module Name: file_utils.py
# file utilities

import os

# find files in root_dir with given extention
# if symlink is True, symlink to other directory is also traversed
def find_files(root_dir, ext, symlink = False):
    """
    find all files with given ext in root_dir
    """
    files = []
    if os.path.isdir(root_dir):
        flist = os.listdir(root_dir)
        for fn in flist:
            if fn == "." or fn == "..":
                continue
            full_name = os.path.join(root_dir, fn)
            if os.path.isfile(full_name):
                ext_name = os.path.splitext(full_name)[1]
                if ext_name in ext:
                    files.append(full_name)
            elif symlink == False and os.path.islink(full_name):
                continue;
            elif os.path.isdir(full_name):
                sub = find_files(full_name, ext, symlink)
                if not sub is None and len(sub) > 0:
                    files.extend(sub)
    return files

def search_relative_file(s_dir, rel_file):
   """
   find absolte path of rel_file in root_dir
   """
   files = set()
   root_dir = os.path.abspath(s_dir)
   for root,  _, _  in os.walk(root_dir):
      checkfile=os.path.join(root, rel_file)
      if os.path.isfile(checkfile):
          files.add(checkfile)
   return files

# test main
if __name__ == "__main__":
    files = find_files(".", [".py", ".md"])
    print(files)
    files = find_files(".", [".py", ".md"], True)
    print(files)
