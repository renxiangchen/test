# scanner-connector/utils

common utilities for scanner-connector
