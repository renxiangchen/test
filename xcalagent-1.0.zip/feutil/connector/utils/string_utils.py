#!/usr/bin/env python3
# encoding: utf-8

# Xcalibyte Vulnerability Static Analyzer Java Version 1.0
# Copyright (c) 2018-2019 Xcalibyte Limited
# Confidential under the terms of the NDA between Xcalibyte and the licensee.
# For the use of the licensee only. Internal use only. No redistribution.

# Module Name: string_utils.py
# string utilities

import re

def sanitize_str(in_str):
    """
    replace all ![a-zA-Z0-9_] with '-'
    """
    return re.sub('[^a-zA-Z0-9_]', '-', in_str.strip())


if __name__ == "__main__":
    assert sanitize_str(" abc ") == "abc"
    assert sanitize_str(" a!b@c ") == "a-b-c"

