#!/usr/bin/env python3
# encoding: utf-8

# Xcalibyte Vulnerability Static Analyzer Java Version 1.0
# Copyright (c) 2018-2019 Xcalibyte Limited
# Confidential under the terms of the NDA between Xcalibyte and the licensee.
# For the use of the licensee only. Internal use only. No redistribution.

# Module Name: file_manager
# manage the source files

try:
    from errors import *
except ImportError:
    from utils.errors import *

class FileManager:
    """
    Manage the scanned files, contains two mapping:
    filename->fileid
    fileid->filepath
    """
    def __init__(self):
        self.fname2IdMap = dict()
        self.id2PathMap = dict()
        self.lastId = 0

    def id2path_map(self):
        return self.id2PathMap

    def GenOrGetId(self, fname):
        id = self.fname2IdMap.get(fname)
        if id is None:
            self.lastId += 1
            self.AddFilePath(self.lastId, fname)
            return self.lastId
        else:
            return id

    def GenOrGetIdByFname(self, fname):
        id = self.fname2IdMap.get(fname)
        if id is None:
            self.lastId += 1
            self.fname2IdMap[fname] = self.lastId
            return self.lastId
        else:
            return id
    
    def AddFilePath(self, id, path):
        if id <= self.lastId:
            if self.id2PathMap.get(id) is None:
                self.id2PathMap[id] = path
                self.fname2IdMap[path] = id
        else:
            raise Exception("Duplicate file id for path" + path)

# Test main
if __name__ == "__main__":
    import json
    file_mgr = FileManager()
    file_mgr.GenOrGetId("A1.java")
    file_mgr.AddFilePath(1, os.path.join(os.sep, "home", "xxx", "A1.java"))
    print(json.dumps(file_mgr, default=lambda o: o.__dict__, indent=1, sort_keys=True))
