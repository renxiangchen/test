#!/usr/bin/env python3
# encoding: utf-8

# Xcalibyte Vulnerability Static Analyzer Java Version 1.0
# Copyright (c) 2018-2019 Xcalibyte Limited
# Confidential under the terms of the NDA between Xcalibyte and the licensee.
# For the use of the licensee only. Internal use only. No redistribution.

# Module Name: error_code.py
# error code description

import sys
from enum import Enum

class ErrorManager:
    """
    define error code
    """
    ERR_OK = "OK"
    ERR_NO_FILE_STATS = "No FileStats elements"
    ERR_FATAL = 3

    def __init__(self):
        self.fobj = sys.stderr

    def open_file(self, fname):
        try:
            self.fobj = open(fname, "w")
        except IOException as e:
            sys.stderr.write("\tERROR: unable to open file " + fname)
            sys.exit()

    def close_file(self):
        if self.fobj is not None:
            self.fobj.close()
 
    def report_warning(self, msg):
        if self.fobj is not None:
            self.fobj.write("\t" + "WARN: " + msg + "\n")

    def report_fatal(self, msg):
        if self.fobj is not None:
            self.fobj.write("\tERROR: " + msg + "\n")
        sys.exit(self.ERR_FATAL)

error_manager = ErrorManager()

def error_mgr(): 
   """
   return global error object
   """
   return error_manager
