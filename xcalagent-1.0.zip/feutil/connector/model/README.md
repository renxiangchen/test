# scanner-connector/model

define common model for all scanners so that their rules and scan results can be converted into this common model and integrated into xcalibyte framework

1. Engine - ruleset - rul
   Current version: 1

1.1 Structure:
 + Engine -- A scan engine which loads ruleset and scan source file, IR files to produce a report
   + Ruleset -- A set of rules which can be picked by the engine
     - Rule -- An issue template

1.2 Attributes and description:
 + (engine)
   - name  -- name of the engine. string, "mastiff"
   - version  -- major version of the engine, different revision engines with same version are backward compatible. string, "1"
   - revision  -- revision of the engine, include the minor version and/or patch level, string "1.0.3"
   - description  -- description of the engine, string, "mastiff scan engine"
   - languages  -- languages can be scanned by this engine, string, "c, cxx, java"
   - engine_url  -- url to engine web page, string, "http://www.xcalibyte.cn/product/mastiff"
   - provider  -- engine provider, string, "xcalibyte"
   - provider_url  -- url to engine provider web page, string, "http://www.xcalibyte.cn"
   - license  -- engine license, string, "commercial"
   - license_url  -- url to engine license web page, string, "http://www.xcalibyte.cn/license"
   + rulesets
     + (ruleset)
       - name  -- name of the ruleset to match rs in report file, string, "builtin",
       - display_name  -- display name of the ruleset to display on UI, string, "Xcalibyte"
       - version  -- major version of the ruleset, different revision rulesets with same version are backward compatible, string, "1"
       - revision  -- revision of the ruleset, include minor version and/or patch level, string "1.0.3"
       - description  -- description of the ruleset, string, "builtin ruleset"
       - languages  -- languages can be checked by this ruleset, string, "c, cxx"
       - ruleset_url  -- url to ruleset web page, string, "http://www.xcalibyte.com/product/mastiff/builtin"
       - provider  -- ruleset provider, string, "xcalibyte"
       - provider_url  -- url to ruleset provider, string, "http://www.xcalibyte.cn"
       - license  -- license of the ruleset, string, "commercial"
       - license_url  -- url to the ruleset license, "http://www.xcalibyte.cn/license"
       + rules
         + (rule)
           - code  -- unique rule code, string, "NPD"
           - name  -- name of the rule, string, "Null pointer dereference"
           - description  -- description for this rule, string, "blahblah"
           - details  -- more details of the rule, string, "blahblah"
           - languages  -- languages can be checked by this rule, string, "c, c++"
           - category  -- rule category,, string:
                          correctness, security, performance, bad-practice, coding-style
           - severity  -- issue severity found by this rule, string:
                          low, medium, high
           - priority  -- issue priority found by this rule, string:
                          low, medium, high, critical
           - likelyhood  -- does the issue found by this rule likely or unlikely happen, string:
                            unlikely, possible, likely
           - fix_cost  -- the code to fix the issue found by this rule, string:
                          low, medium, high
           - rule_url  -- url to rule web page, string, "http://www.xcalibyte.cn/product/mastiff/builtin/npd"

1.3 Example:
 + Xcalibyte Engine
   + Builtin ruleset
     - NPD
     - UIV
     - ...
   + CERT-C ruleset
     - INT32
     - ERR33
     - ...
   + CERT-J ruleset
     - IDS00
   + ...
 + SpotBugs Engine
   + Builtin ruleset
     - NP_BOOLEAN_RETURN_NULL
     - ...
   + Xcalibyte SpotBugs ruleset
   + User SpotBugs ruleset
   + ...
 + OCLint Engine
   + Builtin ruleset
     - short variable name
     - ...
   + Xcalibyte OCLint ruleset
   + User OCLint ruleset


2. Report - FileInfo, Issue
   Current version: 1

2.1 Structure:
 + Report -- The result from a scan session, produced by the engine
   + FileInfos -- All source files involved in this scan session
     - FileInfo -- A source file with file id and file path name
   + Rulesets -- The rulesets available in the engine
     - Ruleset -- Name and version of the ruleset
   + Issues -- All issues found in this scan session
     + Issue - An issue reported by the engine with a rule
       + TracePaths -- Full trace path for this issue
         - TracePath -- A single step in the full trace path

2.2 Attributes and description:
  To reduce the length of the report content, all "keys" are limited to 1~4 letters. Full name is listed in square brackets for reference.
  + (report)
    - v   [version]  -- version of the report format, string, "1"
    - id  [scanTaskId]  -- scan task id, string, "xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx"
    - s   [status]  -- scan session status, string, "completed"
    - m   [message]  -- message for this scan session, string, "blah"
    - eng [scanEngine]  -- engine used in this scan, string, "mastiff"
    - ev  [scanEngineVersion] -- version of engine used in this scan, string, "1.0"
    - cmd [scanCmd]  -- command line to start this scan, string, "xvsa *.i"
    - env [scanEnv]  -- environment variables set in this scan, string, "HOME=blah:SHELL=blah..."
    - ss  [scanStart] -- scan start time in microseconds, timestamp in microseconds, "1557028390263230"
    - se  [scanEnd] -- scan end time in microseconds, timestamp in microseconds, "1557028390268314"
    + files [fileInfos]
      + (fileInfo)
        - fid  [fileId]  -- source file id, string, "1"
        - path [path]  -- source file path, string, "/home/test/test.h"
    + rulesets
      + (ruleset)
        - rs   [ruleset]  -- ruleset name, string, "BUILTIN"
        - rv   [rulesetVersion] -- ruleset version, string, "1.0"
    + issues
      + (issue)
        - k   [key] -- unique key of this issue, string, "NPD@@file.c@@5@@a@@func@@"
        - c   [certainty]  -- certainty about the issue. definitely or maybe, string: "M" for maybe or "D" for definitely
        - rs  [ruleset]  -- which ruleset the rule is from, string, "builtin"
        - rc  [ruleCode]  -- the unique code of the rule, string, "NPD"
        - ec  [errorCode]  -- error code for variants checked by the same rule, string, null or "MSC37-C"
        - fid [fileId]  -- source file id, string, "1"
        - sln [startLineNo]  -- start line number, integer, 0 means no startLineNo provided
        - scn [startColumnNo]  -- start column number, integer, 0 means no startColumnNo provided
        - eln [endLineNo]  -- end line number, integer, 0 means no endLine provided
        - ecn [endColumnNo]  -- end line number, integer, 0 means no endColumnNo provided
        - m   [message]  -- message from engine about this issue, string, "issue message"
        - vn  [variableName]  -- variable name for this issue, string, "var"
        - fn  [functionName]  -- function name for this issue, string, "func"
        - tn  [typeName]  -- type name for the variable or issue, string, "type"
        + paths [tracePaths]
          + (tracePath)
            - fid [fileId]  -- source file id, string, "1"
            - sln [startLineNo]  -- start line number, integer, 0 means no startLineNo provided
            - scn [startColumnNo]  -- start column number, integer, 0 means no startColumnNo provided
            - eln [endLineNo]  -- end line number, integer, 0 means no endLine provided
            - ecn [endColumnNo]  -- end column number, integer, 0 means no endColumnNo provided
            - m   [message]  -- message from engine about this step, string, "issue message"
            - vn  [variableName]  -- variable name for this step, string, "var"
            - fn  [functionName]  -- function name for this step, string, "func"
            - tn  [typeName]  -- type name for this variable or step, string, "type"

