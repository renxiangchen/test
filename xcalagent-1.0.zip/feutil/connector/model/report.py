#!/usr/bin/env python3
# encoding: utf-8

# Xcalibyte Vulnerability Static Analyzer Java Version 1.0
# Copyright (c) 2018-2019 Xcalibyte Limited
# Confidential under the terms of the NDA between Xcalibyte and the licensee.
# For the use of the licensee only. Internal use only. No redistribution.

# Module Name: ruleset_meta.py
# model definition for ruleset
# a ruleset is defined as a stonealone package contains many rules

import json

# FileInfo
class FileInfo:
    """
    define file info
    """
    def __init__(self,
                 fileId,   # file id
                 path      # file path name
                ):
        self.fid = fileId
        self.path = path

# Ruleset
class Ruleset:
    """
    define ruleset info
    """
    def __init__(self,
                 name,    # ruleset name
                 version  # ruleset version
                ):
        self.rs = name
        self.rv = version

# Report
class Report:
    """
    report version
    """
    VERSION = '1'

    """
    define a report
    """
    def __init__(self,
                 version,            # version of the report
                 scanTaskId,         # scan task id
                 status,             # scan status
                 message,            # scan message
                 scanEngine,         # scan engine: xcalibyte, oclint, spotbugs, etc
                 scanEngineVersion,  # scan engine version
                 scanEngineRevision, # scan engine revision
                 scanCmd,            # scan command line
                 scanEnv,            # scan environment variables
                 scanStart,          # scan start time in microseconds
                 scanEnd             # scan end time in microseconds
                ):
        self.v   = version
        self.id  = scanTaskId
        self.s   = status
        self.m   = message
        self.eng = scanEngine
        self.ev  = scanEngineVersion
        self.er  = scanEngineRevision
        self.cmd = scanCmd
        self.env = scanEnv
        self.ss  = scanStart
        self.se  = scanEnd
        self.files    = []
        self.rulesets = []
        self.issues   = []

    """
    set scan TaskId
    """
    def setScanTaskId(self, id):
        self.id = id

    """
    set scan Time
    """
    def setScanTime(self, start, end):
        self.ss = start
        self.se = end

    """
    set scan end
    """
    def addScanEnd(self, end):
        self.se = self.se + end

    """
    set scan version
    """
    def setScanVersion(self, version):
        self.ev = version

    """
    get scan version
    """
    def getScanVersion(self):
        return self.ev

    """
    set scan revision
    """
    def setScanRevision(self, revision):
        self.er = revision

    """
    add a file to fileInfos
    """
    def addFileInfo(self, fileinfo):
        self.files.append(fileinfo)

    """
    add a ruleset info
    """
    def addRuleset(self, ruleset):
        self.rulesets.append(ruleset)

    """
    add an issue to issues
    """
    def addIssue(self, issue):
        self.issues.append(issue)


"""
test method to test Report
"""
if __name__ == "__main__":
    import json
    rpt = Report("1",
                 "scan task id",
                 "status",
                 "message",
                 "scan engine",
                 "scan engine version",
                 "scan engine revision",
                 "scan cmd",
                 "scan env",
                 "scan start",
                 "scan end"
                )
    print (json.dumps(rpt, default=lambda o: o.__dict__, indent=1, sort_keys=True))

    rpt.addFileInfo(FileInfo(1, "a.c"))
    rpt.addFileInfo(FileInfo(2, "b.c"))
    rpt.addRuleset(Ruleset("builtin", "1.0"))
    rpt.addRuleset(Ruleset("ext", "2.0"))
    rpt.addIssue("test-issue-1")
    rpt.addIssue("test-issue-2")
    print (json.dumps(rpt, default=lambda o: o.__dict__, indent=1, sort_keys=True))
