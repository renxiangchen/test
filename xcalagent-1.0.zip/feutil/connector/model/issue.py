#!/usr/bin/env python3
# encoding: utf-8

# Xcalibyte Vulnerability Static Analyzer Java Version 1.0
# Copyright (c) 2018-2019 Xcalibyte Limited
# Confidential under the terms of the NDA between Xcalibyte and the licensee.
# For the use of the licensee only. Internal use only. No redistribution.

# Module Name: issue.py
# definition for issue
# a issue is defined as a record reported by scanner with a given rule

import json

# IssueCertainty
class IssueCertainty:
    """
    define issue certainty
    """
    Definitely = "D"
    Maybe = "M"
    SPOTBUG_HIGH   = "CONFIDENCE_1"
    SPOTBUG_NORMAL = "CONFIDENCE_2"
    SPOTBUG_LOW    = "CONFIDENCE_3"

# Path
class TracePath:
    """
    describe the trace path
    """
    def __init__(self,
                 fileId,              # file id
                 startLineNo,         # start line no
                 startColumnNo = 0,   # start column no
                 endLineNo = 0,       # end line no
                 endColumnNo = 0,     # end column no
                 message = "",        # message
                 variableName = None, # variable name
                 functionName = None, # function name
                 typeName = None      # type name
                ):
        self.fid = fileId
        self.sln = startLineNo
        self.scn = startColumnNo
        self.eln = endLineNo
        self.ecn = endColumnNo
        self.m   = message
        self.vn  = variableName
        self.fn  = functionName
        self.tn  = typeName

# Issue
class Issue:
    """
    describe the issue
    """
    def __init__(self,
                 key,                # unique key for a issue
                 certainty,          # certainty
                 ruleset,            # ruleset name
                 ruleCode,           # rule code
                 errorCode,          # variants checked by the same rule
                 fileId,             # file id
                 startLineNo,        # start line no
                 startColumnNo = 0,  # start column no
                 endLineNo = 0,      # end line no
                 endColumnNo = 0,    # end column no
                 message = "",       # message
                 variableName = "",  # variable name
                 functionName = "",  # function name
                 typeName = None     # type name
                ):
        self.k   = key
        self.c   = certainty
        self.rs  = ruleset
        self.rc  = ruleCode
        self.ec  = errorCode
        self.fid = fileId
        self.sln = startLineNo
        self.scn = startColumnNo
        self.eln = endLineNo
        self.ecn = endColumnNo
        self.m   = message
        self.vn  = variableName
        self.fn  = functionName
        self.tn  = typeName
        self.paths = []

    """
    add a trace path to issue
    """
    def addTracePath(self, path):
        self.paths.append(path)


# Test main
if __name__ == "__main__":
    import json
    ss = Issue("key",
               IssueCertainty.Definitely,
               "ruleset",
               "ruleset-rulecode-1",
               "error code",
               1,
               10,
               11,
               12,
               13,
               "message",
               "variable name",
               "function name",
               "type name"
              )
    ss.addTracePath(TracePath(2,
                              20,
                              21
                             ));
    ss.addTracePath(TracePath(3,
                              30,
                              31,
                              message = "test message",
                              variableName = "variable name",
                              functionName = "function name",
                              typeName = "type name"
                             ));
    ss.addTracePath(TracePath(4,
                              40,
                              41,
                              42,
                              43,
                              message = "test message",
                              variableName = "variable name",
                              functionName = "function name",
                              typeName = "type name"
                             ));
    print (json.dumps(ss, default=lambda o: o.__dict__, indent=1, sort_keys=True))
