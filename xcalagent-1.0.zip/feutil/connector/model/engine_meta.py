#!/usr/bin/env python3
# encoding: utf-8

# Xcalibyte Vulnerability Static Analyzer Java Version 1.0
# Copyright (c) 2018-2019 Xcalibyte Limited
# Confidential under the terms of the NDA between Xcalibyte and the licensee.
# For the use of the licensee only. Internal use only. No redistribution.

# Module Name: engine_meta.py
# definition for engine meta info
# a engine is defined as a service which can load rulesets and scan the code


# Engine
class Engine:
    """
    define meta info for a engine
    """
    def __init__(self,
                 name,               # name of the engine
                 version,            # version of the engine
                 revision,           # revision of the engine
                 description,        # description of the engine
                 languages,          # languages applicable to this engine
                 engine_url = "",    # url to engine webpage
                 provider = "",      # engine provider
                 provider_url = "",  # url to provider webpage
                 license = "",       # license of this engine
                 license_url = "",   # url to license webpage
                 extra_attrs = None  # dict for extra attributes
                ):
        self.name = name
        self.version = version
        self.revision = revision
        self.description = description
        self.languages = languages
        self.engine_url = engine_url
        self.provider = provider
        self.provider_url = provider_url
        self.license = license
        self.license_url = license_url
        self.extra_attrs = extra_attrs
        self.rulesets = []

    """
    add a ruleset to engine
    """
    def addRuleset(self, ruleset):
        self.rulesets.append(ruleset)


"""
test method to test engine
"""
if __name__ == "__main__":
    import json
    ng = Engine("test_engine",
                "1.0",
                "1.0",
                "test engine",
                "c, c++, java",
                "http://company.com/engine/test_engine",
                "company",
                "http://company.com",
                "commercial license",
                "http://company.com/license.html",
                {
                    "update_url": "http://company.com/engine/update?test_engine",
                    "secret" : "AAAABBBBCCCCDDDDEEEEFFFF"
                }
               )
    print (json.dumps(ng, default=lambda o: o.__dict__, indent=1, sort_keys=True))
    ng.addRuleset("test-rule-1")
    ng.addRuleset("test-rule-2")
    print (json.dumps(ng, default=lambda o: o.__dict__, indent=1, sort_keys=True))
