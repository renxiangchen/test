# scanner-connector/model

convert SpotBugs rules and scan results and integrate into xcalibyte framework

SpotBugs: https://spotbugs.github.io/

Prerequisite:
  1. packages needed by python
     
     [option] sudo easy_install generateDS, only needed when re-generate spotbug_desc.py

     [option] sudo pip install openpyxl, only needed if generate Excel output

Resources List:
   bugcollection.xsd: xml description file to describe the elements and attribute in bug report

   findbugs.xml: rule type and categories

   messages.xml: rule description
