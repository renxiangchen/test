#!/usr/bin/env python3
# encoding: utf-8

# Xcalibyte Vulnerability Static Analyzer Java Version 1.0
# Copyright (c) 2018-2019 Xcalibyte Limited
# Confidential under the terms of the NDA between Xcalibyte and the licensee.
# For the use of the licensee only. Internal use only. No redistribution.

# Module Name: meta.py
# convert spotbug rule description to xcalibyte json ouptut
import sys
import os
import getopt
import json
sys.path.append("..")
sys.path.append(".")
 
try:
    import xml.etree.cElementTree as ET
except ImportError:
    import xml.etree.ElementTree as ET
import meta_mapping as RMAP
from model.rule_meta import *
from model.ruleset_meta import *
from model.engine_meta import *
from utils.errors import *

def usage(prog):
    """
    print usage
    """
    print(prog + ": generate spotbug meta json file for Xcalibyte framework")
    print("Usage: " + prog + " -h | -o <output_file>")
    print("  -h: print this usage")
    print("  -o <output_file>: write meta json info into <output_file>")

class Tuples:
    def __init__(self, title = None, tlist = None):
        self.title = title
        self.tlist = tlist

def read_xml(fname):
    """ parse xml file """
    tree = ET.ElementTree(file=fname)
    tuples = Tuples()
    tuples.title = set()
    tuples.tlist = list()
    for elem in tree.iterfind('BugPattern'):
        tuple_elem = dict(elem.attrib)
        for child in elem:
             tuple_elem[child.tag] = child.text
        tuples.tlist.append(tuple_elem)
        if not use_predef_order:
            for key,value in tuple_elem.items():
                tuples.title.update({key})
    return tuples

def merge_tuple(key, tup1, tup2):
    """
    merge elementes from tup2 to tup1 based on key
    """
    tup1.title = tup1.title | tup2.title
    for elem in tup1.tlist:
        keyvalue = elem[key]
        matched = 0
        for elem2 in tup2.tlist:
         if elem2[key] == keyvalue:
             elem.update(elem2)
             matched = 1
        if matched != 1 :
            error_mgr().report_warning("not found key " + keyvalue + " in findbugs.xml, may deprecated")

    
def process_xml(tuples, fixed_title):
    """
    convert tuples into bug description list
    """
    bug_titles = list()
    if use_predef_order:
        bug_titles.extend(fixed_title)
    else:
        for title in tuples.title:
             bug_titles.append(title)
    bug_desc_list.append(bug_titles)
    for element in tuples.tlist:
        bug_desc = list()
        for title in bug_titles:
            if title in element:
                value = element[title].strip()
                bug_desc.append(value.replace("\r","").replace("\n","").replace("<p>","").replace("</p>", ""))
            else:
                bug_desc.append(" ")
        bug_desc_list.append(bug_desc)
    return bug_desc_list

def cvt_2_rule(tuples):
    """
    convert tuples into v format
    """
    ruleSet = Ruleset("builtin",
                      "SpotBugs",
                      "4.0.0",
                      "4.0.0",
                      "SpotBug builtin rules",
                      "java",
                      "https://spotbugs.readthedocs.io/en/latest/bugDescriptions.html",
                      "SpotBugs",
                      "https://spotbugs.github.io/",
                      "GNU Lesser General Public License",
                      "https://www.gnu.org/licenses/lgpl-3.0.html"
                      )
    r_map = RMAP.RuleMapping()
    for element in tuples.tlist:
        rule = Rule(None, None, None , None, "java", None, None, None, None, None, None)
        for key, value in element.items():
            value = value.strip().replace("\r","").replace("\n","").replace("<p>","").replace("</p>", "")
            if(r_map.getMapping(key) != None):
                r_map.map_to_rule(key, value, rule)
        if rule.getCategory() != None :
          ruleSet.addRule(rule)
    return ruleSet
            
def write_json(fname, obj):
    """
    write json to rule files
    """
    try:
        fobj = open(fname, "w")
    except Exception as e:
        sys.stderr.write(str(e) + "\n")
        sys.exit(1)
    fobj.write(json.dumps(obj, default=lambda o: o.__dict__, indent=1, sort_keys=True))
    
def print_xml():
    print(bug_desc_list)

def gen_xslx(data, fname):
    predef_title = ['category', 'abbrev', 'type', 'ShortDescription', 'LongDescription', 'Details', 'deprecated']
    out = process_xml(data1, predef_title)
    write_xslx(fname, out)
    
def write_xslx(fname, bug_desc_list):
    """ write to excle """
    from openpyxl import Workbook
    wb = Workbook()
    ws = wb.active
    for row in bug_desc_list:
        ws.append(row)
    wb.save(fname)

def parse_args():
    global output_file
    output_file = None
    prog_name = os.path.basename(sys.argv[0])
    try:
        options, args = getopt.getopt(sys.argv[1:], "ho:")
        for name, value in options:
            if name == "-h":
                usage(prog_name)
                sys.exit()
            elif name == "-o":
                output_file = value
    except getopt.GetoptError as e:
        sys.stderr.write("Error: " + str(e) + ". Please run `" + prog_name + " -h' for more details.\n")
        sys.exit(1)

    if output_file is None:
        usage(prog_name)
        sys.exit(1)

def driver():
    script_dir = os.path.dirname(os.path.abspath(__file__)) 
    msg_file = os.path.join(script_dir, "resources", "messages.xml")
    rule_desc_file = os.path.join(script_dir, "resources", "findbugs.xml")
    if not os.path.isfile(msg_file) or \
       not os.path.isfile(rule_desc_file) :
        sys.stderr.write("Error: no resource file\n")
        sys.exit(1)

    global use_predef_order
    use_predef_order = False
    data1 = read_xml(msg_file)
    data2 = read_xml(rule_desc_file)
    merge_tuple("type", data1, data2)
    rules = cvt_2_rule(data1)
    ng = Engine("SpotBugs",
                "4.0.0",
                "4.0.0",
                "SpotBugs",
                "java",
                "https://spotbugs.github.io/",
                "SpotBugs",
                "https://spotbugs.github.io/",
                "GNU Lesser General Public License",
                "https://www.gnu.org/licenses/lgpl-3.0.html")
    ng.addRuleset(rules)
    write_json(output_file, ng)

# Test main
if __name__ == "__main__":
    parse_args()
    driver()
