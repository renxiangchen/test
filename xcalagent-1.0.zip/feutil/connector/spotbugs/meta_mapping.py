#!/usr/bin/env python3
# encoding: utf-8

# Xcalibyte Vulnerability Static Analyzer Java Version 1.0
# Copyright (c) 2018-2019 Xcalibyte Limited
# Confidential under the terms of the NDA between Xcalibyte and the licensee.
# For the use of the licensee only. Internal use only. No redistribution.

# Module Name: rule_mapping.py
# define a mapping from spotBug's bug description to Xcalibyte rule description
import sys
class RuleMapping:
    """
    define mapping from spotBugs' rule description to xcalibyte rule description
    """
    Maprule = {
               'type':'name',
               'ShortDescription':'description', 
               'Details':'details',
               'category':'category',
               'cweid':'extra_attrs'
              }
    @staticmethod
    def getMapping(attr):
       return RuleMapping.Maprule.get(attr)

    def map_to_rule(self, key, value, ruleobj):
        default = "default"
        getattr(self, 'case_' + str(key))(ruleobj, value)

    def case_abbrev(self, ruleobj, value):
        ruleobj.setCode(value)

    def case_category(self, ruleobj, value):
        ruleobj.setCategory(value)

    def case_Details(self, ruleobj, value):
        ruleobj.setDetails(value)

    def case_ShortDescription(self, ruleobj, value):
        ruleobj.setSDesc(value)

    def case_type(self, ruleobj, value):
        ruleobj.setName(value)
        ruleobj.setCode(value)

    def case_cweid(self, ruleobj, value):
        emptyObj = {}
        if(ruleobj.getExtraAttrs() == None):
            ruleobj.setExtraAttrs(emptyObj)
        newitem = {'CWE':value}
        ruleobj.addExtraAttrs(newitem)


"""
test method to test RuleMapping
"""
if __name__ == "__main__":
    sys.path.append("..")
    from model.rule_meta import *

    s = RuleMapping()
    rule = Rule("None", "None", "None", "None", "java", "None", "None", "None", "None", "None", "None")
    s.map_to_rule("abbrev", 1, rule)
    print("ruleobj = ", rule.code)
