#!/usr/bin/env python3
# encoding: utf-8

# Xcalibyte Vulnerability Static Analyzer
# Copyright (c) 2018-2019 Xcalibyte Limited
# Confidential under the terms of the NDA between Xcalibyte and the licensee.
# For the use of the licensee only. Internal use only. No redistribution.

# Module Name: scan.py
# scan files in given directory and generate a single xcalibyte json report file

# std library
import os

# connector libraries
from utils import scan_base
from utils import file_utils

# SpotBugScanner
class SpotBugScanner(scan_base.BaseScanner):
    """
    SpotBug scanner
    """

    def __init__(self):
        """
        initialize OclintScanner
        """
        scan_base.BaseScanner.__init__(self)
        self._scanner_output = scan_base.BaseScanner.SCANNER_OUTPUT_FILE

    def _cleanup(self, retcode):
        """
        do cleanup. retcode == 0 means program completed successfully
        """
        if self._keep == True:
            return
        scan_base.BaseScanner._cleanup(self, retcode)

    def _scan_cmd(self):
        """
        reutrn cmd to invoke scanner 
        """
        assert not self._input_dir is None
        assert not self._output_dir is None
        assert not self._script_dir is None

        files = file_utils.find_files(self._input_dir, [ '.zip', '.ear', '.war', '.jar', '.class' ])

        if files is None or len(files) == 0:
            self._logger.info("Warning: no jar/class files found in " + self._input_dir)
            return None

        script_dir = os.path.dirname(os.path.abspath(__file__))
        script_bin = os.path.join(script_dir, "tools", "bin", "spotbugs");
        scan_args = [ script_bin,
                      "-textui",
                      "-xml:withMessages",
                      "-output", self._scanner_output_file  ]
        
        if not self._scanner_opts is None:
            scan_args.extend(self._scanner_opts)
        scan_args.append(self._input_dir)
        return scan_args


    def _conv_cmd(self):
        """
        return cmd to invoke result converter
        """
        assert not self._scanner_output_file is None
        assert not self._final_output_file is None
        assert not self._script_dir is None
        
        # convert oclint result into xcalibyte json format
        script_dir = os.path.dirname(os.path.abspath(__file__))
        conv_args = [ os.path.join(script_dir , "conv.py"),
                      "-i", self._scanner_output_file,
                      "-o", self._final_output_file ]

        return conv_args

def main(argv):
    scanner = SpotBugScanner()
    return scanner.run(argv)

# Test main
if __name__ == "main":
    import sys
    sys.exit(main(sys.argv))
