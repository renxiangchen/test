#!/usr/bin/env python3

#
# Generated Mon Jun  3 11:10:25 2019 by generateDS.py version 2.32.0.
# Python 3.5.2 (default, Nov 12 2018, 13:43:14)  [GCC 5.4.0 20160609]
#
# Command line options:
#   ('-f', '')
#   ('-o', 'spotbug_desc.py')
#   ('-s', 'conv_mapping.py')
#   ('--super', 'spotbug_desc')
#   ('--member-specs', 'list')
#
# Command line arguments:
#   resources/bugcollection.xsd
#
# Command line:
#   /usr/local/bin/generateDS.py -f -o "spotbug_desc.py" -s "conv_mapping.py" --super="spotbug_desc" --member-specs="list" resources/bugcollection.xsd
#
# Current working directory (os.getcwd()):
#   spotbugs
#

import os
import sys
import re
import spotbug_desc as supermod
script_root = os.path.dirname(os.path.abspath(__file__))
script_parent = os.path.dirname(script_root)
sys.path.append(script_parent)
from utils.errors import *
from model.issue  import *
from model.report import *
from utils.file_utils import *
from lxml import etree as etree_


def parsexml_(infile, parser=None, **kwargs):
    if parser is None:
        # Use the lxml ElementTree compatible parser so that, e.g.,
        #   we ignore comments.
        parser = etree_.ETCompatXMLParser()
    try:
        if isinstance(infile, os.PathLike):
            infile = os.path.join(infile)
    except AttributeError:
        pass
    doc = etree_.parse(infile, parser=parser, **kwargs)
    return doc

#
# Globals
#

ExternalEncoding = ''

#
# Data representation classes
#


class FindBugsFilterSub(supermod.FindBugsFilter):
    def __init__(self, Matcher=None, **kwargs_):
        super(FindBugsFilterSub, self).__init__(Matcher,  **kwargs_)
supermod.FindBugsFilter.subclass = FindBugsFilterSub
# end class FindBugsFilterSub


class BugCollectionSub(supermod.BugCollection):
    def __init__(self, version=None, sequence=None, timestamp=None, analysisTimestamp=None, release=None, Project=None, BugInstance=None, BugCategory=None, BugPattern=None, BugCode=None, Errors=None, FindBugsSummary=None, SummaryHTML=None, ClassFeatures=None, History=None, **kwargs_):
        super(BugCollectionSub, self).__init__(version, sequence, timestamp, analysisTimestamp, release, Project, BugInstance, BugCategory, BugPattern, BugCode, Errors, FindBugsSummary, SummaryHTML, ClassFeatures, History,  **kwargs_)
    def convert(self, report_mgr):
        if self.get_analysisTimestamp() is None:
            scanStartTime = int(round(time.time() *1000000))
        else:
            scanStartTime = self.get_analysisTimestamp() * 1000
        report_mgr.report.setScanTaskId("spotbug-scan-" + str(scanStartTime))
        report_mgr.report.setScanTime(scanStartTime, scanStartTime)
        
        if self.get_version() is not None:
            version = self.get_version()
            main_v = version.split("-", 1)
            report_mgr.report.setScanVersion(main_v[0])
            report_mgr.report.setScanRevision(version)

        if self.get_Project() is None:
            error_mgr().report_fatal("Missing project tag")
        else:
            srcdirs = self.get_Project().convert(report_mgr)
            self.get_FindBugsSummary().convert(srcdirs, report_mgr)
            if self.get_BugInstance() is None:
                error_mgr().report_warning("No Bugs found")
            else:
                for item in self.get_BugInstance():
                    item.convert(report_mgr)
        for key, value in report_mgr.fileManager.id2PathMap.items():
            fileInfo = FileInfo(key, value)
            report_mgr.report.addFileInfo(fileInfo)    
 
supermod.BugCollection.subclass = BugCollectionSub
# end class BugCollectionSub


class SourceLineSub(supermod.SourceLine):
    def __init__(self, classname=None, start=None, end=None, startBytecode=None, endBytecode=None, sourcefile=None, sourcepath=None, relSourcepath=None, synthetic=None, role=None, primary=None, Message=None, **kwargs_):
        super(SourceLineSub, self).__init__(classname, start, end, startBytecode, endBytecode, sourcefile, sourcepath, relSourcepath, synthetic, role, primary, Message,  **kwargs_)

    def convert(self, report_mgr, srcInfo):
       if self.start is not None:
           srcInfo.startLine = self.start
       if self.end is not None:
           srcInfo.endLine   = self.end
       if self.sourcepath is not None:
           srcInfo.fileId    = report_mgr.fileManager.GenOrGetId(self.sourcepath)
           srcInfo.filepath  = self.sourcepath
supermod.SourceLine.subclass = SourceLineSub
# end class SourceLineSub


class MatcherTypeSub(supermod.MatcherType):
    def __init__(self, extensiontype_=None, **kwargs_):
        super(MatcherTypeSub, self).__init__(extensiontype_,  **kwargs_)
supermod.MatcherType.subclass = MatcherTypeSub
# end class MatcherTypeSub


class BugMatcherTypeSub(supermod.BugMatcherType):
    def __init__(self, code=None, pattern=None, category=None, **kwargs_):
        super(BugMatcherTypeSub, self).__init__(code, pattern, category,  **kwargs_)
supermod.BugMatcherType.subclass = BugMatcherTypeSub
# end class BugMatcherTypeSub


class ClassMatcherTypeSub(supermod.ClassMatcherType):
    def __init__(self, name=None, role=None, **kwargs_):
        super(ClassMatcherTypeSub, self).__init__(name, role,  **kwargs_)
supermod.ClassMatcherType.subclass = ClassMatcherTypeSub
# end class ClassMatcherTypeSub


class TypeMatcherTypeSub(supermod.TypeMatcherType):
    def __init__(self, descriptor=None, role=None, typeParameters=None, **kwargs_):
        super(TypeMatcherTypeSub, self).__init__(descriptor, role, typeParameters,  **kwargs_)
supermod.TypeMatcherType.subclass = TypeMatcherTypeSub
# end class TypeMatcherTypeSub


class FirstVersionMatcherTypeSub(supermod.FirstVersionMatcherType):
    def __init__(self, value=None, relOp=None, **kwargs_):
        super(FirstVersionMatcherTypeSub, self).__init__(value, relOp,  **kwargs_)
supermod.FirstVersionMatcherType.subclass = FirstVersionMatcherTypeSub
# end class FirstVersionMatcherTypeSub


class LastVersionMatcherTypeSub(supermod.LastVersionMatcherType):
    def __init__(self, value=None, relOp=None, **kwargs_):
        super(LastVersionMatcherTypeSub, self).__init__(value, relOp,  **kwargs_)
supermod.LastVersionMatcherType.subclass = LastVersionMatcherTypeSub
# end class LastVersionMatcherTypeSub


class DesignationMatcherTypeSub(supermod.DesignationMatcherType):
    def __init__(self, designation=None, **kwargs_):
        super(DesignationMatcherTypeSub, self).__init__(designation,  **kwargs_)
supermod.DesignationMatcherType.subclass = DesignationMatcherTypeSub
# end class DesignationMatcherTypeSub


class BugCodeMatcherTypeSub(supermod.BugCodeMatcherType):
    def __init__(self, name=None, **kwargs_):
        super(BugCodeMatcherTypeSub, self).__init__(name,  **kwargs_)
supermod.BugCodeMatcherType.subclass = BugCodeMatcherTypeSub
# end class BugCodeMatcherTypeSub


class LocalMatcherTypeSub(supermod.LocalMatcherType):
    def __init__(self, name=None, **kwargs_):
        super(LocalMatcherTypeSub, self).__init__(name,  **kwargs_)
supermod.LocalMatcherType.subclass = LocalMatcherTypeSub
# end class LocalMatcherTypeSub


class BugPatternMatcherTypeSub(supermod.BugPatternMatcherType):
    def __init__(self, name=None, **kwargs_):
        super(BugPatternMatcherTypeSub, self).__init__(name,  **kwargs_)
supermod.BugPatternMatcherType.subclass = BugPatternMatcherTypeSub
# end class BugPatternMatcherTypeSub


class PriorityMatcherTypeSub(supermod.PriorityMatcherType):
    def __init__(self, value=None, **kwargs_):
        super(PriorityMatcherTypeSub, self).__init__(value,  **kwargs_)
supermod.PriorityMatcherType.subclass = PriorityMatcherTypeSub
# end class PriorityMatcherTypeSub


class RankMatcherTypeSub(supermod.RankMatcherType):
    def __init__(self, value=None, **kwargs_):
        super(RankMatcherTypeSub, self).__init__(value,  **kwargs_)
supermod.RankMatcherType.subclass = RankMatcherTypeSub
# end class RankMatcherTypeSub


class PackageMatcherTypeSub(supermod.PackageMatcherType):
    def __init__(self, name=None, **kwargs_):
        super(PackageMatcherTypeSub, self).__init__(name,  **kwargs_)
supermod.PackageMatcherType.subclass = PackageMatcherTypeSub
# end class PackageMatcherTypeSub


class MethodMatcherTypeSub(supermod.MethodMatcherType):
    def __init__(self, name=None, params=None, returns=None, role=None, **kwargs_):
        super(MethodMatcherTypeSub, self).__init__(name, params, returns, role,  **kwargs_)
supermod.MethodMatcherType.subclass = MethodMatcherTypeSub
# end class MethodMatcherTypeSub


class FieldMatcherTypeSub(supermod.FieldMatcherType):
    def __init__(self, name=None, type_=None, role=None, **kwargs_):
        super(FieldMatcherTypeSub, self).__init__(name, type_, role,  **kwargs_)
supermod.FieldMatcherType.subclass = FieldMatcherTypeSub
# end class FieldMatcherTypeSub


class OrMatcherTypeSub(supermod.OrMatcherType):
    def __init__(self, Matcher=None, **kwargs_):
        super(OrMatcherTypeSub, self).__init__(Matcher,  **kwargs_)
supermod.OrMatcherType.subclass = OrMatcherTypeSub
# end class OrMatcherTypeSub


class AndMatcherTypeSub(supermod.AndMatcherType):
    def __init__(self, Matcher=None, **kwargs_):
        super(AndMatcherTypeSub, self).__init__(Matcher,  **kwargs_)
supermod.AndMatcherType.subclass = AndMatcherTypeSub
# end class AndMatcherTypeSub


class MatchMatcherTypeSub(supermod.MatchMatcherType):
    def __init__(self, classregex=None, class_=None, Matcher=None, **kwargs_):
        super(MatchMatcherTypeSub, self).__init__(classregex, class_, Matcher,  **kwargs_)
supermod.MatchMatcherType.subclass = MatchMatcherTypeSub
# end class MatchMatcherTypeSub


class NotMatcherTypeSub(supermod.NotMatcherType):
    def __init__(self, Matcher=None, **kwargs_):
        super(NotMatcherTypeSub, self).__init__(Matcher,  **kwargs_)
supermod.NotMatcherType.subclass = NotMatcherTypeSub
# end class NotMatcherTypeSub


class ProjectTypeSub(supermod.ProjectType):
    def __init__(self, filename=None, projectName=None, Jar=None, AuxClasspathEntry=None, SrcDir=None, WrkDir=None, Plugin=None, SuppressionFilter=None, Cloud=None, **kwargs_):
        super(ProjectTypeSub, self).__init__(filename, projectName, Jar, AuxClasspathEntry, SrcDir, WrkDir, Plugin, SuppressionFilter, Cloud,  **kwargs_)
    def convert(self, report_mgr):
        return self.SrcDir

supermod.ProjectType.subclass = ProjectTypeSub

# end class ProjectTypeSub


class PluginTypeSub(supermod.PluginType):
    def __init__(self, id=None, enabled=None, **kwargs_):
        super(PluginTypeSub, self).__init__(id, enabled,  **kwargs_)
supermod.PluginType.subclass = PluginTypeSub
# end class PluginTypeSub


class SuppressionFilterTypeSub(supermod.SuppressionFilterType):
    def __init__(self, Matcher=None, **kwargs_):
        super(SuppressionFilterTypeSub, self).__init__(Matcher,  **kwargs_)
supermod.SuppressionFilterType.subclass = SuppressionFilterTypeSub
# end class SuppressionFilterTypeSub


class CloudTypeSub(supermod.CloudType):
    def __init__(self, id=None, online=None, synced=None, detailsUrl=None, Property=None, **kwargs_):
        super(CloudTypeSub, self).__init__(id, online, synced, detailsUrl, Property,  **kwargs_)
supermod.CloudType.subclass = CloudTypeSub
# end class CloudTypeSub


class PropertyTypeSub(supermod.PropertyType):
    def __init__(self, key=None, valueOf_=None, **kwargs_):
        super(PropertyTypeSub, self).__init__(key, valueOf_,  **kwargs_)
supermod.PropertyType.subclass = PropertyTypeSub
# end class PropertyTypeSub

class SourceInfo():
    def __init__(self):
        self.fileId    = -1
        self.filepath  = ""
        self.startLine = 0
        self.endLine   = 0
        self.startCol  = 0
        self.endCol    = 0

class BugInstanceTypeSub(supermod.BugInstanceType):
    def __init__(self, type_=None, priority=None, abbrev=None, category=None, uid=None, reviews=None, firstSeen=None, consensus=None, isInCloud=None, last=None, removedByChange=None, first=None, introducedByChange=None, shouldFix=None, ageInDays=None, notAProblem=None, instanceHash=None, instanceOccurrenceNum=None, instanceOccurrenceMax=None, rank=None, cweid=None, ShortMessage=None, LongMessage=None, Class=None, Type=None, Method=None, SourceLine=None, LocalVariable=None, Field=None, Int=None, String=None, Property=None, UserAnnotation=None, **kwargs_):
        super(BugInstanceTypeSub, self).__init__(type_, priority, abbrev, category, uid, reviews, firstSeen, consensus, isInCloud, last, removedByChange, first, introducedByChange, shouldFix, ageInDays, notAProblem, instanceHash, instanceOccurrenceNum, instanceOccurrenceMax, rank, cweid, ShortMessage, LongMessage, Class, Type, Method, SourceLine, LocalVariable, Field, Int, String, Property, UserAnnotation,  **kwargs_)

    def convert(self, report_mgr):
        certainty = IssueCertainty.SPOTBUG_LOW
        if self.priority is not None :
            if self.priority == 1 :
                certainty = IssueCertainty.SPOTBUG_HIGH
            elif self.priority == 2:
                certainty = IssueCertainty.SPOTBUG_NORMAL

        # if rank is not set, set it to 20(lowest)
        if self.rank is None:
            self.rank = "20"
        ruleset    = "builtin"
        ruleCode   = self.type_
        errorCode = "RANK_" + str(self.rank)

        srcInfos   = list()
        varName    = ""
        methodName = None
        typeName   = None 

        'deprecated ruleCode mapped to new ruleCode'
        deprecatedMapping = {'RCN_REDUNDANT_CHECKED_NULL_COMPARISON': 'RCN_REDUNDANT_COMPARISON_TWO_NULL_VALUES',
                             'DP_DO_INSIDE_DO_PRIVILEDGED': 'DP_DO_INSIDE_DO_PRIVILEGED'}
        if ruleCode in deprecatedMapping :
            ruleCode = deprecatedMapping[ruleCode]

        if self.SourceLine is not None :
            # same error may report on multiple line, add the source info to a list
            for item in self.SourceLine:
                info = SourceInfo()
                item.convert(report_mgr, info)
                srcInfos.append(info)

        if self.LongMessage is None:
            error_mgr().report_warning("BugInstance: no longMessage")
            message = None
        else:
            message = self.LongMessage

        if self.LocalVariable is not None:
            # how do we handle multiple variables? use first variable 
            var_cnt = len(self.LocalVariable)
            if var_cnt > 0:
                item = self.LocalVariable[0]
                varName = item.convert()
                if var_cnt > 1:
                    error_mgr().report_warning("BugInstance: multiple local var entry") 

        if self.Method is not None:
            meth_cnt = len(self.Method)
            # only convert the first method Name
            if meth_cnt > 0:
                item = self.Method[0]
                methodName = item.convert() 

        if self.Type is not None:
            type_cnt = len(self.Type)
            if type_cnt > 0:
               item = self.Type[0]
               typeName = item.convert()
               if type_cnt > 1:
                   error_mgr().report_warning("BugInstance: multiple type entry")

        for srcInfo in srcInfos:
            if srcInfo.fileId == -1:
                error_mgr().report_warning("Ignore fileId -1 for issue: " + str(self))
                continue
            key = srcInfo.filepath  + '@' + \
                  str(srcInfo.startLine) + '@' + \
                  str(srcInfo.startCol)  + '@' + \
                  varName + '@' + \
                  ruleCode
            issue = Issue(key,
                          certainty,
                          ruleset, ruleCode, errorCode,
                          srcInfo.fileId,
                          srcInfo.startLine, srcInfo.startCol,
                          srcInfo.endLine, srcInfo.endCol,
                          message,
                          varName,
                          methodName,
                          typeName)
            issue.addTracePath(TracePath(srcInfo.fileId,
                                         srcInfo.startLine, srcInfo.startCol,
                                         srcInfo.endLine, srcInfo.endCol,
                                         message, varName, methodName, typeName))
            report_mgr.report.addIssue(issue)
        
supermod.BugInstanceType.subclass = BugInstanceTypeSub
# end class BugInstanceTypeSub


class ClassTypeSub(supermod.ClassType):
    def __init__(self, classname=None, role=None, primary=None, SourceLine=None, Message=None, **kwargs_):
        super(ClassTypeSub, self).__init__(classname, role, primary, SourceLine, Message,  **kwargs_)
supermod.ClassType.subclass = ClassTypeSub
# end class ClassTypeSub


class TypeTypeSub(supermod.TypeType):
    def __init__(self, descriptor=None, role=None, typeParameters=None, SourceLine=None, Message=None, **kwargs_):
        super(TypeTypeSub, self).__init__(descriptor, role, typeParameters, SourceLine, Message,  **kwargs_)

    def convert(self):
        if self.descriptor is not None:
            return self.descriptor
        else:
            return ""
supermod.TypeType.subclass = TypeTypeSub
# end class TypeTypeSub


class MethodTypeSub(supermod.MethodType):
    def __init__(self, classname=None, name=None, signature=None, isStatic=None, role=None, primary=None, SourceLine=None, Message=None, **kwargs_):
        super(MethodTypeSub, self).__init__(classname, name, signature, isStatic, role, primary, SourceLine, Message,  **kwargs_)
 
    def convert(self):
        if self.name is not None:
            return self.name
        else:
            return ""

supermod.MethodType.subclass = MethodTypeSub
# end class MethodTypeSub


class LocalVariableTypeSub(supermod.LocalVariableType):
    def __init__(self, name=None, register=None, pc=None, role=None, Message=None, **kwargs_):
        super(LocalVariableTypeSub, self).__init__(name, register, pc, role, Message,  **kwargs_)

    def convert(self):
        if self.name is not None:
            return self.name
        else:
            return ""
supermod.LocalVariableType.subclass = LocalVariableTypeSub
# end class LocalVariableTypeSub


class FieldTypeSub(supermod.FieldType):
    def __init__(self, classname=None, name=None, signature=None, sourceSignature=None, isStatic=None, role=None, primary=None, SourceLine=None, Message=None, **kwargs_):
        super(FieldTypeSub, self).__init__(classname, name, signature, sourceSignature, isStatic, role, primary, SourceLine, Message,  **kwargs_)
supermod.FieldType.subclass = FieldTypeSub
# end class FieldTypeSub


class IntTypeSub(supermod.IntType):
    def __init__(self, value=None, role=None, Message=None, **kwargs_):
        super(IntTypeSub, self).__init__(value, role, Message,  **kwargs_)
supermod.IntType.subclass = IntTypeSub
# end class IntTypeSub


class StringTypeSub(supermod.StringType):
    def __init__(self, value=None, role=None, Message=None, **kwargs_):
        super(StringTypeSub, self).__init__(value, role, Message,  **kwargs_)
supermod.StringType.subclass = StringTypeSub
# end class StringTypeSub


class PropertyType1Sub(supermod.PropertyType1):
    def __init__(self, name=None, value=None, **kwargs_):
        super(PropertyType1Sub, self).__init__(name, value,  **kwargs_)
supermod.PropertyType1.subclass = PropertyType1Sub
# end class PropertyType1Sub


class UserAnnotationTypeSub(supermod.UserAnnotationType):
    def __init__(self, designation=None, user=None, needsSync=None, timestamp=None, valueOf_=None, **kwargs_):
        super(UserAnnotationTypeSub, self).__init__(designation, user, needsSync, timestamp, valueOf_,  **kwargs_)
supermod.UserAnnotationType.subclass = UserAnnotationTypeSub
# end class UserAnnotationTypeSub


class BugCategoryTypeSub(supermod.BugCategoryType):
    def __init__(self, category=None, Description=None, Abbreviation=None, Details=None, **kwargs_):
        super(BugCategoryTypeSub, self).__init__(category, Description, Abbreviation, Details,  **kwargs_)
supermod.BugCategoryType.subclass = BugCategoryTypeSub
# end class BugCategoryTypeSub


class BugPatternTypeSub(supermod.BugPatternType):
    def __init__(self, type_=None, abbrev=None, category=None, cweid=None, ShortDescription=None, Details=None, **kwargs_):
        super(BugPatternTypeSub, self).__init__(type_, abbrev, category, cweid, ShortDescription, Details,  **kwargs_)
supermod.BugPatternType.subclass = BugPatternTypeSub
# end class BugPatternTypeSub


class BugCodeTypeSub(supermod.BugCodeType):
    def __init__(self, abbrev=None, cweid=None, Description=None, **kwargs_):
        super(BugCodeTypeSub, self).__init__(abbrev, cweid, Description,  **kwargs_)
supermod.BugCodeType.subclass = BugCodeTypeSub
# end class BugCodeTypeSub


class ErrorsTypeSub(supermod.ErrorsType):
    def __init__(self, errors=None, missingClasses=None, MissingClass=None, **kwargs_):
        super(ErrorsTypeSub, self).__init__(errors, missingClasses, MissingClass,  **kwargs_)
supermod.ErrorsType.subclass = ErrorsTypeSub
# end class ErrorsTypeSub


class FindBugsSummaryTypeSub(supermod.FindBugsSummaryType):
    def __init__(self, timestamp=None, total_classes=None, referenced_classes=None, total_bugs=None, total_size=None, num_packages=None, java_version=None, vm_version=None, cpu_seconds=None, clock_seconds=None, peak_mbytes=None, alloc_mbytes=None, gc_seconds=None, priority_1=None, priority_2=None, priority_3=None, FileStats=None, PackageStats=None, FindBugsProfile=None, **kwargs_):
        super(FindBugsSummaryTypeSub, self).__init__(timestamp, total_classes, referenced_classes, total_bugs, total_size, num_packages, java_version, vm_version, cpu_seconds, clock_seconds, peak_mbytes, alloc_mbytes, gc_seconds, priority_1, priority_2, priority_3, FileStats, PackageStats, FindBugsProfile,  **kwargs_)

    def convert(self, srcdirs, report_mgr):
        if self.cpu_seconds is not None:
            report_mgr.report.addScanEnd(int(self.cpu_seconds * 1000000))
        if not self.FileStats or self.FileStats is None:
            error_manager.report_warning(ErrorManager.ERR_NO_FILE_STATS)
            return
        for filestat in self.FileStats:
            filestat.convert(srcdirs, report_mgr)
        
supermod.FindBugsSummaryType.subclass = FindBugsSummaryTypeSub
# end class FindBugsSummaryTypeSub


class FileStatsTypeSub(supermod.FileStatsType):
    def __init__(self, path=None, bugCount=None, size=None, bugHash=None, **kwargs_):
        super(FileStatsTypeSub, self).__init__(path, bugCount, size, bugHash,  **kwargs_)

    def convert(self, srcdirs, report_mgr):
       fid = report_mgr.fileManager.GenOrGetIdByFname(self.path)
       fname_with_package = self.path 
       if srcdirs is None or not srcdirs:
           report_mgr.fileManager.AddFilePath(fid, fname_with_package)
       else:
           pathlist = set()
           for item in srcdirs:
               fullpath = os.path.join(item, fname_with_package)
               if os.path.isfile(fullpath):
                   pathlist.add(fullpath)
               else:
                   pathlist = search_relative_file(item, fname_with_package)
           if len(pathlist) != 1:
               error_mgr().report_warning("file " + fname_with_package + " not exits or has multiple entries in dir:" + item)
               report_mgr.fileManager.AddFilePath(fid, self.path)
           else:
               report_mgr.fileManager.AddFilePath(fid, list(pathlist)[0])

supermod.FileStatsType.subclass = FileStatsTypeSub
        
# end class FileStatsTypeSub


class PackageStatsTypeSub(supermod.PackageStatsType):
    def __init__(self, package=None, total_bugs=None, total_types=None, total_size=None, priority_1=None, priority_2=None, priority_3=None, ClassStats=None, **kwargs_):
        super(PackageStatsTypeSub, self).__init__(package, total_bugs, total_types, total_size, priority_1, priority_2, priority_3, ClassStats,  **kwargs_)
supermod.PackageStatsType.subclass = PackageStatsTypeSub
# end class PackageStatsTypeSub


class ClassStatsTypeSub(supermod.ClassStatsType):
    def __init__(self, class_=None, sourceFile=None, interface=None, size=None, bugs=None, priority_1=None, priority_2=None, priority_3=None, **kwargs_):
        super(ClassStatsTypeSub, self).__init__(class_, sourceFile, interface, size, bugs, priority_1, priority_2, priority_3,  **kwargs_)
supermod.ClassStatsType.subclass = ClassStatsTypeSub
# end class ClassStatsTypeSub


class FindBugsProfileTypeSub(supermod.FindBugsProfileType):
    def __init__(self, ClassProfile=None, **kwargs_):
        super(FindBugsProfileTypeSub, self).__init__(ClassProfile,  **kwargs_)
supermod.FindBugsProfileType.subclass = FindBugsProfileTypeSub
# end class FindBugsProfileTypeSub


class ClassProfileTypeSub(supermod.ClassProfileType):
    def __init__(self, name=None, totalMilliseconds=None, invocations=None, avgMicrosecondsPerInvocation=None, maxMicrosecondsPerInvocation=None, maxContext=None, standardDeviationMicrosecondsPerInvocation=None, **kwargs_):
        super(ClassProfileTypeSub, self).__init__(name, totalMilliseconds, invocations, avgMicrosecondsPerInvocation, maxMicrosecondsPerInvocation, maxContext, standardDeviationMicrosecondsPerInvocation,  **kwargs_)
supermod.ClassProfileType.subclass = ClassProfileTypeSub
# end class ClassProfileTypeSub


class ClassFeaturesTypeSub(supermod.ClassFeaturesType):
    def __init__(self, ClassFeatureSet=None, **kwargs_):
        super(ClassFeaturesTypeSub, self).__init__(ClassFeatureSet,  **kwargs_)
supermod.ClassFeaturesType.subclass = ClassFeaturesTypeSub
# end class ClassFeaturesTypeSub


class ClassFeatureSetTypeSub(supermod.ClassFeatureSetType):
    def __init__(self, class_=None, Feature=None, **kwargs_):
        super(ClassFeatureSetTypeSub, self).__init__(class_, Feature,  **kwargs_)
supermod.ClassFeatureSetType.subclass = ClassFeatureSetTypeSub
# end class ClassFeatureSetTypeSub


class FeatureTypeSub(supermod.FeatureType):
    def __init__(self, value=None, **kwargs_):
        super(FeatureTypeSub, self).__init__(value,  **kwargs_)
supermod.FeatureType.subclass = FeatureTypeSub
# end class FeatureTypeSub


class HistoryTypeSub(supermod.HistoryType):
    def __init__(self, AppVersion=None, **kwargs_):
        super(HistoryTypeSub, self).__init__(AppVersion,  **kwargs_)
supermod.HistoryType.subclass = HistoryTypeSub
# end class HistoryTypeSub


class AppVersionTypeSub(supermod.AppVersionType):
    def __init__(self, sequence=None, timestamp=None, release=None, codeSize=None, numClasses=None, **kwargs_):
        super(AppVersionTypeSub, self).__init__(sequence, timestamp, release, codeSize, numClasses,  **kwargs_)
supermod.AppVersionType.subclass = AppVersionTypeSub
# end class AppVersionTypeSub


def get_root_tag(node):
    tag = supermod.Tag_pattern_.match(node.tag).groups()[-1]
    rootClass = None
    rootClass = supermod.GDSClassesMapping.get(tag)
    if rootClass is None and hasattr(supermod, tag):
        rootClass = getattr(supermod, tag)
    return tag, rootClass


def parse(inFilename, silence=False):
    parser = None
    doc = parsexml_(inFilename, parser)
    rootNode = doc.getroot()
    rootTag, rootClass = get_root_tag(rootNode)
    if rootClass is None:
        rootTag = 'FindBugsFilter'
        rootClass = supermod.FindBugsFilter
    rootObj = rootClass.factory()
    rootObj.build(rootNode)
    # Enable Python to collect the space used by the DOM.
    doc = None
    if not silence:
        sys.stdout.write('<?xml version="1.0" ?>\n')
        rootObj.export(
            sys.stdout, 0, name_=rootTag,
            namespacedef_='',
            pretty_print=True)
    return rootObj


def parseEtree(inFilename, silence=False):
    parser = None
    doc = parsexml_(inFilename, parser)
    rootNode = doc.getroot()
    rootTag, rootClass = get_root_tag(rootNode)
    if rootClass is None:
        rootTag = 'FindBugsFilter'
        rootClass = supermod.FindBugsFilter
    rootObj = rootClass.factory()
    rootObj.build(rootNode)
    # Enable Python to collect the space used by the DOM.
    doc = None
    mapping = {}
    rootElement = rootObj.to_etree(None, name_=rootTag, mapping_=mapping)
    reverse_mapping = rootObj.gds_reverse_node_mapping(mapping)
    if not silence:
        content = etree_.tostring(
            rootElement, pretty_print=True,
            xml_declaration=True, encoding="utf-8")
        sys.stdout.write(content)
        sys.stdout.write('\n')
    return rootObj, rootElement, mapping, reverse_mapping


def parseString(inString, silence=False):
    if sys.version_info.major == 2:
        from StringIO import StringIO
    else:
        from io import BytesIO as StringIO
    parser = None
    doc = parsexml_(StringIO(inString), parser)
    rootNode = doc.getroot()
    rootTag, rootClass = get_root_tag(rootNode)
    if rootClass is None:
        rootTag = 'FindBugsFilter'
        rootClass = supermod.FindBugsFilter
    rootObj = rootClass.factory()
    rootObj.build(rootNode)
    # Enable Python to collect the space used by the DOM.
    doc = None
    if not silence:
        sys.stdout.write('<?xml version="1.0" ?>\n')
        rootObj.export(
            sys.stdout, 0, name_=rootTag,
            namespacedef_='')
    return rootObj


def parseLiteral(inFilename, silence=False):
    parser = None
    doc = parsexml_(inFilename, parser)
    rootNode = doc.getroot()
    rootTag, rootClass = get_root_tag(rootNode)
    if rootClass is None:
        rootTag = 'FindBugsFilter'
        rootClass = supermod.FindBugsFilter
    rootObj = rootClass.factory()
    rootObj.build(rootNode)
    # Enable Python to collect the space used by the DOM.
    doc = None
    if not silence:
        sys.stdout.write('#from spotbug_desc import *\n\n')
        sys.stdout.write('import spotbug_desc as model_\n\n')
        sys.stdout.write('rootObj = model_.rootClass(\n')
        rootObj.exportLiteral(sys.stdout, 0, name_=rootTag)
        sys.stdout.write(')\n')
    return rootObj


USAGE_TEXT = """
Usage: python ???.py <infilename>
"""


def usage():
    print(USAGE_TEXT)
    sys.exit(1)


def main():
    args = sys.argv[1:]
    if len(args) != 1:
        usage()
    infilename = args[0]
    parse(infilename)


if __name__ == '__main__':
    #import pdb; pdb.set_trace()
    main()
