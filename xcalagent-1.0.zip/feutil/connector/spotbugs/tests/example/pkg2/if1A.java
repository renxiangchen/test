package pkg2;
interface if1
{
  public void m1(Object obj, if1C obj2);
  public void m2();
}
public class if1A  implements if1
{
  public static void bar(if1 i1, if1C c1) {
    i1.m1(null, c1); 
    c1.var.toString(); // NPD
  }
  public static void bar2(if1 i2, if1C c1) {
    i2.m1(null, c1); 
    c1.var.toString(); // no NPD
  }
 
  public void m1(Object obj, if1C obj2) {



    obj2.toString();
    obj.toString();  // NPD
    obj2.var = null;
  }
  public void m2() {
  }

  public static void driver() {
    if1C c1 = new if1C();
    if1 a1 = new if1A();
    bar(a1, c1);
    if1 b1 = new if1B();
    bar2(b1, c1);
  }
}

class if1B implements if1
{
  public void m1(Object obj, if1C obj2)
  {
    //obj.toString();
    obj2.var="abc";
  }
  public void m2()
  {
  }
}

class if1C
{
  public String var;
}

