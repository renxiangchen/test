#!/usr/bin/env python3
# encoding: utf-8

# Xcalibyte Vulnerability Static Analyzer Java Version 1.0
# Copyright (c) 2018-2019 Xcalibyte Limited
# Confidential under the terms of the NDA between Xcalibyte and the licensee.
# For the use of the licensee only. Internal use only. No redistribution.

# Module Name: conv.py
# convert spotbug xml to xcalibyte json ouptut
import json
import sys
import os
import getopt
import spotbug_desc
import conv_mapping
from model.report import *
from utils.errors import *
from utils.file_manager import *
try:
    import xml.etree.cElementTree as ET
except ImportError:
    import xml.etree.ElementTree as ET

class ReportManager:
    def __init__(self):
        self.create_report()
        self.fileManager = FileManager()

    def create_report(self):
        version      = Report.VERSION
        scanTaskId   = ""      # to be filled with timestamp
        status       = "completed"
        message      = "scan by spotbug"
        scanEngine   = "SpotBugs"
        scanEngineV  = None    # to be filled
        scanCmd      = "spotbugs -xml:withMessages -textui -sourcepath path file"
        scanEnv      = ""
        scanStart    = ""      # to be filled
        scanEnd      = ""      # to be filled
        self.report  = Report(version,
                              scanTaskId, status, message, scanEngine,
                              scanEngineV, scanEngineV, scanCmd,
                              scanEnv, scanStart, scanEnd)
        
def convert_xml(inFilename, report_mgr):
    try:
        doc = spotbug_desc.parsexml_(inFilename)
        rootClass = conv_mapping.BugCollectionSub
        rootObj = rootClass.factory()
        rootNode = doc.getroot()
        rootObj.build(rootNode)
        rootObj.convert(report_mgr)
        scanVersion = report_mgr.report.getScanVersion()
        report_mgr.report.addRuleset(Ruleset("builtin", scanVersion))
        doc = None
    except Exception as e:
        error_mgr().report_fatal(str(e) +  ". parsexml fails\n")

def write_json(report_mgr):
    json_obj = json.dumps(report_mgr, default=lambda o: o.__dict__, indent=1, sort_keys=True)
    try:
        # write report to output_file
        with open(output_file, "w") as ofo:
            json.dump(report_mgr, ofo, default=lambda o: o.__dict__, indent=1, sort_keys=True)
    except IOError as e:
        error_mgr().report_fatal(str(e) + ". Please check if file exists or directory writable.\n")

def usage(prog):
    """
    print usage
    """
    print(prog + ": SpotBug xml result into Xcalibyte json report.")
    print("Usage: " + prog + " -h | -i <input_file> -o <output_file>")
    print("  -h: print this usage")
    print("  -i <input_file>:  load SpotBug xmlresult from <input_file>")
    print("  -o <output_file>: write Xcalibyte json report into <output_file>")

def parse_arg():
    global input_file
    global output_file
    prog_name = os.path.basename(sys.argv[0])
    input_file = None
    output_file = None
    try:
        options, args = getopt.getopt(sys.argv[1:], "hi:o:")
        for name, value in options:
            if name == "-h":
                usage(prog_name)
                sys.exit()
            elif name == "-i":
                input_file = value
            elif name == "-o":
                output_file = value
    except getopt.GetoptError as e:
        error_mgr().report_fatal(str(e) + ". Please run `" + prog_name + " -h' for more details.\n")

    # check if input_file/output_file is specified
    if input_file is None or \
       output_file is None:
        usage(prog_name)
        sys.exit(1)
    if not os.path.isfile(input_file):
        error_mgr().report_fatal("file[" + input_file + "] does not exits\n")

# Test main
if __name__ == "__main__":
    script_root = os.path.dirname(os.path.abspath(__file__))
    script_parent = os.path.dirname(script_root)
    sys.path.append(script_parent)
    sys.path.append(script_root)
    parse_arg()
    report_mgr = ReportManager()
    convert_xml(input_file, report_mgr)
    write_json(report_mgr.report)
