#!/usr/bin/env python3
# encoding: utf-8

# Xcalibyte Vulnerability Static Analyzer Java Version 1.0
# Copyright (c) 2018-2019 Xcalibyte Limited
# Confidential under the terms of the NDA between Xcalibyte and the licensee.
# For the use of the licensee only. Internal use only. No redistribution.

# Module Name: scanner-run.py
# invoke the scanner and convert the result into Xcalibyte report
# usage:
# scanner-run.py -s <scanner> -o <output-file> -l <log-file>

# std library
import getopt
import sys
import os
import subprocess
import traceback

def usage(prog):
    """
    print usage
    """
    print(prog + ": run scanner with input directory")
    print("Usage: " + prog + " -h | -s <scanner> -o <output-file> -l <log-file> <input-dir> -- <extra-scanner-options>")
    print("  -h:               print this usage")
    print("  -s <scanner>:     specify the scanner to be used")
    print("  -o <output-file>: specify the final report file")
    print("  -l <log-file>:    specify the log file")
    print("  <input-dir>:      specify the input directory to be scanned")
    print("  -- <extra-scanner-options>:")
    print("                    extra scanner options to be passed to scanner directly")

# main
if __name__ == "__main__":
    # parse parameters
    prog_name = os.path.basename(sys.argv[0])
    dir_root  = os.path.dirname(os.path.abspath(sys.argv[0]))
    scanner = None
    input_dir = None
    output_file = None
    log_file = None
    keep = False

    try:
        options, args = getopt.getopt(sys.argv[1:], "hks:o:l:")
        for name, value in options:
            if name == "-h":
                usage(prog_name)
                sys.exit(1)
            elif name == "-k":
                keep = True
            elif name == "-s":
                scanner = value
            elif name == "-o":
                output_file = value
            elif name == "-l":
                log_file = value
        input_dir = args[0]

    except Exception as e:
        sys.stderr.write("Error: " + str(e) + ". Please run `" + prog_name + " -h' for more details.\n")
        sys.exit(1)

    if scanner is None or input_dir is None or output_file is None or log_file is None:
        usage(prog_name)
        sys.exit(1)

    scanner_dir = os.path.join(dir_root, scanner)
    scanner_file = os.path.join(scanner_dir, "scan.py")
    if not os.path.isdir(scanner_dir) or not os.path.isfile(scanner_file):
        sys.stderr.write("Error: not find the scanner `" + scanner + "'.\n")
        sys.exit(2)

    try:
        sys.path.append(dir_root)
        sys.path.append(scanner_dir)
        import scan
        cmd_args = [ scanner, "-l", log_file, "-o", output_file ]
        if keep == True:
            cmd_args.append("-k")
        cmd_args.extend(args)
        ret = scan.main(cmd_args)
        sys.exit(ret)
    except Exception as e:
        sys.stderr.write("Error: " + str(e) + ". Please check `" + log_file + "' for more details.\n")
        traceback.print_exc()
        sys.exit(1)

