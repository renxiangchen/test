# scanner-connector/model

convert oclint rules and scan results and integrate into xcalibyte framework

OCLint: http://oclint.org
