#!/usr/bin/env python3
# encoding: utf-8

# Xcalibyte Vulnerability Static Analyzer Java Version 1.0
# Copyright (c) 2018-2019 Xcalibyte Limited
# Confidential under the terms of the NDA between Xcalibyte and the licensee.
# For the use of the licensee only. Internal use only. No redistribution.

# Module Name: oclint_meta.py
# generate oclint meta json file

# std library
import json
import getopt
import sys
import os
import subprocess

ENGINE_JSON_FILE_NAME = "oclint-engine.json"
RULESET_JSON_FILE_NAME = "oclint-ruleset-builtin.json"

def usage(prog):
    """
    print usage
    """
    print(prog + ": generate oclint meta json file for Xcalibyte framework")
    print("Usage: " + prog + " -h | -o <output_file>")
    print("  -h: print this usage")
    print("  -o <output_file>: write meta json info into <output_file>")

# main
if __name__ == "__main__":
    # parse parameters
    prog_name = os.path.basename(sys.argv[0])
    script_dir = os.path.dirname(os.path.abspath(__file__))
    output_file = None
    try:
        options, args = getopt.getopt(sys.argv[1:], "ho:")
        for name, value in options:
            if name == "-h":
                usage(prog_name)
                sys.exit()
            elif name == "-o":
                output_file = value
    except getopt.GetoptError as e:
        sys.stderr.write("Error: " + str(e) + ". Please run `" + prog_name + " -h' for more details.\n")
        sys.exit(1)

    # check if output_file is specified
    if output_file is None:
        usage(prog_name)
        sys.exit(1)

    # check if script_dir contains full oclint binaries
    if not os.path.isfile(os.path.join(script_dir, "tools", "bin", "oclint")) or \
       not os.path.isfile(os.path.join(script_dir, "tools", "bin", "oclint-docgen")) or \
       not os.path.isdir(os.path.join(script_dir, "tools", "lib", "oclint", "rules")):
        sys.stderr.write("Error: `" + script_dir + "' doesn't contain full oclint binaries.\n")
        sys.exit(2)

    output_dir = os.path.dirname(output_file)
    if output_dir == "":
        output_dir = os.getcwd()
    if not os.path.isdir(output_dir):
        sys.stderr.write("Error: `" + output_dir + "' doesn't exist.\n")
        sys.exit(2)

    dg_args = [ os.path.join(script_dir, "tools", "bin", "oclint-docgen"),
                "-report-type",
                "json",
                "-o=" + output_dir,
                "docgen",
                "--" ]

    engine_file = os.path.join(output_dir, ENGINE_JSON_FILE_NAME)
    ruleset_file = os.path.join(output_dir, RULESET_JSON_FILE_NAME)

    dg_ret = subprocess.run(dg_args)
    if dg_ret.returncode != 0:
        sys.stderr.write("Error: failed to run oclint-docgen. ret=" +
                         str(dg_ret.returncode) + "\n")
        if os.path.isfile(engine_file):
            os.remove(engine_file)
        if os.path.isfile(ruleset_file):
            os.remove(ruleset_file)
        sys.exit(3)

    try:
        with open(engine_file, "r") as efo:
            efj = json.load(efo)
            efj["revision"] = efj["version"]
            with open(ruleset_file, "r") as rfo:
                rfj = json.load(rfo)
                rfj["revision"] = rfj["version"]
                rfj["display_name"] = "OCLint" if rfj["name"].lower() == "builtin" \
                                               else rfj["name"]
                efj["rulesets"] = []
                efj["rulesets"].append(rfj)
                with open(output_file, "w") as ofo:
                    json.dump(efj, ofo,
                              default=lambda o: o.__dict__, indent=1, sort_keys=True)
    except Exception as e:
        sys.stderr.write(str(e))
        sys.exit(4)
    finally:
        if os.path.isfile(engine_file):
            os.remove(engine_file)
        if os.path.isfile(ruleset_file):
            os.remove(ruleset_file)

    sys.exit(0)
