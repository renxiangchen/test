#!/usr/bin/env python3
# encoding: utf-8

# Xcalibyte Vulnerability Static Analyzer Java Version 1.0
# Copyright (c) 2018-2019 Xcalibyte Limited
# Confidential under the terms of the NDA between Xcalibyte and the licensee.
# For the use of the licensee only. Internal use only. No redistribution.

# Module Name: conv_result.py
# convert OCLint JSON output to Xcalibyte JSON output

# std library
import json
import getopt
import sys
import os

# convert_trace_path
def convert_trace_path(file_mgr, violation):
    """
    find file, line and col from violation and generate TracePath
    """
    if violation['path'] is None:
        raise AttributeError("no path in violation")
    file_id = file_mgr.GenOrGetId(violation['path'])
    startLineNo   = violation['startLine']
    startColumnNo = violation['startColumn']
    endLineNo     = violation['endLine']
    endColumnNo   = violation['endColumn']
    message       = violation['message']
    return issue.TracePath(file_id,
                           startLineNo, startColumnNo,
                           endLineNo, endColumnNo,
                           message)

# convert_violation
def convert_violation(file_mgr, violation):
    """
    convert OCLint violation into Xcalibyte issue
    """
    if violation['path'] is None:
      raise AttributeError("no path in violation")
    key           = violation['path'] + '@' + \
                    str(violation['startLine']) + '@' + \
                    str(violation['startColumn']) + '@' + \
                    string_utils.sanitize_str(violation['message'])
    certainty     = issue.IssueCertainty.Definitely
    ruleset       = "builtin"
    ruleCode      = violation['rule']
    errorCode     = ruleCode
    fileId        = file_mgr.GenOrGetId(violation['path'])
    startLineNo   = violation['startLine']
    startColumnNo = violation['startColumn']
    endLineNo     = violation['endLine']
    endColumnNo   = violation['endColumn']
    message       = violation['message']
    ise           = issue.Issue(key,
                                certainty,
                                ruleset, ruleCode, errorCode,
                                fileId,
                                startLineNo, startColumnNo,
                                endLineNo, endColumnNo,
                                 message)
    ise.addTracePath(issue.TracePath(fileId,
                                     startLineNo, startColumnNo,
                                     startLineNo, startColumnNo,
                                     message))
    return ise

# convert_clang_sa
def convert_clang_sa(file_mgr, clang_sa):
    """
    convert clang static analyzer into Xcalibyte issue
    """
    key           = clang_sa['path'] + '@' + \
                    str(clang_sa['startLine']) + '@' + \
                    str(clang_sa['startColumn']) + '@' + \
                    string_utils.sanitize_str(clang_sa['message'])
    certainty     = issue.IssueCertainty.Definitely
    ruleset       = "builtin" # TODO: replace by clang-static-analyzer
    ruleCode      = "clang-static-analyzer"
    errorCode     = ruleCode
    fileId        = file_mgr.GenOrGetId(clang_sa['path'])
    startLineNo   = clang_sa['startLine']
    startColumnNo = clang_sa['startColumn']
    message       = clang_sa['message']
    ise           = issue.Issue(key,
                                certainty,
                                ruleset, ruleCode, errorCode,
                                fileId, startLineNo, startColumnNo,
                                0, 0,
                                message)
    ise.addTracePath(issue.TracePath(fileId,
                                     startLineNo, startColumnNo,
                                     0, 0))
    return ise

# convert_report
def convert_report(result):
    """
    find items in result and return report object
    """
    file_mgr      = file_manager.FileManager()
    version       = report.Report.VERSION
    scanTaskId    = "oclint-scan-" + str(result['timestamp'])
    status        = "completed"
    message       = "scan by oclint"
    scanEngine    = "OCLint"
    scanEngineVersion = result['version']
    scanEngineRevision = result['version']
    scanCmd       = "oclint -report-type json -enable-clang-static-analyzer * -- -c"
    scanEnv       = ""
    scanStart     = ""
    scanEnd       = ""
    rpt           = report.Report(version,
                                  scanTaskId, status, message, scanEngine,
                                  scanEngineVersion, scanEngineRevision,
                                  scanCmd, scanEnv, scanStart, scanEnd)

    rpt.addRuleset(report.Ruleset("builtin", scanEngineVersion))

    for violation in result['violation']:
        ret = convert_violation(file_mgr, violation)
        rpt.addIssue(ret)

    for clang_sa in result['clangStaticAnalyzer']:
        ret = convert_clang_sa(file_mgr, clang_sa)
        rpt.addIssue(ret)

    for idx, path in file_mgr.id2path_map().items():
        rpt.addFileInfo(report.FileInfo(idx, path))

    return rpt

def usage(prog):
    """
    print usage
    """
    print(prog + ": convert OCLint json result into Xcalibyte json report.")
    print("Usage: " + prog + " -h | -i <input_file> -o <output_file>")
    print("  -h: print this usage")
    print("  -i <input_file>:  load OCLine json result from <input_file>")
    print("  -o <output_file>: write Xcalibyte json report into <output_file>")

# main
if __name__ == "__main__":
    # parse parameters
    prog_name = os.path.basename(sys.argv[0])
    script_root = os.path.dirname(os.path.abspath(__file__))
    script_parent = os.path.dirname(script_root)
    sys.path.append(script_parent)

    # scanner connector library
    from model import report, issue
    from utils import file_manager, string_utils

    input_file = None
    output_file = None
    try:
        options, args = getopt.getopt(sys.argv[1:], "hi:o:")
        for name, value in options:
            if name == "-h":
                usage(prog_name)
                sys.exit()
            elif name == "-i":
                input_file = value
            elif name == "-o":
                output_file = value
    except Exception as e:
        print ("Error: " + str(e) + ". Please run `" + prog_name + " -h' for more details.")
        sys.exit(1)

    # check if input_file/output_file is specified
    if input_file is None or \
       output_file is None:
        usage(prog_name)
        sys.exit(1)

    # open input file and load as json
    try:
        with open(input_file, "r") as ifo:
            ifj = json.load(ifo)
            # convert into xcalibyte report
            rpt = convert_report(ifj)

            # write report to output_file
            with open(output_file, "w") as ofo:
                json.dump(rpt, ofo,
                          default=lambda o: o.__dict__, indent=1, sort_keys=True)
    except IOError as e:
        print(str(e) + ". Please check if file exists or directory writable.")
        sys.exit(2)
    sys.exit(0)
