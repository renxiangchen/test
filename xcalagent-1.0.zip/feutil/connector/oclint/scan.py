#!/usr/bin/env python3
# encoding: utf-8

# Xcalibyte Vulnerability Static Analyzer
# Copyright (c) 2018-2019 Xcalibyte Limited
# Confidential under the terms of the NDA between Xcalibyte and the licensee.
# For the use of the licensee only. Internal use only. No redistribution.

# Module Name: scan.py
# scan files in given directory and generate a single xcalibyte json report file

# std library
import os
import sys

# connector libraries
from utils import scan_base
from utils import file_utils

# OclintScanner
class OclintScanner(scan_base.BaseScanner):
    """
    OCLint scanner
    """

    def __init__(self):
        """
        initialize OclintScanner
        """
        scan_base.BaseScanner.__init__(self)
        self._scanner_output = scan_base.BaseScanner.SCANNER_OUTPUT_FILE
        self._plist_files = None

    def _cleanup(self, retcode):
        """
        do cleanup. retcode == 0 means program completed successfully
        """
        if self._keep == True:
            return
        scan_base.BaseScanner._cleanup(self, retcode)
        if not self._plist_files is None:
            for plist in self._plist_files:
                if os.path.isfile(plist):
                    os.remove(plist)

    def _scan_cmd(self):
        """
        reutrn cmd to invoke scanner 
        """
        assert not self._input_dir is None
        assert not self._output_dir is None
        assert not self._script_dir is None

        files = file_utils.find_files(self._input_dir, [ '.i', '.ii' ])

        if files is None or len(files) == 0:
            self._logger.info(self._prog_name + " no .i/.ii files found in " + self._input_dir + ".")
            return None

        if self._keep == False and \
           not self._scanner_opts is None and \
           "-enable-clang-static-analyzer" in self._scanner_opts:
            self._plist_files = map(lambda x:
                                        os.path.splitext(os.path.basename(x))[0] + ".plist",
                                    files)

        script_dir = os.path.dirname(os.path.abspath(__file__))
        scan_args = [ os.path.join(script_dir, "tools", "bin", "oclint"),
                      "-report-type",
                      "json",
                      "-o=" + self._scanner_output_file ]
        if not self._scanner_opts is None:
            scan_args.extend(self._scanner_opts)
        scan_args.extend(files)
        scan_args.append("--")
        scan_args.append("-c")

        return scan_args


    def _conv_cmd(self):
        """
        return cmd to invoke result converter
        """
        assert not self._scanner_output_file is None
        assert not self._final_output_file is None
        assert not self._script_dir is None
        
        # convert oclint result into xcalibyte json format
        # See bug 1295, scanner connector invocation error, do not try to directly invoke python script,
        # Instead, put python executable before it
        script_dir = os.path.dirname(os.path.abspath(__file__))
        conv_args = [ os.path.abspath(sys.executable),
                      os.path.join(script_dir, "conv.py"),
                      "-i", self._scanner_output_file,
                      "-o", self._final_output_file ]

        return conv_args

def main(argv):
    scanner = OclintScanner()
    return scanner.run(argv)

# test main
if __name__ == "main":
    import sys
    sys.exit(main(sys.argv))
