#!/usr/bin/env bash

agent_dir=$1
USERNAME=$2
PASSWORD=$3
JOB_QUEUE=$4
SERVER_ADDRESS=$5
SERVER_PORT=$6
AGENT_TYPE=$7

if [ ! ${agent_dir} ]; then
    agent_dir=$(realpath $(dirname $0)/../)
fi

cd $agent_dir

if [ ! -d ${agent_dir}/xcalbuild ] ; then
    echo "Xcalbuild is not found..."
    exit 15
fi

cd $agent_dir
sed -i "s#XCAL_AGENT_TYPE#${AGENT_TYPE}#g" ${agent_dir}/setup.sh

bash -x setup.sh || (echo "Xcalagent setup failed, exit." && exit 1)

sed -i "s#<username>#${USERNAME}#" ${agent_dir}/workdir/run.conf && \
sed -i "s#<password>#${PASSWORD}#" ${agent_dir}/workdir/run.conf && \
sed -i "s#public_default#${JOB_QUEUE}#" ${agent_dir}/workdir/run.conf && \
sed -i "s#127.0.0.1#${SERVER_ADDRESS}#" ${agent_dir}/workdir/run.conf && \
sed -i "s#80#${SERVER_PORT}#" ${agent_dir}/workdir/run.conf && bash -x start.sh
