#
#  Copyright (C) 2019-2020 XC5 Hong Kong Limited, Inc. All Rights Reserved.
#

# =====================================================================================
#
# Globals
#
# =====================================================================================
import os
import platform

AGENT_VERSION = "0.0.15"
arg_cmd_line = {}  # Arguments extracted from command line
gspan = None  # Global Span during whole process
g_err = ()  # Global Error Status
AGENT_LOG_FILE_NAME = "xcalagent.run.log"
os_info = "linux"
if platform.system() == "Windows":
    os_info = "win"

# A Default Configuration / Template for user to override,
# User could write a file to override part of this
DEFAULT_CONFIG = {
    "jaegerPort": None,
    "jaegerHost": None,
    # HTTP Polling interval, 5 is default
    "pollSpan": 5,
    "reconnectSpan": 5,
    # Default Config
    "agentName": "default-agent",
    "agentToken": "04bfe0cffbda602114c336d418cfa37a4c0270fd",
    "matchingScanServiceVersion": ["0.0.13"],  # Version: X.Y.Z or A.B.C->X.Y.Z
    "javaObjectFileVersion": "1.0",
    "skipServerVersionMismatch": "NO",
    "apiServer": {
        "host": "127.0.0.1",
        "port": "80",
        "schema": "http://",
        "loginApi": "/api/auth_service/v2/login",
        "pollApi": "/api/scan_task_service/v3/agent/get_task",
        "progressReportApi": "/api/scan_task_service/v3/agent/progress_report",
        "fileInfoUploadApi": "/api/file_service/v2/file/file_info",
        "scanTaskDiagnosticUploadApi": "/api/scan_service/v2/scan_task/{id}/diagnostic_info",
        "fileDownloadApi": "/api/file_service/v2/file_info/{fileInfoId}/file?token={token}",
        "checkFileCacheApi": "/api/scan_task_service/v2/agent/check_file_cache?token={token}&checksum={fileHash}",
        "saveFileCacheApi": "/api/scan_task_service/v2/agent/save_file_cache?token={token}&checksum={fileHash}&fileId={fileId}",
        "scanServiceVersionApi": "/api/scan_task_service/system/version",
        "createProjectApi": "/api/project_service/v2/project?token={token}",                          # added for offline agent
        "getProjectApi": "/api/project_service/v2/project/project_id/{projectId}/config?token={token}",      # added for offline agent
        "addScanTaskApi": "/api/scan_service/v2/project/{id}/scan_task/{status}?token={token}",  # added for offline agent
        "scanServiceApi": "/api/scan_task_service/v2"    # added for offline agent
},
    "xcalBuildScriptPath": os.path.join("$XCALAGENT", "xcalbuild", os_info, "xcalbuild.py"),
    "xcalAgentInstallDir": "--autofill--",
    "xcalFeUtilityDir": os.path.join("$XCALAGENT", "feutil"),
    # Debug purpose
    "skipXcalBuild": "NO",
    # Debug purpose
    "skipJavaBuild": "NO",
    # LogLevel
    "logLevel": "WARN",
    # Remove preprocess and preprocess.tar.gz before xcalbuild
    "forcePrebuildCleanup": "YES",
    # Whether allowing remote specified removal of preprocess and preprocess.tar.gz before xcalbuild
    "allowPrebuildCleanup": "YES",
    # Remove preprocess after xcalbuild
    "forcePostbuildCleanup": "YES",
    # Whether allowing remote specified removal of preprocess after xcalbuild
    "allowPostbuildCleanup": "YES",
    # Cleanup src after build fileinfo collected
    "allowCleanupSrcDownloaded": "NO",
    # C/C++ Building Options
    "defaultBuildCommand": "make",
    # Java Specifics
    "javaArtifactPatterns": ["*.o", "*.B"],
    # Timeout in seconds
    "javaRuntimeGenTimeout": "600.00",
    "javaPluginTimeout": "600.00",
    "javaScannerConnectorTimeout": "600.0",
    "xcalBuildTimeout": "3600.00",
    # Mocking Runtime Upload, testing purpose only.
    "mockRuntimeUpload": "NO",
    "mockRuntimeFilePath": "",
    "scannerName":"spotbugs",
    # Runtime Object Generation Memory Limit, in MiB
    "runtimeGenMinMemory": "2048",
    "runtimeGenMaxMemory": "3300",
    # Scanner Connector Related Configuration
    "scannerConnectorMaxMemory": "4000",
    "scannerConnectorArgs": "-jvmArgs \"-Xmx$CONNMAXMEMm\" ",
    "forceRuntimeObjectGeneration": "NO",
    # Java Plugin runnning line
    "javaMavenBuildLine": "$BUILDERPATH io.xc5:xvsa-maven-plugin:1.39:gather -Dxvsa.dir=$FEUTILDIR -Dxvsa.phantom=true -Dxvsa.result=$RESULTDIR -Dxvsa.srclist=$SRCLISTFILE -X $EXTRABUILDOPTS",
    "javaGradleBuildLine": "$BUILDERPATH xvsa -PXVSA_HOME=$FEUTILDIR -PXVSA_GRADLE_OUTPUT=$RESULTDIR -PXVSA_SRC_LIST=$SRCLISTFILE --info $EXTRABUILDOPTS",
    "javaDefaultGradleExecPath":"gradle",
    "javaDefaultMavenExecPath":"mvn",
    "javaDefaultExtraOpts": {},
    # Miscellaneous Options
    "srcListFileName": "source_files.json",
    "xcalagent_log_name": "xcalagent.log",
    "xcalbuild_log_name": "xcalbuild.log"
}
