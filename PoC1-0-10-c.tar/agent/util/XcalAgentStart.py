#
#  Copyright (C) 2019-2020 XC5 Hong Kong Limited, Inc. All Rights Reserved.
#

import os
import platform
import sys
import subprocess

INFO = "[INFO]:"
WARN = "[WARNING]:"
ERR = "[ERROR]:"


class XcalAgentStart(object):
    def __init__(self):
        self.current_os = platform.platform()
        self.current_py = sys.executable
        print(INFO, "[CurrentOS]: %s, [PythonInterpreter]: %s" % (self.current_os, self.current_py))

    def subprocess_cmd(self, command):
        process = subprocess.Popen(command, stdout=subprocess.PIPE, shell=True)
        proc_stdout = process.communicate()[0].strip()
        print(proc_stdout)

    def start_agent(self):
        pwd = os.getcwd()  ## TODO:check if pwd is not xcalagent
        agent_dir = os.path.join(pwd, "agent")
        commondef_dir = os.path.join(os.path.join(agent_dir, "commondef"), "src")

        print(INFO, "Starting XcalAgent...")
        fastagent_dir = os.path.join(os.path.join(os.getcwd(), "agent"), "fastagent.py")
        run_conf_dir = os.path.join(os.path.join(os.getcwd(), "workdir"), "run.conf")

        run_cmd = '"%s" "%s" -c "%s"' % (self.current_py, fastagent_dir, run_conf_dir)

        self.subprocess_cmd(run_cmd)


if __name__ == "__main__":
    try:
        start = XcalAgentStart()
        start.start_agent()
    except KeyboardInterrupt as e:
        pass

