#
#  Copyright (C) 2019-2020 XC5 Hong Kong Limited, Inc. All Rights Reserved.
#

import os
import sys
import XcalGlobals
from common.CommonGlobals import TaskErrorNo
from common.XcalException import XcalException
from common.XcalLogger import XcalLogger


class FilePathResolver(object):
    def __init__(self, logger: XcalLogger):
        self.logger = logger

    def get_job_dir(self, global_ctx, job_config):
        job_dir = os.path.join(str(global_ctx.get("xcalAgentInstallDir")),
                               "workdir", "jobs", job_config.get("taskConfig").get("scanTaskId"))
        self.make_sure_usable(job_dir)

        if not os.access(job_dir, os.W_OK | os.R_OK):
            raise XcalException("XcalFileUtility", "get_job_dir", "Job directory %s is not readable/writable" % job_dir,
                                TaskErrorNo.E_FOLDER_PERMISSION_ERROR)
        return str(job_dir)

    def get_precsan_res_save_dir(self, global_ctx, job_config, step_config):
        return self.get_job_dir(global_ctx, job_config)

    def get_upload_dir(self, global_ctx, job_config, one_step):
        return self.get_job_dir(global_ctx, job_config)

    def get_source_temp_dir(self, global_ctx, job_config, one_step):
        src_dir = os.path.join(self.get_job_dir(global_ctx, job_config), "src")
        self.make_sure_usable(src_dir)
        return src_dir

    def get_log_file_path(self, global_ctx, job_config, one_step):
        return os.path.join(self.get_job_dir(global_ctx, job_config), "xcalagent.log")

    def get_download_dir(self, global_ctx, job_config, one_step):
        download_dir = os.path.join(self.get_job_dir(global_ctx, job_config), "download")
        self.make_sure_usable(download_dir)
        return download_dir

    def get_download_temp_file_name(self, global_ctx, job_config, step_config):
        download_dir = self.get_download_dir(global_ctx, job_config, step_config)
        return os.path.join(download_dir, "src.zip")

    def get_xcalbuild_script_path(self, global_ctx):
        default_path = str(global_ctx.get("xcalBuildScriptPath"))
        default_path = default_path.replace("$XCALAGENT", global_ctx.get("xcalAgentInstallDir"))

        if (not os.path.exists(default_path)) or (not os.path.isfile(default_path)):
            raise XcalException("XcalFileUtility", "get_xcalbuild_script_path",
                                "Cannot find XcalBuild script under : %s, please check xcalBuildScriptPath variable "
                                "is set properly" % default_path,
                                TaskErrorNo.E_XCALBUILD_NOT_FOUND)
        return str(default_path)

    def get_preprocessed_tar_path(self, global_ctx, job_config, step_config):
        tarfile_name = step_config.get("outputFileName")
        if tarfile_name is None:
            tarfile_name = "preprocess.tar.gz"
        return os.path.join(self.get_precsan_res_save_dir(global_ctx, job_config, step_config), tarfile_name)

    def get_source_dir(self, global_ctx, job_config, step_config):
        project_path = step_config.get("srcDir")

        if step_config.get("sourceStorageName") != "agent":
            project_path = self.get_source_temp_dir(global_ctx, job_config, step_config)

        if (not os.path.exists(project_path)) or (not os.path.isdir(project_path)):
            raise XcalException("XcalFileUtility", "get_source_dir", "Source code path %s does not exist or is not a directory" % project_path,
                                TaskErrorNo.E_SOURCE_DIRECTORY_NOT_EXIST)

        if not os.access(project_path, os.R_OK):
            raise XcalException("XcalFileUtility", "get_source_dir", "Source code in %s is not readable" % project_path,
                                TaskErrorNo.E_FOLDER_PERMISSION_ERROR)
        return project_path

    def make_sure_usable(self, path):
        if not os.path.exists(path):
            os.makedirs(path)

    # Non-win system use work path, while windows use a project file or work path
    def get_build_work_path(self, global_ctx, job_config, step_config):
        work_path = str(step_config.get("buildMainDir"))

        if step_config.get("sourceStorageName") is not None and step_config.get("sourceStorageName") != "agent":
            if work_path.startswith("/"):
                work_path = "." + work_path
            work_path = os.path.join(self.get_source_temp_dir(global_ctx, job_config, step_config), work_path)
            assert work_path.startswith(self.get_source_temp_dir(global_ctx, job_config, step_config))

        if XcalGlobals.os_info != "win":
            if (not os.path.exists(work_path)) or (not os.path.isdir(work_path)):
                raise XcalException("XcalFileUtility", "get_build_work_path", "Build path %s does not exist or is not a valid directory" % work_path,
                                    TaskErrorNo.E_BUILD_MAIN_DIRECTORY_NOT_EXIST)

            if not os.access(work_path, os.W_OK | os.R_OK):
                raise XcalException("XcalFileUtility", "get_build_work_path", "Build path %s is not readable/writable" % work_path,
                                    TaskErrorNo.E_FOLDER_PERMISSION_ERROR)
        else:
            # when scan projects on windows, build path is a project file or work path.
            if not os.path.exists(work_path):
                raise XcalException("XcalFileUtility", "get_build_work_path",
                                    "Build path %s does not exist" % work_path,
                                    TaskErrorNo.E_BUILD_MAIN_DIRECTORY_NOT_EXIST)

            if not os.access(work_path, os.R_OK):
                raise XcalException("XcalFileUtility", "get_build_work_path", "Build path %s is not readable" % work_path,
                                    TaskErrorNo.E_FOLDER_PERMISSION_ERROR)

        return str(work_path)

    def get_java_log_path(self, global_ctx, job_config, one_step):
        return os.path.join(self.get_job_dir(global_ctx, job_config), "javapreprocess.log")

    def get_scanner_log_path(self, global_ctx, job_config, one_step):
        return os.path.join(self.get_job_dir(global_ctx, job_config), "scanner-connector.log")
    
    def get_java_preprocess_result_dir(self, global_ctx, job_config, step_config, must_exist=True):
        preprocess_dir = os.path.join(self.get_job_dir(global_ctx, job_config), "xvsa-out")
        if not must_exist:
            if not os.path.exists(preprocess_dir):
                os.makedirs(preprocess_dir)

        if (not os.path.exists(preprocess_dir)) or (not os.path.isdir(preprocess_dir)):
            raise XcalException("XcalFileUtility", "get_java_preprocess_result_dir", "output directory not created properly",
                                TaskErrorNo.E_JAVA_PREPROCESS_RESULT_DIR_NOT_EXIST)

        if not os.access(preprocess_dir, os.R_OK | os.W_OK):
            raise XcalException("XcalFileUtility", "get_java_preprocess_result_dir", "Cannot read/write outputDir = %s" %
                                preprocess_dir, TaskErrorNo.E_FE_UTIL_DIR_UNREADABLE)
        return preprocess_dir

    def get_java_jdk_path(self, global_ctx, job_config, step_config):
        java_path = os.getenv("JAVA_HOME")
        if os.path.exists(java_path) and os.path.isdir(java_path):
            return java_path
        else:
            raise XcalException("XcalFileUtility", "get_java_jdk_path", "JAVA_HOME = %s is not set properly" % java_path,
                                TaskErrorNo.E_JAVA_HOME_NOTVALID)

    def get_java_rt_jar_path(self, global_ctx, job_config, step_config):
        rt_jar_path = os.path.join(self.get_java_jdk_path(global_ctx, job_config, step_config), "jre", "lib", "rt.jar")
        if (not os.path.exists(rt_jar_path)) or (not os.access(rt_jar_path, os.R_OK)):
            raise XcalException("XcalFileUtility", "get_java_rt_jar_path", "Runtime.jar = %s is not readable" % rt_jar_path,
                                TaskErrorNo.E_JAVA_RT_JAR_NOT_READABLE)
        return rt_jar_path

    def get_fe_util_base_dir(self, global_ctx, job_config, step_config):
        util_base = global_ctx.get("xcalFeUtilityDir")
        util_base = util_base.replace("$XCALAGENT", global_ctx.get("xcalAgentInstallDir"))
        if (not os.path.exists(util_base)) or (not os.path.isdir(util_base)):
            raise XcalException("XcalFileUtility", "get_fe_util_base_dir", "Cannot locate feutil directory under %s" %
                                util_base, TaskErrorNo.E_FE_UTIL_DIR_NOTFOUND)
        if not os.access(util_base, os.R_OK):
            raise XcalException("XcalFileUtility", "get_fe_util_base_dir", "Cannot read feutil directory under %s" %
                                util_base, TaskErrorNo.E_FE_UTIL_DIR_UNREADABLE)
        return util_base

    def get_fe_util_lib_path(self, global_ctx, job_config, step_config):
        base_dir = self.get_fe_util_base_dir(global_ctx, job_config, step_config)
        lib_path = os.path.join(base_dir, "lib", "1.0")
        if (not os.path.exists(base_dir)) or (not os.path.isdir(base_dir)):
            raise XcalException("XcalFileUtility", "get_fe_util_lib_path", "Cannot locate feutil library directory under %s" %
                                base_dir, TaskErrorNo.E_FE_UTIL_LIB_NOTFOUND)
        if not os.access(base_dir, os.R_OK):
            raise XcalException("XcalFileUtility", "get_fe_util_lib_path", "Cannot read feutil library directory under %s" %
                                base_dir, TaskErrorNo.E_FE_UTIL_LIB_UNREADABLE)
        return lib_path

    def get_fe_util_jar_path(self, global_ctx, job_config, step_config):
        util_lib_dir = self.get_fe_util_lib_path(global_ctx, job_config, step_config)
        jar_path = os.path.join(util_lib_dir, "macbcr.jar")
        if (not os.path.exists(jar_path)) or (not os.path.isfile(jar_path)):
            raise XcalException("XcalFileUtility", "get_fe_util_jar_path", "Cannot locate feutil java jar under %s" %
                                jar_path, TaskErrorNo.E_FE_UTIL_JAR_NOTFOUND)
        if not os.access(jar_path, os.R_OK):
            raise XcalException("XcalFileUtility", "get_fe_util_jar_path", "Cannot read feutil java jar under %s" %
                                jar_path, TaskErrorNo.E_FE_UTIL_JAR_UNREADABLE)
        return jar_path

    def get_fe_util_connector_script_path(self, global_ctx, job_config, step_config):
        util_dir = self.get_fe_util_base_dir(global_ctx, job_config, step_config)
        script_path = os.path.join(util_dir, "connector", "scanner-run.py")
        if (not os.path.exists(script_path)) or (not os.path.isfile(script_path)):
            raise XcalException("XcalFileUtility", "get_fe_util_connector_script_path", "Cannot locate feutil connector script under %s" %
                                script_path, TaskErrorNo.E_FE_UTIL_CONN_NOTFOUND)
        if not os.access(script_path, os.R_OK):
            raise XcalException("XcalFileUtility", "get_fe_util_connector_script_path", "Cannot read feutil connector script under %s" %
                                script_path, TaskErrorNo.E_FE_UTIL_CONN_UNREADABLE)
        return script_path
    
    def get_fe_util_connector_script_dir(self, global_ctx, job_config, step_config):
        util_dir = self.get_fe_util_base_dir(global_ctx, job_config, step_config)
        connect_dir = os.path.join(util_dir, "connector")
        if (not os.path.exists(connect_dir)) or (not os.path.isdir(connect_dir)):
            raise XcalException("XcalFileUtility", "get_fe_util_connector_script_dir", "Cannot locate feutil connector dir under %s" %
                                connect_dir, TaskErrorNo.E_CONNECTOR_NOTFOUND)
        if not os.access(connect_dir, os.R_OK):
            raise XcalException("XcalFileUtility", "get_fe_util_connector_script_dir", "Cannot read feutil connector dir under %s" %
                                connect_dir, TaskErrorNo.FE_CONNECTOR_UNREADABLE)
        return connect_dir
        
    def get_jdk_jar_path(self, global_ctx, job_config, step_config, jar_basename):
        java_dir = self.get_java_jdk_path(global_ctx, job_config, step_config)
        jar_path = os.path.join(java_dir, "jre", "lib", jar_basename)
        if (not os.path.exists(jar_path)) or (not os.path.isfile(jar_path)):
            raise XcalException("XcalFileUtility", "get_jdk_jar_path", "Cannot locate JDK java jar under %s" %
                                jar_path, TaskErrorNo.E_JDK_JAR_NOTFOUND)
        if not os.access(jar_path, os.R_OK):
            raise XcalException("XcalFileUtility", "get_jdk_jar_path", "Cannot read JDK java jar under %s" %
                                jar_path, TaskErrorNo.E_JDK_JAR_UNREADBLE)
        return jar_path

    # This file would be created if not exists
    def get_output_runtime_object_file(self, global_ctx, job_config, step_config):
        work_dir = self.get_job_dir(global_ctx, job_config)
        runtime_object_file = os.path.join(work_dir, "rt.o")
        return runtime_object_file

    # This file would be created if not exists
    def get_runtime_object_tarball_path(self, global_ctx, job_config, step_config):
        work_dir = self.get_upload_dir(global_ctx, job_config, step_config)
        runtime_object_file = os.path.join(work_dir, "rt.tgz")
        return runtime_object_file

    # This file would be created if not exists
    def get_scanner_connector_result_temp_file(self, global_ctx, job_config, step_config):
        work_dir = self.get_upload_dir(global_ctx, job_config, step_config)
        connect_result_file = os.path.join(work_dir, "connector.v")
        return connect_result_file

    # Get Source_files.json path, which is inside upload directory
    def get_src_list_path(self, global_ctx, job_config, step_config):
        work_dir = self.get_upload_dir(global_ctx, job_config, step_config)
        src_list_file = os.path.join(work_dir, global_ctx.get("srcListFileName"))
        return src_list_file

    # Get the executing python path
    def get_python_exec_path(self, global_ctx, job_config, step_config):
        python_path = os.path.abspath(sys.executable)
        return python_path
