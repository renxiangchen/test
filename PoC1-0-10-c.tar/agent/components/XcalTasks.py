#
#  Copyright (C) 2019-2020 XC5 Hong Kong Limited, Inc. All Rights Reserved.
#

import json
import logging
import os
import re
import shlex
import tarfile
import time

import XcalGlobals
from common.CommandLineUtility import CommandLineUtility
from common.CommonGlobals import Stage, Status, Percentage, SOURCE_CODE_ARCHIVE_FILE_NAME, \
    FILE_INFO_FILE_NAME, PREPROCESS_FILE_NAME
from common.CompressionUtility import CompressionUtility
from common.XcalException import XcalException
from common.XcalLogger import XcalLogger
from common.FileUtility import FileUtility

from util.XcalFileUtility import FilePathResolver
from components.XcalConnect import Connector, TaskErrorNo
from components.XcalJavaPrescan import JavaPrescanTask, RuntimeObjectCollectTask, ScannerConnectorTask
from components.XcalCleanupTasks import PrebuildCleanupTask, PostCleanupTask, SourceCodeCleanupTask
from components import XcalFileInfoCollector


class PrebuildTask(object):
    def __init__(self, logger: XcalLogger):
        self.logger = logger
        pass

    def run(self, global_ctx: dict, job_config: dict, step_config: dict):
        pass


class XcalBuildTask(object):
    def __init__(self, logger: XcalLogger):
        self.logger = logger
        pass

    def run(self, global_ctx: dict, job_config: dict, step_config: dict):

        if global_ctx.get("skipXcalBuild") == "YES":
            return

        path_resolver = FilePathResolver(self.logger)
        python_executable = path_resolver.get_python_exec_path(global_ctx, job_config, step_config)
        default_path = path_resolver.get_xcalbuild_script_path(global_ctx)
        work_path = path_resolver.get_build_work_path(global_ctx, job_config, step_config)
        result_dir = path_resolver.get_precsan_res_save_dir(global_ctx, job_config, step_config)
        log_path = path_resolver.get_log_file_path(global_ctx, job_config, step_config)
        default_build_command = global_ctx.get("defaultBuildCommand")

        prepare_command = step_config.get("configureCommand")
        if prepare_command is None:
            prepare_command = ""
        else:
            prepare_command = "-p %s" % (shlex.quote(prepare_command))

        build_command = step_config.get("buildCommand", default_build_command)

        self.logger.debug("System: ", XcalGlobals.os_info)
        if XcalGlobals.os_info == "linux":
            command = "%s %s -i %s -o %s %s %s" % \
                      (shlex.quote(python_executable),
                       shlex.quote(default_path),
                       shlex.quote(work_path),
                       shlex.quote(result_dir),
                       prepare_command,
                       shlex.quote(build_command)
                       )
        else:
            command = "\"%s\" \"%s\" -i \"%s\" -o \"%s\" -c \"%s\"" % \
                      (python_executable,
                       default_path,
                       work_path,
                       result_dir,
                       build_command
                       )

        self.logger.trace("XcalBuildTask", "Run xcalbuild command: %s" % command)
        self.logger.trace("XcalBuildTask", "XcalBuild Log Path: %s" % log_path)

        rc = CommandLineUtility.bash_execute(command,
                                             timeout=float(global_ctx.get("xcalBuildTimeout")),
                                             logfile=log_path, logger=self.logger)
        self.logger.trace("XcalBuildTask", "Finish with %s" % str(rc))
        if rc != 0:
            raise XcalException("XcalBuildTask", "run", "XcalBuild exit with error = %s" % str(rc),
                                TaskErrorNo.E_XCALBUILD_FAIL)

        # Assertion for the directory layout, hard code intentionally
        with tarfile.open(FilePathResolver(self.logger).get_preprocessed_tar_path(global_ctx, job_config, step_config),
                          "r") as tf:
            names = tf.getnames()
            assert len(names) > 0
            assert 'xcalibyte.properties' in names

            i_file_count = 0

            for one_item in names:
                if re.search("\.ii$", one_item) is not None or re.search("\.i$", one_item) is not None:
                    i_file_count += 1

            if i_file_count <= 0:
                raise XcalException("XcalBuildTask", "run",
                                    "No .i/.ii files generated, please check log in %s, or rerun %s" %
                                    (log_path, command), TaskErrorNo.E_NO_I_FILE_GENERATED)


class PrepareFileInfoTask(object):
    def __init__(self, logger: XcalLogger):
        self.logger = logger
        pass

    def run(self, global_ctx: dict, job_config: dict, step_config: dict):
        project_path = FilePathResolver(self.logger).get_source_dir(global_ctx, job_config, step_config)
        dest_path = FilePathResolver(self.logger).get_precsan_res_save_dir(global_ctx, job_config, step_config)

        if not os.path.exists(dest_path):
            raise XcalException("PrepareFileInfoTask", "run", "fileinfo destination folder %s does not exist"
                                % dest_path, TaskErrorNo.E_FILEINFO_FOLDER_NONEXIST)

        self.logger.trace("PrepareFileInfoTask Start ", time.asctime())
        fileinfo_path = XcalFileInfoCollector.generate_file(project_path,
                                                            job_config,
                                                            step_config,
                                                            destination_path = dest_path,
                                                            filename = step_config.get("outputFileName"),
                                                            log = self.logger)
        self.logger.debug("PrepareFileInfoTask Complete ", "file path: %s" % fileinfo_path)
        self.logger.trace("PrepareFileInfoTask Complete ", time.asctime())
        pass


class GitCloneTask(object):
    def __init__(self, logger: XcalLogger):
        self.logger = logger
        pass

    def run(self, global_ctx: dict, job_config: dict, step_config: dict):
        git_url = step_config.get("sourceCodeAddress")
        vcs_token = step_config.get("vcsToken")
        branch = step_config.get("branch")

        log_path = FilePathResolver(self.logger).get_log_file_path(global_ctx, job_config, step_config)
        result_dir = FilePathResolver(self.logger).get_source_temp_dir(global_ctx, job_config, step_config)

        if not os.path.exists(result_dir):
            os.makedirs(result_dir)

        if vcs_token:
            index = git_url.find("//")
            git_url = git_url[:index + 2] + "oauth2:" + vcs_token + "@" + git_url[index + 2:]

        # --single-branch is valid from version 1.7.10(very old) and later.
        # Refer to https://stackoverflow.com/questions/1911109/how-do-i-clone-a-specific-git-branch
        if branch:
            command = "git clone -b %s --single-branch %s %s" % (branch, git_url, result_dir)
        else:
            command = "git clone %s %s" % (git_url, result_dir)

        self.logger.trace("GitCloneTask", "begin %s" % time.asctime())
        self.logger.debug("GitCloneTask", "git clone command: %s" % command)
        self.logger.debug("GitCloneTask", "log path: %s" % log_path)

        rc = CommandLineUtility.bash_execute(command, timeout=float(step_config.get("timeout")),
                                             logfile=log_path, logger=self.logger)
        if rc != 0:
            raise XcalException("GitCloneTask", "run", "git clone failed, please check if git works",
                                TaskErrorNo.E_GIT_CLONE_FAILED)

        self.logger.trace("GitCloneTask", "complete %s" % time.asctime())


class FileDownloadTask(object):
    def __init__(self, logger: XcalLogger):
        self.logger = logger
        pass

    def run(self, global_ctx: dict, job_config: dict, step_config: dict):
        file_id = step_config.get("sourceCodeFileId")
        zip_file = FilePathResolver(self.logger).get_download_temp_file_name(global_ctx, job_config, step_config)

        self.logger.trace("FileDownloadTask", "download start %s" % time.asctime())
        Connector(self.logger).download_file(file_id, zip_file, global_ctx, job_config, step_config)
        self.logger.info("FileDownloadTask", "download complete %s" % time.asctime())

        result_dir = FilePathResolver(self.logger).get_source_temp_dir(global_ctx, job_config, step_config)
        self.logger.info("FileDownloadTask", "decompress start %s" % time.asctime())
        CompressionUtility.extract_file(self.logger, zip_file, result_dir, remove=True)
        self.logger.info("FileDownloadTask", "decompress complete %s" % time.asctime())
        self.logger.trace("FileDownloadTask", "Complete %s" % time.asctime())


class CompressSourceTask(object):
    def __init__(self, logger: XcalLogger):
        self.logger = logger
        pass

    def run(self, global_ctx: dict, job_config: dict, step_config: dict):
        dest_path = FilePathResolver(self.logger).get_precsan_res_save_dir(global_ctx, job_config, step_config)
        if not os.path.exists(dest_path):
            raise XcalException("CompressSourceTask", "run", "destination folder %s to place the source code archive"
                                                             " does not exist" % dest_path, TaskErrorNo.E_FOLDER_NOTEXIST)

        source_code_path = step_config.get("sourceCodePath")
        filename = step_config.get("outputFileName")
        input_filename = step_config.get("inputFileName")
        archive_file_path = CompressionUtility.get_archive(self.logger, filename, source_code_path, input_filename, destination_path=dest_path)
        self.logger.trace("Compress source code complete: ", archive_file_path)
        self.logger.trace("CompressSourceTask Complete: ", time.asctime())


class CppPreScanTask(object):
    def __init__(self, logger: XcalLogger):
        self.logger = logger
        pass

    def run(self, global_ctx: dict, job_config: dict, step_config: dict):
        PrebuildCleanupTask(self.logger).run(global_ctx, job_config, step_config)
        XcalBuildTask(self.logger).run(global_ctx, job_config, step_config)
        PostCleanupTask(self.logger).run(global_ctx, job_config, step_config)
        pass


#   Used by AgentTaskManager
class FileUploadTask(object):
    def __init__(self, logger: XcalLogger):
        self.logger = logger

    def run(self, global_ctx: dict, job_config: dict, one_step: dict):
        self.logger.trace("File Upload Start", (time.asctime(), "file:", one_step.get("filename")))

        resolver = FilePathResolver(self.logger)
        src_dir = resolver.get_upload_dir(global_ctx, job_config, one_step)
        utility = FileUtility(self.logger)
        utility.goto_dir(src_dir)

        if one_step.get("filename") == global_ctx.get('xcalagent_log_name') or one_step.get(
                "filename") == global_ctx.get('xcalbuild_log_name'):
            Connector(self.logger).upload_diagnostic_log(global_ctx, job_config, one_step.get("filename"))
        else:
            upload_result = Connector(self.logger).upload_file(global_ctx, job_config, one_step.get("filename"))

            Connector.append_to_job_config(global_ctx, job_config, one_step, upload_result = upload_result)

            utility.goback_dir()

        self.logger.trace("File Upload Complete ", time.asctime())


class JobLoggerTask(object):
    def __init__(self, logger: XcalLogger):
        self.logger = logger

    def run(self, global_ctx: dict, job_config: dict, one_step: dict):
        log_file = FilePathResolver(self.logger).get_log_file_path(global_ctx, job_config, one_step)
        with open(log_file, "a+") as f:
            f.write(str(time.asctime()) + " -- Job Received, Starting -- ")
            f.write("----------- JOB CONFIG ------------\n")
            f.write(json.dumps(job_config))
            f.write("\n----------- GLOBAL CTX ------------\n")
            f.write(json.dumps(global_ctx))
            f.write("\n-----------------------------------\n")
    pass


class TaskRunner(object):
    def __init__(self, logger: XcalLogger, global_ctx):
        self.global_ctx = global_ctx
        self.logger = logger
        pass

    def async_entry(self, global_ctx, job_config):
        with XcalLogger("TaskRunner", "async_entry", parent=self.logger) as log:
            log.trace("Agent is starting to process tasks ... ", "SCAN-TASK-ID: " + job_config.get("taskConfig").get("scanTaskId"))
            Connector(log).report_status(global_ctx, job_config, Stage.AGENT_START, Status.PROCESSING,
                                         TaskErrorNo.SUCCESS, Percentage.START)
            try:
                self.perform_tasks(global_ctx, job_config, log)
            except XcalException as exp:
                logging.exception(exp)
                log.error("TaskRunner", "error in known issues", (exp.err_code, str(exp.message)))
                Connector(log).report_status(global_ctx, job_config, Stage.AGENT_END, Status.FAILED,
                                             exp.err_code, Percentage.END)
            except BaseException as err:
                logging.exception(err)
                log.error("TaskRunner", "error in unknown exception", str(err))
                Connector(log).report_status(global_ctx, job_config, Stage.AGENT_END, Status.FAILED,
                                             TaskErrorNo.E_SUBPROCESS_FAIL, Percentage.END)

    def perform_tasks(self, global_ctx, job_config, log:XcalLogger):
        JobLoggerTask(self.logger).run(global_ctx, job_config, {})
        report_obj = Connector(log)
        if job_config.get("steps") is not None:
            steps = job_config.get("steps")
            for one_step in steps:
                stage = None
                percentage = Percentage.END
                if one_step.get("type") is None:
                    # This is error handling ...
                    report_obj.report_status(global_ctx, job_config, Stage.AGENT_END, Status.FAILED,
                                             TaskErrorNo.E_JOB_TYPE_NONE, Percentage.END)
                    return
                # TODO: getSourceCode and downloadSourceCode step can be merged into one step
                elif one_step.get("type") == "getSourceCode":
                    #  clone source code ---------------------------------------
                    stage = Stage.FETCH_SOURCE
                    GitCloneTask(self.logger).run(global_ctx, job_config, one_step)
                elif one_step.get("type") == "downloadSourceCode":
                    #  download source code ---------------------------------------
                    stage = Stage.FETCH_SOURCE
                    FileDownloadTask(self.logger).run(global_ctx, job_config, one_step)
                elif one_step.get("type") == "compressSourceCode":
                    #  compress source code to zip file ---------------------------
                    stage = Stage.COMPRESS_SOURCE_CODE
                    CompressSourceTask(self.logger).run(global_ctx, job_config, one_step)
                elif one_step.get("type") == "java":
                    stage = Stage.PRE_PROCESS
                    percentage = Percentage.START
                    JavaPrescanTask(self.logger).run(global_ctx, job_config, one_step)
                elif one_step.get("type") == "runtimeObjectCollect":
                    stage = Stage.PRE_PROCESS
                    percentage = Percentage.MIDDLE
                    RuntimeObjectCollectTask(log).run(global_ctx, job_config, one_step)
                elif one_step.get("type") == "scannerConnector":
                    stage = Stage.PRE_PROCESS
                    percentage = Percentage.END
                    ScannerConnectorTask(log).run(global_ctx, job_config, one_step)
                elif one_step.get("type") == "xcalbuild":
                    stage = Stage.PRE_PROCESS
                    CppPreScanTask(self.logger).run(global_ctx, job_config, one_step)
                elif one_step.get("type") == "upload":
                    if one_step.get("filename") == SOURCE_CODE_ARCHIVE_FILE_NAME:
                        stage = Stage.UPLOAD_SOURCE_CODE
                    elif one_step.get("filename") == FILE_INFO_FILE_NAME:
                        stage = Stage.UPLOAD_FILE_INFO
                    elif one_step.get("filename") == PREPROCESS_FILE_NAME:
                        stage = Stage.UPLOAD_PRE_PROCESS_INFO
                    FileUploadTask(self.logger).run(global_ctx, job_config, one_step)
                elif one_step.get("type") == "prepareFileInfo":
                    stage = Stage.COLLECT_FILE_INFO
                    PrepareFileInfoTask(self.logger).run(global_ctx, job_config, one_step)
                elif one_step.get("type") == "sourceCleanup":
                    stage = Stage.AGENT_END
                    SourceCodeCleanupTask(self.logger).run(global_ctx, job_config, one_step)
                else:
                    # This is error handling ...
                    Connector(log).report_status(global_ctx, job_config, Stage.AGENT_END, Status.FAILED,
                                                 TaskErrorNo.E_JOB_TYPE_UNKNOWN, Percentage.END)
                    return

                if stage is None:
                    # This is error handling ...
                    report_obj.report_status(global_ctx, job_config, Stage.AGENT_END, Status.FAILED,
                                             TaskErrorNo.E_JOB_TYPE_UNKNOWN, Percentage.END)
                    return
                else:
                    report_obj.report_status(global_ctx, job_config, stage, Status.PROCESSING,
                                             TaskErrorNo.SUCCESS, percentage)

            #  All Done ---------------------------------------
            del job_config["steps"]       # remove the steps key/value since this is no use for scan service
            Connector(log).report_result(global_ctx, job_config)
            log.trace("Whole Prescan Finished, Successfully ....", time.asctime())

        else:
            log.error("TaskRunner", "perform_tasks", "Cannot determine the steps to run.... {steps:None}")

    def perform_offline_tasks(self, global_ctx, job_config, log:XcalLogger, call_scan: bool):
        JobLoggerTask(self.logger).run(global_ctx, job_config, {})
        if job_config.get("steps") is not None:
            steps = job_config.get("steps")
            for one_step in steps:
                if one_step.get("type") is None:
                    log.trace("perform_offline_tasks", "wrong step type")
                    exit(1)
                if one_step.get("type") == "getSourceCode":
                    #  clone source code to ---------------------------------------
                    GitCloneTask(self.logger).run(global_ctx, job_config, one_step)
                elif one_step.get("type") == "downloadSourceCode":
                    #  download source code to ---------------------------------------
                    FileDownloadTask(self.logger).run(global_ctx, job_config, one_step)
                elif one_step.get("type") == "compressSourceCode":
                    #  compress source code to zip file ---------------------------------------
                    CompressSourceTask(self.logger).run(global_ctx, job_config, one_step)
                elif one_step.get("type") == "java":
                    JavaPrescanTask(self.logger).run(global_ctx, job_config, one_step)
                elif one_step.get("type") == "xcalbuild":
                    CppPreScanTask(self.logger).run(global_ctx, job_config, one_step)
                elif one_step.get("type") == "runtimeObjectCollect":
                    RuntimeObjectCollectTask(log).run(global_ctx, job_config, one_step)
                elif one_step.get("type") == "scannerConnector":
                    ScannerConnectorTask(log).run(global_ctx, job_config, one_step)
                elif one_step.get("type") == "upload":
                    FileUploadTask(self.logger).run(global_ctx, job_config, one_step)
                elif one_step.get("type") == "prepareFileInfo":
                    PrepareFileInfoTask(self.logger).run(global_ctx, job_config, one_step)
                elif one_step.get("type") == "sourceCleanup":
                    SourceCodeCleanupTask(self.logger).run(global_ctx, job_config, one_step)
                else:
                    log.trace("perform_offline_tasks", "wrong step type")
                    exit(1)

            #  All Done ---------------------------------------
            # Connector(log).report_result(global_ctx, job_config)
            log.debug("perform_offline_tasks", "after all the jobs done, job config: %s" % job_config)
            if call_scan:
                Connector(log).call_scan_service(global_ctx, job_config)
            return job_config
        else:
            log.error("TaskRunner", "perform_offline_tasks", "Cannot determine the steps to run.... {steps:None}")
            exit(1)



