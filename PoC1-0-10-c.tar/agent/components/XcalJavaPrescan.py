#
#  Copyright (C) 2019-2020 XC5 Hong Kong Limited, Inc. All Rights Reserved.
#

import glob
import logging
import os
import shutil
import tarfile
import tempfile
import json

from common.CommandLineUtility import CommandLineUtility
from common.CompressionUtility import CompressionUtility
from common.ConfigObject import ConfigObject
from common.HashUtility import HashUtility
from common.XcalException import XcalException
from common.CommonGlobals import TaskErrorNo
from common.XcalLogger import XcalLogger
from common.FileUtility import FileUtility

from components.XcalCleanupTasks import PrebuildCleanupTask, PostCleanupTask
from components.XcalConnect import Connector
from util.XcalFileUtility import FilePathResolver


class JavaPrescanTask(object):
    def __init__(self, logger: XcalLogger):
        self.logger = logger

    def run(self, global_ctx: dict, job_config: dict, step_config: dict):
        """
        Perform a series of tasks,
        PrebuildCleanupTask
        PluginInvokeTasks
        CollectMiddleResultTasks
        PostCleanupTask
        :param global_ctx:
        :param job_config:
        :param step_config:
        :return:
        """
        self.logger.trace("Starting Java Prescan Task", "")

        if global_ctx.get("skipJavaBuild") == "YES":
            self.logger.trace("Skipping Prescan Task", "")
            return

        PrebuildCleanupTask(self.logger).run(global_ctx, job_config, step_config)
        if global_ctx.get("javaMockCompile", "NO") == "YES":
            shutil.copy(global_ctx.get("javaPrecompiled"),
                        FilePathResolver(self.logger).get_preprocessed_tar_path(global_ctx, job_config, step_config))
        else:
            PluginInvokeTasks(self.logger).run(global_ctx, job_config, step_config)
            CollectMiddleResultTasks(self.logger).run(global_ctx, job_config, step_config)
        PostCleanupTask(self.logger).run(global_ctx, job_config, step_config)

        self.logger.trace("Java Prescan Finished", ())


class PluginInvokeTasks(object):
    def __init__(self, logger: XcalLogger):
        self.logger = logger

    def run(self, global_ctx: dict, job_config: dict, step_config: dict):
        """
        Invoke Maven plugins with default parameters
        :param global_ctx:
        :param job_config:
        :param step_config:
        :return:
        """
        resolver = FilePathResolver(self.logger)
        build_line = self.prepare_build_info(global_ctx, job_config, step_config)
        work_path = resolver.get_build_work_path(global_ctx, job_config, step_config)
        new_env = self.prepare_build_environment(global_ctx, job_config, step_config)

        self.logger.info("Invoking Maven ", ("Maven Build Line:", build_line, "Work Dir:", work_path))
        utility = FileUtility(self.logger)
        utility.goto_dir(work_path)

        out_fn = FilePathResolver(self.logger).get_java_log_path(global_ctx, job_config, step_config)
        self.logger.trace("Invoking Maven process to files", ("invocation line:", build_line, "out:", out_fn,
                                                              "workdir:", work_path))
        try:
            # Run subprocess, if jaeger is enabled, use it, otherwise, directly invoke
            utility.goto_dir(work_path)
            p = CommandLineUtility.bash_execute(build_line, timeout=float(global_ctx.get("javaPluginTimeout")),
                                        logfile=out_fn, logger=self.logger, environment=new_env)
            utility.goback_dir()
            if p != 0:
                raise XcalException("PluginInvokeTasks", "run", "Plugin (Java build tool) run into error",
                                    TaskErrorNo.E_PLUGIN_RETURN_NONZERO)
        except KeyboardInterrupt as e:
            raise e
        except BaseException as e:
            logging.exception(e)
            raise XcalException("PluginInvokeTasks", "run", "Due to unacceptable error", TaskErrorNo.E_PLUGIN_EXEC_ERR)

        # Calculating the output and error file size
        out_size = 0
        if os.path.isfile(out_fn):
            out_size = os.path.getsize(out_fn)

        utility.goback_dir()

        # Report Status
        self.logger.info("Preprocess process finished", ("Exit code:", p, "Out Size:", out_size))

    def prepare_build_info(self, global_ctx, job_config, step_config):
        """
        Prepare build line
        :param global_ctx:
        :param job_config:
        :param step_config:
        :return:
        """
        resolver = FilePathResolver(self.logger)

        # See if there is project-specific config for overrider mvnw/gradlew
        # See if there is project-specific config for Extra Maven option
        task_config = job_config.get("taskConfig", {})
        user_config = task_config.get("configContent", {})
        extra_build_opts = user_config.get("extraBuildOpts", "")
        builder_path = user_config.get("builderPath", "$ORIGINAL_BUILDER")
        build_cmd = str(step_config.get("buildCommand", "nil-None")).lower()

        if build_cmd == "maven" or build_cmd == "mvn":
            build_line = global_ctx.get("javaMavenBuildLine")
            default_builder_path = global_ctx.get("javaDefaultMavenExecPath")
        elif build_cmd == "gradle":
            build_line = global_ctx.get("javaGradleBuildLine")
            default_builder_path = global_ctx.get("javaDefaultGradleExecPath")
        else:
            raise XcalException("PluginInvokeTasks", "prepare_build_info",
                                "Cannot determine runner for prescan plugin = %s" % build_cmd,
                                TaskErrorNo.E_JAVA_PRESCAN_PLUGIN_NOT_VIABLE)
        temp_res = build_line
        temp_res = temp_res.replace("$FEUTILDIR", resolver.get_fe_util_base_dir(global_ctx, job_config, step_config))
        temp_res = temp_res.replace("$RESULTDIR", resolver.get_java_preprocess_result_dir(global_ctx, job_config,
                                                                                          step_config,
                                                                                          must_exist=False))
        temp_res = temp_res.replace("$SRCLISTFILE", resolver.get_src_list_path(global_ctx, job_config, step_config))
        temp_res = temp_res.replace("$BUILDERPATH", builder_path)
        temp_res = temp_res.replace("$ORIGINAL_BUILDER", default_builder_path)
        temp_res = temp_res.replace("$EXTRABUILDOPTS", extra_build_opts)
        self.logger.trace("Composed command-line to run : %s" % temp_res, "")
        return temp_res

    def prepare_build_environment(self, global_ctx, job_config, step_config):
        # Add Maven Opts for including into the
        task_config = job_config.get("taskConfig", {})
        user_config = task_config.get("configContent", {})
        step_config["extraEnvOpts"] = user_config.get("extraEnvOpts", "{}")
        try:
            user_specified_opts = json.loads(step_config["extraEnvOpts"])
        except Exception:
            raise XcalException("PluginInvokeTasks", "prepare_build_environment", "Cannot parse user specified extraEnvOpts",
                                err_code=TaskErrorNo.E_JAVA_PARSE_USER_ENVOPT)

        system_env_opts = os.environ.copy()
        default_opts = global_ctx.get("javaDefaultExtraOpts", {})
        combined_default_opt = ConfigObject.merge_two_dicts(system_env_opts, default_opts)
        result_opts = ConfigObject.merge_two_dicts(combined_default_opt, user_specified_opts)

        return result_opts


class CollectMiddleResultTasks(object):

    def __init__(self, logger: XcalLogger):
        self.logger = logger

    def run(self, global_ctx, job_config, step_config):
        """
        Collect the result from Maven/Gradle Plugins
        :param global_ctx:
        :param job_config:
        :param step_config:
        :return:
        """
        with XcalLogger("CollectMiddleResultTasks", "run", parent=self.logger) as log:

            utility = FilePathResolver(self.logger)
            artifact_patterns = global_ctx.get("javaArtifactPatterns")

            artifact_root = utility.get_java_preprocess_result_dir(global_ctx, job_config, step_config)
            tarball_fn = utility.get_preprocessed_tar_path(global_ctx, job_config, step_config)

            log.info("Prescan params", {})

            if not os.path.isdir(artifact_root):
                raise XcalException("CollectMiddleResultTasks", "run",
                                    ("Cannot locate the artifact root", "artifact_root = %s" % artifact_root),
                                    TaskErrorNo.E_PRESCAN_RESULT_DIR_NONEXIST)

            # Split the patterns in
            viable_fn_list = []

            # Compressing Artifacts into the zip file
            for item in artifact_patterns:
                whole_pattern = os.path.join(artifact_root, item)
                log.debug("Globbing with pattern", whole_pattern)
                file_list = glob.glob(whole_pattern, recursive=False)
                if len(file_list) > 0:
                    for one in file_list:
                        viable_fn_list.append(one)

            if len(viable_fn_list) <= 0:
                raise XcalException("CollectMiddleResultTasks", "run",
                                    ("Cannot locate any artifact file with root = ", artifact_root, ", patterns = ",
                                     artifact_patterns,
                                     "please set a viable artifact root to javaArtifactRoot, and javaArtifactPattern"),
                                    TaskErrorNo.E_NO_VIABLE_MIDDLE_RESULT)

            log.info("Pattern match complete", ("Viable files/dirs =", viable_fn_list))

            try:
                utility.get_precsan_res_save_dir(global_ctx, job_config, step_config)

                # Count = 0
                count = 0
                with tarfile.open(tarball_fn, "w:gz") as tf, tempfile.NamedTemporaryFile("w+") as tmp:
                    for one in viable_fn_list:
                        # Adding one file
                        count += 1
                        log.info("Add file to archive", (one, "as", os.path.join("java.scan", os.path.basename(one))))
                        tf.add(one, os.path.join("java.scan", os.path.basename(one)))

                    # Add a single file
                    tmp.write("version=1.0\n" +
                              "project=make_default\n" +
                              "project_key=make_default\n" +
                              "build_command=make\n" +
                              "linker=cc\n" +
                              "count=" + str(count) + "\n" +
                              "xc5_root_dir=/home/xc5/agent_test/bin/..\n")
                    tmp.seek(0)
                    tf.add(tmp.name, "java.scan/xcalibyte.properties")

            except FileNotFoundError as err:
                raise XcalException("CollectMiddleResultTasks", "run",
                                    "Error when collecting processed files, %s" % str(err),
                                    TaskErrorNo.E_NOT_FOUND_FILE)

            log.info("Dumping preprocess file complete", ("Archive saved to = ", tarball_fn))


class RuntimeObjectCollectTask(object):
    RUNTIME_JAR = "RUNTIME_JAR"

    def __init__(self, logger: XcalLogger):
        self.logger = logger
        pass

    def run(self, global_ctx: dict, job_config: dict, step_config: dict):
        """
        Collect Runtime Object,
        Get the hash of rt.jar,
        If this file was cached, return the rt.tgz's file-Id
        Otherwise, Perform a series of tasks:
        RunJavaFronEndTask
        CollectJavaFrontEndResultTask
        FileUploadTask
        And save file cache
        :param global_ctx:
        :param job_config:
        :param step_config:
        :return:
        """

        util = FilePathResolver(self.logger)
        java_path = util.get_java_jdk_path(global_ctx, job_config, step_config)
        self.logger.trace("resolved JAVA_HOME = %s" % java_path, "")

        rt_jar_path = util.get_java_rt_jar_path(global_ctx, job_config, step_config)
        self.logger.trace("resolved rt.jar = %s" % rt_jar_path, "")

        hash_result = HashUtility.get_sha1_hash(rt_jar_path)
        self.logger.trace("calculated hash(of rt.jar) = %s" % hash_result, "")

        hash_result = "%s-%s" % (hash_result, global_ctx.get("javaObjectFileVersion", "N"))

        # Grabbing the version string from the file
        self.convert_library_and_upload(global_ctx, job_config, step_config,
                                        library_name=RuntimeObjectCollectTask.RUNTIME_JAR,
                                        library_version=hash_result)

    def upload_file_cache(self, global_ctx:dict, job_config:dict, step_config:dict,
                          library_version:str, library_name:str = "Unknown"):

        from components.XcalTasks import FileUploadTask

        FileUploadTask(self.logger).run(global_ctx, job_config, step_config)
        file_res = Connector.extract_upload_result(global_ctx, job_config, step_config)
        if file_res is None or file_res.get("fileId") is None:
            raise XcalException("RuntimeObjectCollectTask", "upload_file_cache",
                                "cannot the uploaded file's ID in uploadResult",
                                TaskErrorNo.E_SAVE_FILE_ID_NOT_FOUND)
        file_id = file_res.get("fileId")
        # Upload to server
        try:
            result = Connector(self.logger).save_file_cache(global_ctx, job_config, step_config, library_version, file_id)
            if result.get("status", "fail") != "ok":
                raise XcalException("RuntimeObjectCollectTask", "upload_file_cache",
                                    "With mock result uploaded, but we cannot save the cache info to the server",
                                    TaskErrorNo.E_SAVE_FILE_CACHE_SERVER_FAIL)
        except Exception as err:
            logging.debug(err)
            self.logger.warn("server responded that saving the cached result file failed", "")
        pass

    def convert_library_and_upload(self, global_ctx, job_config, step_config, library_name:str, library_version:str):
        """
        Upload the libary's object file to the server.
        :param global_ctx:
        :param job_config:
        :param step_config:
        :param library_name:
        :param library_version:
        :return:
        """
        try:
            result = Connector(self.logger).check_file_cache(global_ctx, job_config, step_config, library_version)
            if result is None or result.get("status") is None:
                # Maybe this is a non-admin user.
                raise XcalException("RuntimeObjectCollectTask", "convert_library_and_upload",
                                    "ScanService response information cannot be used to check file checksum",
                                    TaskErrorNo.E_CHECK_CACHE_FILE_FAILED)
        except Exception as e:
            logging.debug(e)
            self.logger.warn("unable to contact server to find cached files", "")

            # Rewrite with failure results
            result = {"status": "none"}

        if result.get("status") == "existing" and global_ctx.get("forceRuntimeObjectGeneration", "NO") == "NO":
            # Existing rt.jar, return with cached remote file
            file_id = result.get("fileId")
            if file_id is None:
                raise XcalException("RuntimeObjectCollectTask", "convert_library_and_upload",
                                    "server responded to a cache check with invalid file-id, checksum = %s",
                                    TaskErrorNo.E_CHECK_CACHE_NONE_FILEID)
            self.logger.trace("server reported a matching/existing file with hash = %s, fileId = %s" %
                              (library_version, file_id), "")
            Connector.append_to_job_config(global_ctx, job_config, step_config, file_id=file_id)
            return

        self.logger.trace("server reported no matching/existing file with hash = %s found" % library_version +
                          "running preprocess to regenerate this", "")

        if global_ctx.get("mockRuntimeUpload", "NO") == "YES" and \
           global_ctx.get("forceRuntimeObjectGeneration", "NO") == "NO":
            old_file_path = global_ctx.get("mockRuntimeFilePath", "")
            tarball_path = FilePathResolver(self.logger).get_runtime_object_tarball_path(global_ctx, job_config,
                                                                                         step_config)
            self.logger.trace("mocking runtime already uploaded, copy old_file_path = %s to new_path = %s" % (
            old_file_path, tarball_path), "")

            # Copy to upload folder and upload the file.
            shutil.copy(old_file_path, tarball_path)

            # Writing to the name for upload task to ingest
            step_config["filename"] = os.path.basename(tarball_path)

        else:
            # Really generating the runtime-library
            RunJavaFronEndTask(self.logger).run(global_ctx, job_config, step_config)
            
            # There's an implicit write to step_config['filename'] in here:
            CollectJavaFrontEndResultTask(self.logger).run(global_ctx, job_config, step_config)

        self.upload_file_cache(global_ctx, job_config, step_config, library_version, RuntimeObjectCollectTask.RUNTIME_JAR)
        self.logger.trace("RuntimeObjectCollectTask completed for library %s, version = %s" % (library_name, library_version), "")


class RunJavaFronEndTask(object):
    def __init__(self, logger: XcalLogger):
        self.logger = logger
        pass

    def run(self, global_ctx, job_config, step_config):
        """
        Perform Java frontend job invocation, mainly for generating the runtime object
        :param global_ctx:
        :param job_config:
        :param step_config:
        :return:
        """
        utility = FilePathResolver(self.logger)
        log = XcalLogger("RunJavaFronEndTask", "run", parent=self.logger)

        library_path = utility.get_fe_util_lib_path(global_ctx, job_config, step_config)
        frontend_jar = utility.get_fe_util_jar_path(global_ctx, job_config, step_config)
        java_path = utility.get_java_jdk_path(global_ctx, job_config, step_config)
        object_result_path = utility.get_output_runtime_object_file(global_ctx, job_config, step_config)
        mem_min = global_ctx.get("runtimeGenMinMemory")
        mem_max = global_ctx.get("runtimeGenMaxMemory")
        self.logger.trace("resolved JAVA_HOME = %s" % java_path, "min memory = %s, max memory = %s" % (mem_min, mem_max))

        build_line = "java -Xms%sm -Xmx%sm -Djava.library.path=%s -ea -jar " \
                     "%s " \
                     "-noSootOutput=true -VTABLE=true " \
                     "-cp=%s " \
                     "-cp=%s " \
                     "-fC,%s " \
                     "-fB,%s" % \
                     (mem_min,
                      mem_max,
                      library_path,
                      frontend_jar,
                      utility.get_jdk_jar_path(global_ctx, job_config, step_config, "jsse.jar"),
                      utility.get_jdk_jar_path(global_ctx, job_config, step_config, "charsets.jar"),
                      utility.get_jdk_jar_path(global_ctx, job_config, step_config, "rt.jar"),
                      object_result_path)

        out_fn = utility.get_java_log_path(global_ctx, job_config, step_config)
        self.logger.trace("Invoking JFE, saving logs to files", ("invocation line:", build_line, "out:", out_fn))

        # Run subprocess, if jaeger is enabled, use it, otherwise, directly invoke
        p = CommandLineUtility.bash_execute(build_line, timeout=float(global_ctx.get("javaRuntimeGenTimeout")),
                                        logfile=out_fn, logger=log)
        if p != 0:
            raise XcalException("RunJavaFronEndTask", "run", "Error occurred in Java Front End invocation, exit = %d" % p,
                                TaskErrorNo.E_JFE_RETURN_NONZERO)

        self.logger.trace("JFE returned successfully with exit = 0, continuing.", "log in %s" % out_fn)


class CollectJavaFrontEndResultTask(object):
    def __init__(self, logger: XcalLogger):
        self.logger = logger
        pass

    def run(self, global_ctx, job_config, step_config):
        """
        Collect Java Preprocess Result and compress .o files to tgz archive
        :param global_ctx:
        :param job_config:
        :param step_config:
        :return:
        """
        utility = FilePathResolver(self.logger)
        object_result_path = utility.get_output_runtime_object_file(global_ctx, job_config, step_config)
        tarball_path = utility.get_runtime_object_tarball_path(global_ctx, job_config, step_config)

        if (not os.path.exists(object_result_path)) or (not os.path.isfile(object_result_path)):
            raise XcalException("RunJavaFronEndTask", "run",
                                "Runtime Object was not generated properly, please check JFE log",
                                TaskErrorNo.E_RT_OBJ_NON_EXIST)

        self.logger.trace("Found Runtime.o in %s, Compressing to %s" % (object_result_path, tarball_path), "")

        CompressionUtility.compress_tar_package(self.logger, object_result_path, tarball_path)
        if (not os.path.exists(tarball_path)) or (not os.path.isfile(tarball_path)):
            raise XcalException("CollectJavaFrontEndResultTask", "run", "Failed to compress the runtime object tarball %s, "
                                                             "not-existing tarball" % tarball_path,
                                TaskErrorNo.E_RT_TAR_NOT_EXIST)

        step_config["filename"] = os.path.basename(tarball_path)


class ScannerConnectorInvokerTask(object):
    def __init__(self, logger: XcalLogger):
        self.logger = logger
        pass

    def run(self, global_ctx, job_config, step_config):
        """
        Invoke Scanner Connector via shell and save the log to preprocess.log
        :param global_ctx:
        :param job_config:
        :param step_config:
        :return:
        """
        utility = FilePathResolver(self.logger)
        log = XcalLogger("ScannerConnectorInvokerTask", "run", parent=self.logger)

        python_executable = utility.get_python_exec_path(global_ctx, job_config, step_config)
        connector_script = utility.get_fe_util_connector_script_path(global_ctx, job_config, step_config)
        connector_dir = utility.get_fe_util_connector_script_dir(global_ctx, job_config, step_config)
        scanner_name = global_ctx.get("scannerName")
        temp_file_path = utility.get_scanner_connector_result_temp_file(global_ctx, job_config, step_config)
        scanner_log_fn = utility.get_scanner_log_path(global_ctx, job_config, step_config)
        source_path = utility.get_build_work_path(global_ctx, job_config, step_config)

        # There is a per-agent config item to specify the maximum memory usage
        default_max_memory = global_ctx.get("scannerConnectorMaxMemory")

        # If user specified a max memory limit on the UI input, we should use it first.
        if job_config.get("taskConfig", {}).get("configContent", {}).get("scannerConnectorMaxMemory") is not None:
            default_max_memory = job_config.get("taskConfig", {}).get("configContent", {}).get("scannerConnectorMaxMemory")
            
        scanner_args = global_ctx.get("scannerConnectorArgs") \
                                 .replace("$CONNMAXMEM", "%d" % int(default_max_memory))
        build_line = "%s %s -s %s -l %s -o %s %s -- -sourcepath %s %s " % \
                     (python_executable,
                      connector_script,
                      scanner_name,
                      scanner_log_fn,
                      temp_file_path,
                      source_path,
                      source_path,
                      scanner_args)

        agent_log_fn = utility.get_log_file_path(global_ctx, job_config, step_config)
        self.logger.trace("Invoking scanner connector, saving logs to files", ("invocation line:", build_line, "scanner-log:", scanner_log_fn, "agent-log:", agent_log_fn))

        # Run subprocess, if jaeger is enabled, use it, otherwise, directly invoke
        fileutil = FileUtility(self.logger)
        fileutil.goto_dir(connector_dir)
        p = CommandLineUtility.bash_execute(build_line, timeout=float(global_ctx.get("javaScannerConnectorTimeout")),
                                        logfile=agent_log_fn, logger=log)
        fileutil.goback_dir()
        
        if p != 0:
            raise XcalException("ScannerConnectorInvokerTask", "run", "Error occurred in Scanner Connector invocation, exit = %d" % p,
                                TaskErrorNo.E_SCAN_CONN_RET_NONZERO)

        self.logger.trace("Scanner connector returned successfully with exit = 0, continuing.", "log in %s and %s" % (scanner_log_fn, agent_log_fn))
        pass


class ScannerConnectorCollectResultTask(object):
    def __init__(self, logger: XcalLogger):
        self.logger = logger
        pass

    def run(self, global_ctx, job_config, step_config):
        """
        Perform Collection of Scanner-Connectors Result to be compressed
        :param global_ctx:
        :param job_config:
        :param step_config:
        :return:
        """
        utility = FilePathResolver(self.logger)
        temp_file_path = utility.get_scanner_connector_result_temp_file(global_ctx, job_config, step_config)

        if (not os.path.exists(temp_file_path)) or (not os.path.isfile(temp_file_path)):
            raise XcalException("ScannerConnectorResultTask", "run",
                                "Scanner result (v-file) was not generated properly, please check detail log",
                                TaskErrorNo.E_SCAN_CONN_RES_NOT_EXIST)

        self.logger.trace("ScannerConnectorCollectResultTask", "result by scanner connector in %s" % temp_file_path)
        with open(temp_file_path, "r") as jsonFile:
            data = json.load(jsonFile)
        data["id"] = job_config.get("taskConfig").get("scanTaskId")
        with open(temp_file_path, "w") as jsonFile:
            json.dump(data, jsonFile, indent=1)
        step_config["filename"] = os.path.basename(temp_file_path)
        pass


class ScannerConnectorTask(object):
    def __init__(self, logger: XcalLogger):
        self.logger = logger
        pass

    def run(self, global_ctx, job_config, step_config):
        """
        Perform a series of jobs including
        ScannerConnectorInvokerTask,
        ScannerConnectorCollectResultTask
        FileUploadTask
        :param global_ctx:
        :param job_config:
        :param step_config:
        :return:
        """
        from components.XcalTasks import FileUploadTask

        ScannerConnectorInvokerTask(self.logger).run(global_ctx, job_config, step_config)
        ScannerConnectorCollectResultTask(self.logger).run(global_ctx, job_config, step_config)
        FileUploadTask(self.logger).run(global_ctx, job_config, step_config)

        self.logger.trace("ScannerConnectorTask completed", "")
