#
#  Copyright (C) 2019-2020 XC5 Hong Kong Limited, Inc. All Rights Reserved.
#

import os
import shutil

from util.XcalFileUtility import FilePathResolver
from common.XcalLogger import XcalLogger


class PrebuildCleanupTask(object):
    def __init__(self, logger: XcalLogger):
        self.logger = logger
        pass

    def run(self, global_ctx, job_config: dict, step_config: dict):
        root_path = FilePathResolver(self.logger).get_job_dir(global_ctx, job_config)
        download_temp_file = FilePathResolver(self.logger).get_download_temp_file_name(global_ctx, job_config, step_config)

        if os.path.exists(download_temp_file):
            self.logger.trace("Removing download temp file ", download_temp_file)
            os.remove(download_temp_file)

        if global_ctx.get("forcePrebuildCleanup") or (global_ctx.get("allowPrebuildCleanup") == "YES" and
                                                      step_config.get("preCleanUp") is not None):
            if os.path.exists(os.path.join(root_path, "preprocess")):
                shutil.rmtree(os.path.join(root_path, "preprocess"))
            if os.path.exists(os.path.join(root_path, "preprocess.tar.gz")):
                os.remove(os.path.join(root_path, "preprocess.tar.gz"))


class PostCleanupTask(object):
    def __init__(self, logger: XcalLogger):
        self.logger = logger
        pass

    def run(self, global_ctx, job_config: dict, step_config: dict):
        root_path = FilePathResolver(self.logger).get_job_dir(global_ctx, job_config)
        if global_ctx.get("forcePrebuildCleanup") or (global_ctx.get("allowPrebuildCleanup") == "YES" and
                                                      step_config.get("preCleanUp") is not None):
            if os.path.exists(os.path.join(root_path, "preprocess")):
                shutil.rmtree(os.path.join(root_path, "preprocess"))


class SourceCodeCleanupTask(object):
    def __init__(self, logger: XcalLogger):
        self.logger = logger
        pass

    def run(self, global_ctx, job_config: dict, step_config: dict):
        source_temp_dir = FilePathResolver(self.logger).get_source_temp_dir(global_ctx, job_config, step_config)
        if global_ctx.get("allowCleanupSrcDownloaded") == "YES":
            if os.path.exists(source_temp_dir):
                shutil.rmtree(source_temp_dir)
