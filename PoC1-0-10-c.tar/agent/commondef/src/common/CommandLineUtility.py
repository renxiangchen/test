#
#  Copyright (C) 2019-2020 XC5 Hong Kong Limited, Inc. All Rights Reserved.
#

import os
import subprocess
import tempfile

from common.XcalLogger import XcalLogger


class CommandLineUtility(object):

    @staticmethod
    def bash_execute(command:str, timeout:float, logger:XcalLogger, logfile:str = None, environment:dict = None):
        """
        Invoke the shell/command line utility to execute command,
                    which may need proper privileges
        :param command:  command line to execute, please consider Windows / Linux capabilities
        :param timeout:  timeout, in seconds
        :param logfile:  file name to the log file of the process, may be a tempfile.NamedTemporaryFile or
                         any file name with write privilege
        :param logger:    XcalLogger
        :param environment: environment variables to pass down.
        :return: (int) the return code from the subprocess.
        """
        with XcalLogger("CommandLineUtility", "bash_execute", parent=logger) as log:
            ssh_line = command
            out_fn = logfile
            tempfile_used = False

            if environment is None:
                environment = dict(os.environ)

            if out_fn is None:
                local_temp_file = tempfile.NamedTemporaryFile(mode="w+b")
                out_fn = local_temp_file.name
                tempfile_used = True

            log.info("execution command", ssh_line)
            log.info("saving dump to file", ("file name :", out_fn))

            # Invoking Process --------------------------
            with open(out_fn, "a+b") as out_f:
                out_f.write("\n---- execution command ------ \n".encode("UTF-8"))
                out_f.write(str(ssh_line).encode("UTF-8"))
                out_f.write(("\n----- saving dump to file -----\n" + out_fn).encode("UTF-8"))
                out_f.write("\n----- environment: -----\n".encode("UTF-8"))
                out_f.write(str(environment).encode("UTF-8"))
                out_f.write("\n-------------------\n".encode("UTF-8"))
                out_f.flush()

                rc = subprocess.call(ssh_line, stdout=out_f, stderr=subprocess.STDOUT,
                                     shell=True, timeout=timeout, env=environment)
                out_f.seek(0)
                try:
                    out_str = out_f.read().decode("UTF-8")
                except UnicodeDecodeError:
                    out_str = out_f.read().decode("iso-8859-1")
                if len(out_str) > 300:
                    out_str = out_str[-300:]

                log.info("Subprocess stdout", ("stdout = ", out_str))  # Log the results

            if tempfile_used:
                local_temp_file.close()

            return rc
