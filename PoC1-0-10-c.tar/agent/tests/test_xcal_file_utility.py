#
#  Copyright (C) 2019-2020 XC5 Hong Kong Limited, Inc. All Rights Reserved.
#

import os
import sys
import unittest
from common.XcalLogger import XcalLogger
from common.XcalException import XcalException
from util import XcalFileUtility


class TestFilePathResolver(unittest.TestCase):
    def setUp(self, logger=XcalLogger("TestFilePathResolver", "setup")):
        self.logger = logger

    @unittest.skipIf((sys.platform[:3] == 'win'), "not valid on windows")
    def test_get_build_work_path_with_valid_file_path_should_success(self):
        global_ctx = {"newagent": "yes"}
        job_config = None
        current_path = os.path.dirname(os.path.realpath(__file__))
        step_config = {"sourceStorageName": None, "buildMainDir": current_path}
        work_path = XcalFileUtility.FilePathResolver(self.logger).get_build_work_path(global_ctx, job_config, step_config)
        self.assertEqual(current_path, work_path)

    @unittest.skipIf((sys.platform[:3] == 'win'), "not valid on windows")
    def test_get_build_work_path_with_nonexist_file_path_should_throw_exception(self):
        global_ctx = {"newagent": "yes"}
        job_config = None
        current_path = os.path.dirname(os.path.realpath(__file__))
        current_path += "1234"
        step_config = {"sourceStorageName": None, "buildMainDir": current_path}
        try:
            XcalFileUtility.FilePathResolver(self.logger).get_build_work_path(global_ctx, job_config, step_config)
        except XcalException:
            pass

    @unittest.skipIf((sys.platform[:3] == 'win'), "not valid on windows")
    def test_get_build_work_path_with_no_permission_file_path_should_throw_exception(self):
        global_ctx = {"newagent": "yes"}
        job_config = None
        current_path = "/etc"
        step_config = {"sourceStorageName": None, "buildMainDir": current_path}
        try:
            XcalFileUtility.FilePathResolver(self.logger).get_build_work_path(global_ctx, job_config, step_config)
        except XcalException:
            pass

    @unittest.skipIf((sys.platform[:3] != 'win'), "only valid on windows")
    def test_get_build_work_path_with_valid_file_should_success(self):
        global_ctx = {"newagent": "yes"}
        job_config = None
        current_path = os.path.realpath(__file__)
        step_config = {"sourceStorageName": None, "buildMainDir": current_path}
        work_path = XcalFileUtility.FilePathResolver(self.logger).get_build_work_path(global_ctx, job_config, step_config)
        self.assertEqual(current_path, work_path)

    @unittest.skipIf((sys.platform[:3] != 'win'), "only valid on windows")
    def test_get_build_work_path_with_nonexist_file_should_throw_exception(self):
        global_ctx = {"newagent": "yes"}
        job_config = None
        current_path = os.path.realpath(__file__)
        current_path += "1234"
        step_config = {"sourceStorageName": None, "buildMainDir": current_path}
        try:
            XcalFileUtility.FilePathResolver(self.logger).get_build_work_path(global_ctx, job_config, step_config)
        except XcalException:
            pass

if __name__ == '__main__':
    unittest.main()