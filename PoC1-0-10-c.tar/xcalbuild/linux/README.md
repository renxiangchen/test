# Xcalbuild/Linux

## Install

build&install Bear

## Use

`python3 xcalbuild.py [options] <build-command>`

### options

- -i: directory of the source code
- -o: directory of the output
- -p: prebuild(?)command:
  - configure
  - cmake .
- build command:
  - aos make
  - make
  - scons
- -h: help

## Output

- preprocess.tar.gz
  - target1
    - preprocess
      - xxx.i
      - xxx.i
      - ...
    - xcalibyte.properties
  - target2
    - preprocess
      - xxx.i
      - xxx.i
      - ...
    - xcalibyte.properties
  - target...
  - xcalibyte.properties
  - checksum.sha1

- xcalbuild.log