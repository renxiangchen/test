#
#  Copyright (C) 2019-2020 XC5 Hong Kong Limited, Inc. All Rights Reserved.
#

# -*- coding: utf-8 -*-
'''
Xcalbuild-Test.
The first time with a stable xcalbuild, use 'python3 xcalbuild_test.py --std' run.
And then 'python3 xcalbuild_test.py', the result in testcase/result, needs to be looked at.
Clone down directly is not sure whether it can be built, you can manually build first and then run this.
The test cases are chosen randomly, so it is not clear whether the test will work or not.
----form youdao translator.
'''

import subprocess
import os
import hashlib
import argparse
from os.path import join, getsize

def getdirsize(dir):
    size = 0
    for root, dirs, files in os.walk(dir):
        size += sum([getsize(join(root, name)) for name in files])
    return size

def countFile(dir):
    tmp = 0
    for item in os.listdir(dir):
        if os.path.isfile(join(dir, item)):
            tmp += 1
        else:
            tmp += countFile(join(dir, item))
    return tmp

source = {
    'INTANG':'https://github.com/seclab-ucr/INTANG',
    'lua':'https://github.com/lua/lua',
    'or1ksim':'https://github.com/openrisc/or1ksim',
    'AliOS-Things':'https://github.com/alibaba/AliOS-Things',
    'genann':'https://github.com/codeplea/genann',
    'nginx':'https://github.com/nginx/nginx',
    'curl':'https://github.com/curl/curl/',
    'openssl':'https://github.com/openssl/openssl'
}
# makeinfo
examples = {
    # 'basic':'make',
    # 'zlib-1.2.11':'-p \"cmake .\" make',
    # 'a2-code':'make',
    # 'his_esp_project':'make',
    'INTANG':'make',
    'lua':'make',
    'or1ksim':'-p \"./configure\" make',
    'AliOS-Things':'aos make',
    'genann':'make',
    'nginx':'-p \"./auto/configure\" make',
    'curl':'-p \"cmake .\" make',
    'openssl':'make'
}
std = 'std'
now = 'now'
test_dir = 'testcase'
preprocess_tar_gz = 'preprocess.tar.gz'
preprocess = 'preprocess'
source_files = 'source_files.json'


for proj in source.keys():
    if not os.path.exists(join(test_dir, proj)):
        os.system('git clone ' + source[proj] + ' ' + join(test_dir, proj))


parser = argparse.ArgumentParser()
parser.add_argument("--std", action="store_true")
args = parser.parse_args()
if args.std:
    now = std

result = open(join(test_dir, 'result'), "w")
os.system("rm -rf " + join(test_dir, now))
for key in examples.keys():
    command = "python3 xcalbuild.py -i " + \
               join(test_dir, key) + \
              " -o " + join(test_dir, now, key) + \
              ' ' + examples[key]
    print(command)
    ret = os.popen(command).read()
    if not os.path.exists(join(test_dir, now, key)):
        os.makedirs(join(test_dir, now, key))
    open(join(test_dir, now, key, 'log'), "w").write(ret)
    os.system('mv xcalbuild.log ' + join(test_dir, now, key, 'xcalbuild.log'))

    if not args.std:
        std_dir = join(test_dir, std, key, preprocess)
        now_dir = join(test_dir, now, key, preprocess)
        std_dirs = os.listdir(std_dir)
        now_dirs = os.listdir(now_dir)
        if len(std_dirs) != len(now_dirs):
            pass
            # exit(0)
        if countFile(std_dir) != countFile(now_dir):
            print(countFile(std_dir), countFile(now_dir))
            result.write(str(countFile(std_dir)) + '  ' + str(countFile(now_dir)) + '\n')
            # exit(0)
        sha1_dict = {}
        for dir in std_dirs:
            if dir[-3:] != 'dir':
                continue
            dir = join(std_dir, dir, 'preprocess')
            cur_dict = {}
            for file in os.listdir(dir):
                file_path = join(dir, file)
                sha1 = hashlib.sha1(open(file_path, "rb").read()).hexdigest()
                cur_dict[sha1] = [file_path]
            sha1_dict[dir] = cur_dict
        ret = ''
        for dir in now_dirs:
            if dir[-3:] != 'dir':
                continue
            s_dir = join(std_dir, dir, 'preprocess')
            dir = join(now_dir, dir, 'preprocess')
            for file in os.listdir(dir):
                file_path = join(dir, file)
                sha1 = hashlib.sha1(open(file_path, "rb").read()).hexdigest()
                if sha1 not in sha1_dict[s_dir].keys():
                    print(file_path)
                    ret = ret + file_path + '\n'
                    continue
                    # exit(0)
                sha1_dict[s_dir][sha1].append(file_path)
        for dir_dict in sha1_dict.values():
            for value in dir_dict.values():
                if not len(value) == 2:
                    print(value)
                    ret = ret + str(value) + '\n'
                    # exit(0)
        result.write(ret)
        result.write(key + ' yes\n----------------\n')
        
print('ok')
