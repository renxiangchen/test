#
#  Copyright (C) 2019-2020 XC5 Hong Kong Limited, Inc. All Rights Reserved.
#

#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
XcalBuild-Linux.
Advance preprocess implementation on Linux, pre-build and capture all required for core.

It is better to read the code directly.
The comments are not written well, many times will confuse or mislead you.
If there are any questions about the comments, read the code.
----ssj.

"""

import os
import re
import sys
import json
import time
import tarfile
import logging
import hashlib
import argparse
import platform

from os.path import basename, join, dirname, normpath, abspath
from configparser import ConfigParser

if dirname(sys.argv[0]):
    os.chdir(dirname(sys.argv[0]))

CFG = ConfigParser()
# CFG.read(join(dirname(sys.argv[0]), 'config'))
CFG.read('config')
VERSION = CFG.get('linux', 'VERSION')
CDB_NAME = CFG.get('linux', 'CDB_NAME')
PREPROCESS = CFG.get('linux', 'PREPROCESS')
PROPERTY_KEY = CFG.options('PROPERTY_KEY')
SOURCE_FILES = CFG.get('linux', 'SOURCE_FILES')
PREPROCESSER = ""

PREBUILD_PATTERNS = {
    # 'configure':'' # don't need to clean
    'cmake':'rm -rf CMakeFiles && rm -f CMakeCache*'
}

BUILD_PATTERNS = {
    'aos':'aos make clean',
    'catkin_make':'catkin_make clean',
    'catkin':'catkin clean --yes',
    'scons':'scons -c',
    'make':'make clean',
    'ninja':'ninja -t clean'
}

# Known C compiler executable name patterns.
PATTERNS_C = (
    re.compile(r'^([^-]*-)*[mg]cc(-?\d+(\.\d+){0,2})?$'),
    re.compile(r'^([^-]*-)*clang(-\d+(\.\d+){0,2})?$'),
    re.compile(r'^(|i)cc$'),
    re.compile(r'^(g|)xlc$'),
)

# Known C++ compiler executable name patterns.
PATTERNS_CXX = (
    re.compile(r'^(c\+\+|cxx|CC)$'),
    re.compile(r'^([^-]*-)*[mg]\+\+(-?\d+(\.\d+){0,2})?$'),
    re.compile(r'^([^-]*-)*clang\+\+(-\d+(\.\d+){0,2})?$'),
    re.compile(r'^icpc$'),
    re.compile(r'^(g|)xl(C|c\+\+)$'),
    re.compile(r'^(.*c\+\+)$'),
)

# Known Asm compiler executable name patterns.
PATTERNS_AS = (
    re.compile(r'^(as)$'),
)

# (it's written backwards, the string needs to match backwards)
PATTERNS_LD = (
    re.compile(r'^(dl.*)|([^\.]*\.dl.*)$'),
)
PATTERNS_AR = (
    re.compile(r'^(ra.*)|([^\.]*\.ra.*)$'),
)

def mkdir(path):
    """ Make directory. """

    if not os.path.exists(path):
        os.makedirs(path)

def is_obj_32_bits(obj):
    """ Determines whether the target file is 32 bits. """

    info = os.popen('readelf -h ' + obj).read()
    if 'ELF32' in info:
        return True
    return False

def make_targz(outputdir):
    """ Make tar. """

    with tarfile.open(os.path.join(outputdir + '.tar.gz'), "w:gz") as tar:
        try:
            tar.add(outputdir, arcname='')
        except Exception as exception:
            logging.error('FAILED: %s', exception)


def get_compiler_type(compiler):
    """ Gets the type of compiler.

    :param compiler :     Compiler
    :return :     Type of compiler
    """

    if any(pattern.match(compiler) for pattern in PATTERNS_C):
        return 'c'
    if any(pattern.match(compiler) for pattern in PATTERNS_CXX):
        return 'cxx'
    if any(pattern.match(compiler) for pattern in PATTERNS_AS):
        return 'as'
    if any(pattern.match(compiler[::-1]) for pattern in PATTERNS_AR):
        if compiler == 'tar':
            return 'unknown'
        return 'ar'
    if any(pattern.match(compiler[::-1]) for pattern in PATTERNS_LD):
        return 'ld'
    return 'unknown'

class ArgParse:
    """ Parse input command line. """

    @staticmethod
    def create_parser():
        """ Create Parser. """

        parser = argparse.ArgumentParser(description="")
        parser.add_argument("-i",
                            "--builddir",
                            help="build directory",
                            type=str)
        parser.add_argument("-o",
                            "--outputdir",
                            help="output directory",
                            type=str,
                            default=".")
        parser.add_argument("-p",
                            "--prebuild",
                            help="prebuild command, such as 'cmake .','./configure'... ",
                            type=str)
        parser.add_argument("--debug",
                            action="store_true")
        parser.add_argument("--preprocesser",
                            default="default",
                            type=str)
        parser.add_argument(dest="build",
                            help="build command",
                            nargs=argparse.REMAINDER)
        parser.add_argument("-v",
                            "--version",
                            help="Displaying the version of xcalbuild",
                            action="store_true")
        return parser

    @classmethod
    def get_args(cls):
        """ Get arguments. """

        parser = cls.create_parser()
        args = parser.parse_args()

        if args.version:
            print('version: ' + VERSION)
            sys.exit(0)
        mkdir(join(args.outputdir, PREPROCESS))
        log = join(args.outputdir, 'xcalbuild.log')
        logging.basicConfig(level=10,
                            filename=log,
                            filemode='w',
                            format=
                            '%(asctime)s-%(pathname)s[line:%(lineno)d]-%(levelname)s:%(message)s')
        logging.debug('Raw arguments %s', sys.argv)

        if not args.builddir:
            parser.error(message='missing the directory of the source code')
        if not args.build:
            parser.error(message='missing build command')
        args.build[0] = args.build[0].strip()
        if args.preprocesser != 'default' or 'preprocesser=xvsa' in args.build[0]:
            global PREPROCESSER
            PREPROCESSER = args.preprocesser
            if args.preprocesser == 'default':
                argbuild = args.build[0]
                PREPROCESSER = argbuild[argbuild.find('=')+1: argbuild.find(' ')]
                args.build[0] = args.build[0][args.build[0].find(' ')+1:]
            logging.info('preprocesser: ' + PREPROCESSER)
            if os.popen('which ' + PREPROCESSER).read() == '':
                print('not find ' + PREPROCESSER)
                logging.error('no ' + PREPROCESSER)
                exit(1)
        logging.debug('Parsed arguments: %s', args)
        return args

def get_clean_command(prebuild, build):
    """ Get clean command. """

    ret_list = []
    for key, build_pattern in BUILD_PATTERNS.items():
        if key == build.split(' ')[0]:
            ret_list.append(build_pattern)
            break
    if prebuild:
        for key, prebuild_pattern in PREBUILD_PATTERNS.items():
            if key in prebuild:
                ret_list.append(prebuild_pattern)
                break
    return ret_list

FILE_LIST = []
COMPILE_COMMANDS = []
LINK_COMMANDS = {}
class Compilation:
    """ A single compile command. """

    def __init__(self):
        """ Constructor for a single compilation.

        :param directory:     Path when executing the current command
        :param compiler :     Compiler
        :param src_file :     Source file of the compile command
        :param obj_file :     Output file of the compile command
        :param options  :     Options of the compile command
        :param cpr_type :     Detected compiler type
        :param reduced_flags: Reduced flags for properties. """

        self.cpl_dict = dict.fromkeys(['directory',
                                       'compiler',
                                       'src_file',
                                       'obj_file',
                                       'options',
                                       'cpr_type',
                                       'reduced_flags'])
        self.obj_file = ''

    @staticmethod
    def expand_cmd(commands, directory):
        """ Expand the command written in the file.

        Some commands are written in the file and need to be taken out.

        :param commands  :     Raw commands
        :param directory :     Path when executing the raw command
        :return commands :     Expanded command """

        for cmd in commands:
            if cmd[0] == '@':
                pwd = os.getcwd()
                os.chdir(directory)
                if os.path.exists(cmd[1:]):
                    for tmp in open(cmd[1:], 'r').read().strip().split('\n'):
                        tmp = tmp.strip().split(' ')
                        commands += tmp
                commands.remove(cmd)
                os.chdir(pwd)
        return commands

    def set_options(self, command, src_file, cpr_type):
        """ Parse out a command's options

        :param command  :     Raw compile commands
        :param src_file :     Source File
        :param cpr_type :     Compiler type """

        if cpr_type == 'as':
            self.cpl_dict['options'] = ' '.join(command[1:])
            return
        options = ''
        if '-o' in command:
            if '-c' not in command:
                self.cpl_dict['options'] = ' '.join(command[1:])
                return
            cmds = command[command.index('-c')+1:command.index('-o')]
            for cmd in cmds:
                if '-MF' in cmd and len(cmd) > 3:
                    continue
                if '-MT' in cmd and len(cmd) > 3:
                    continue
                # hardcode for gdb
                if 'DSELECT_ARCHITECTURES' in cmd or 'DSELECT_VECS' in cmd:
                    cmd = cmd[:cmd.index('=')+1] + '\'' + cmd[cmd.index('=')+1:] + '\''
                options = options + cmd + ' '
        else:
            for i in range(command.index('-c')+1, len(command)):
                if command[i] == basename(src_file):
                    break
                options = options + command[i] + ' '
        options += ' '
        options = options.replace("=\"", "=\'\"")
        options = options.replace("\" ", "\"\' ")
        options = options.replace("(", "\"(")
        options = options.replace(")", ")\"")
        options = options.replace("&", "\\&")
        # hardcode for jerryscript
        options = options.replace("\"\' \"(7fe2217c)\"\"", "\" (7fe2217c)\"")
        options = options.replace("<", "\"<")
        options = options.replace(">", ">\"")
        self.cpl_dict['options'] = options

    def set_reduced_flags(self, directory, src_file, command):
        """ Set reduced flags except for unused ones.

        :param directory:     Directory.
        :param command  :     Raw compile commands
        :param src_file :     Source File. """

        option = []
        i = 1
        while i < len(command):
            opt = command[i]
            if len(opt) < 2:
                option.append(opt)
                i += 1
                continue
            if opt in ['-I', '-D', '-include']:
                i += 1
                while command[i][0] != '-':
                    i += 1
                    if i == len(command):
                        break
                continue
            if opt[:2] not in ['-I', '-D']:
                if opt == '-o':
                    i += 1
                elif opt != '-c' and src_file != join(directory, opt):
                    option.append(opt)
            i += 1
            continue
        self.cpl_dict['reduced_flags'] = ' '.join(option)

    def set_obj_file(self, command, src_file, directory):
        """ Parse out a command's obj_file

        :param command  :     Raw compile commands
        :param src_file :     Source File """

        if '-o' in command:
            self.cpl_dict['obj_file'] = normpath(join(directory, command[command.index("-o")+1]))
        else:
            self.cpl_dict['obj_file'] = normpath(src_file.split('.')[-2]+'.o')

    def set_src_file(self, src_file):
        """ Set source file.

        :param src_file :     Source File. """

        self.cpl_dict['src_file'] = src_file

    def set_directory(self, directory):
        """ Set directory.

        :param directory :     Directory. """

        self.cpl_dict['directory'] = directory

    def set_compiler(self, compiler, cpr_type):
        """ Set compiler.

        :param compiler :     Compiler.
        :param cpr_type :     Compiler type. """

        self.cpl_dict['compiler'] = compiler
        self.cpl_dict['cpr_type'] = cpr_type

    def get_dict(self):
        """ Get parsed raw compile database.

        :return dict{str: dict} :     Parsed raw compile database. """

        return {self.cpl_dict['obj_file']: self.cpl_dict}

    @staticmethod
    def get_parsed_cmd(compilation, cpr_type):
        """ Get the parsed compilation database : dict.

        :param command  :     Raw compile database
        :param src_file :     Source File
        :param cpr_type :     Compiler type
        :return parsed_dict:  Parsed raw compilation database """

        cpl_class = Compilation()
        directory = compilation['directory']
        src_file = join(directory, compilation['file'])
        if src_file.split('.')[-1] in ['s', 'S']:
            cpr_type = 'as'
        command = cpl_class.expand_cmd(compilation['arguments'], directory)
        cpl_class.set_compiler(command[0], cpr_type)
        cpl_class.set_directory(directory)
        cpl_class.set_src_file(src_file)
        cpl_class.set_obj_file(command, src_file, directory)
        cpl_class.set_options(command, src_file, cpr_type)
        cpl_class.set_reduced_flags(directory, src_file, command)
        return cpl_class.get_dict()

class Link:
    """ A single link command. """
    def __init__(self):
        """ Constructor for a single link command.

        :param directory:     Path when executing the current command.
        :param compiler :     Linker or archiver.
        :param files    :     All files in this command.
        :param others   :     Others, maybe dependence.
        :param options  :     Options of the link command.
        :param cpr_type :     Detected linker type.
        :param target   :     Target. """

        self.ld_dict = dict.fromkeys(['directory',
                                      'compiler',
                                      'files',
                                      'others',
                                      'options',
                                      'cpr_type',
                                      'target'])

    @staticmethod
    def expand_cmd(commands, directory):
        """ Expand the command written in the file.

        return commands:     Expanded command """

        for cmd in commands:
            if cmd[0] == '@': 
                pwd = os.getcwd()
                os.chdir(directory)
                if os.path.exists(cmd[1:]):
                    for tmp in open(cmd[1:], 'r').read().strip().split('\n'):
                        tmp = tmp.strip().split(' ')
                        commands += tmp
                else:
                    logging.warning('no such file: ' + cmd[1:])
                commands.remove(cmd)
                os.chdir(pwd)
        return commands

    def get_target(self, command, cpr_type, directory):
        """ Get target in the raw command.

        :param command   :     Raw command line.
        :param cpr_type  :     Linker or archiver type.
        :param directory :     Path when executing the current command.
        :return target   :     Target in the raw command. """

        if cpr_type == 'ld':
            if '-o' in command:
                retn = join(directory, command[command.index("-o")+1])
            else:
                retn = join(directory, 'a.out')
        if cpr_type == 'ar':
            retn = join(directory, command[2])
        self.ld_dict['target'] = retn
        return retn

    def set_options(self, command):
        """ Get target in the raw command.

        :param command :     Raw command line.
        :return :     Options. """

        self.ld_dict['options'] = ' '.join(command[1:])

    def set_files_and_others(self, command, directory, target):
        """ Get files needed to generate this target and others(maybe dependence) in this command.

        :param command  :     Raw command line.
        :param directory:     Path when executing the current command.
        :param target   :     Target name.
        :return files   :     Files needed to generate this target.
        :return others  :     Others(maybe dependence) in this command. """

        files = []
        others = []
        for cmd in command:
            if cmd.split('.')[-1] in ['o', 'obj'] and basename(cmd) != target:
                files.append(normpath(join(directory, cmd)))
            elif cmd[0] != '-':
                others.append(join(directory, cmd))
        files.append(target)
        self.ld_dict['files'] = files
        self.ld_dict['others'] = others

    def set_directory(self, directory):
        """ Set directory.

        :param directory :     Directory. """

        self.ld_dict['directory'] = directory

    def set_compiler(self, compiler, cpr_type):
        """ Set compiler.

        :param compiler :     Compiler.
        :param cpr_type :     Compiler type. """

        self.ld_dict['compiler'] = compiler
        self.ld_dict['cpr_type'] = cpr_type

    def get_dict(self):
        """ Get dict.

        :return: Dict. """

        target = self.ld_dict['target']
        if LINK_COMMANDS.__contains__(target):
            self.ld_dict['files'] += LINK_COMMANDS[target]['files']
            self.ld_dict['others'] += LINK_COMMANDS[target]['others']
            self.ld_dict['options'] += LINK_COMMANDS[target]['options']
        return target, self.ld_dict

    @staticmethod
    def get_parsed_link(compilation, cpr_type):
        """ Get the parsed compilation database : dict.

        :param command  :     Raw compile database.
        :param src_file :     Source File.
        :param cpr_type :     Compiler type.
        :return:  Parsed compilation database """

        ld_class = Link()
        directory = compilation['directory']
        command = Link.expand_cmd(compilation['arguments'], directory)
        target = ld_class.get_target(command, cpr_type, directory)
        if not target:
            return None, None
        ld_class.set_files_and_others(command, directory, target)
        ld_class.set_directory(directory)
        ld_class.set_options(command)
        ld_class.set_compiler(command[0], cpr_type)
        return ld_class.get_dict()


class Properties:
    """ Properties for a single target. """

    def __init__(self, properties):
        """ Constructor for a single properties."""

        self.properties = properties

    def set_make_command(self, prebuild, build):
        """ Set prebuild and build command. """

        self.properties['make_command'] = build
        self.properties['build_command'] = prebuild

    def set_c_properties(self, target, compile_dict):
        """ Set properties about C.

        :param target      : Target.
        :param compile_dict: Compilation dict in this target. """

        self.properties['c_compiler'] = compile_dict['compiler']
        self.properties['c_extra_flags'] = compile_dict['reduced_flags']
        for opt in compile_dict['reduced_flags'].split(' '):
            if (len(opt) > 5 and opt[:5] == '-std='
                    and opt not in self.properties['c_scan_options']):
                self.properties['c_scan_options'] = \
                self.properties['c_scan_options'] + opt + ' '
        if ('-m32' not in self.properties['c_scan_options']
                and ('32' in platform.architecture()[0]
                     or is_obj_32_bits(target))):
            self.properties['c_scan_options'] += ' -m32 '
            if '-m32' not in compile_dict['reduced_flags']:
                self.properties['c_extra_flags'] += ' -m32 '
        if ('arm' in self.properties['c_compiler'] 
            and '-std=c99' not in self.properties['c_scan_options']):
            self.properties['c_scan_options'] += ' -std=c99 '

    def set_cxx_properties(self, target, compile_dict):
        """ Set properties about cxx.

        :param target      : Target.
        :param compile_dict: Compilation dict in this target. """

        self.properties['cxx_compiler'] = compile_dict['compiler']
        self.properties['cxx_extra_flags'] = compile_dict['reduced_flags']
        for opt in compile_dict['reduced_flags'].split(' '):
            # TODO: this should probably be a set instead of space-separated string,
            # in case of prefix etc.
            # Also need to "translate" the option to something xvsa actually understands.
            if (len(opt) > 5 and opt[:5] == '-std='
                    and opt not in self.properties['cxx_scan_options']):
                self.properties['cxx_scan_options'] = \
                self.properties['cxx_scan_options'] + opt + ' '
        if ('-m32' not in self.properties['cxx_scan_options']
                and ('32' in platform.architecture()[0]
                     or is_obj_32_bits(target))):
            self.properties['cxx_scan_options'] += ' -m32 '
            if '-m32' not in compile_dict['reduced_flags']:
                self.properties['cxx_extra_flags'] += ' -m32 '
        if ('arm' in self.properties['c_compiler'] 
            and '-std=c99' not in self.properties['cxx_scan_options']):
            self.properties['cxx_scan_options'] += ' -std=c99 '

    def set_as_properties(self, target, compile_dict):
        """ Set properties about ASM.

        :param target      : Target.
        :param compile_dict: Compilation dict in this target. """

        self.properties['as_compiler'] = compile_dict['compiler']
        self.properties['as_extra_flags'] = compile_dict['reduced_flags']
        if (('32' in platform.architecture()[0]
             and (not '-m32' in compile_dict['options']))
                or is_obj_32_bits(target)):
            self.properties['as_extra_flags'] += ' -m32 '

    def set_ar_properties(self, archiver, flags):
        """ Set properties about Archiver.

        :param archiver:     Archiver.
        :param flags   :     Ar flags. """

        self.properties['archiver'] = archiver
        self.properties['ar_extra_flags'] = flags

    def set_ld_properties(self, target, target_dict):
        """ Set properties about Linker.

        :param target     :     Target.
        :param target_dict:     Link dict in this target. """

        self.properties['linker'] = target_dict['compiler']
        self.properties['ld_extra_flags'] = target_dict['options']
        self.properties['dependencies'] = []
        for oth in target_dict['others']:
            # libxxx.so libxxx.a -lxxx
            oth = basename(oth)
            if oth == basename(target):
                continue
            for key in LINK_COMMANDS.items():
                key = key[0]
                key = basename(key)
                if oth == key:
                    self.properties['dependencies'].append(oth)
                    continue
                if ('-static' not in target_dict['options'] and len(oth) > 1
                        and oth[:2] == '-l' and 'lib' + oth[2:] + '.so' in key):
                    self.properties['dependencies'].append(oth)
                    continue
                if ('-static' in target_dict['options'] and len(oth) > 1
                        and oth[:2] == '-l' and 'lib' + oth[2:] + '.a' in key):
                    self.properties['dependencies'].append(oth)
                    continue
        self.properties['dependencies'] = ' '.join(self.properties['dependencies'])

    def get_dict(self):
        """ Get Properties dict.

        :return : properties dict """

        return self.properties

    @staticmethod
    def get_properties(target):
        """ Get Properties dict.

        :param target:     Target.
        :return :     Properties dict. """

        pro_class = Properties(properties=dict.fromkeys(PROPERTY_KEY, ''))
        target_dict = LINK_COMMANDS[target]
        if target_dict['cpr_type'] == 'ar':
            pro_class.set_ar_properties(target_dict['compiler'], target_dict['options'])
        else:
            pro_class.set_ld_properties(target, target_dict)
        if len(target_dict['files']) > 0:
            is_c_ok = False
            is_cxx_ok = False
            is_as_ok = False
            for compile_dict in COMPILE_COMMANDS:
                obj = list(compile_dict.keys())[0]
                compile_dict = compile_dict[obj]
                if is_as_ok and is_c_ok and is_cxx_ok:
                    break
                if obj not in target_dict['files']:
                    continue
                if compile_dict['cpr_type'] == 'c' and not is_c_ok:
                    pro_class.set_c_properties(target, compile_dict)
                    is_c_ok = True
                if compile_dict['cpr_type'] == 'cxx' and not is_cxx_ok:
                    pro_class.set_cxx_properties(target, compile_dict)
                    is_cxx_ok = True
                if compile_dict['cpr_type'] == 'as' and not is_as_ok:
                    pro_class.set_as_properties(target, compile_dict)
                    is_as_ok = True
        return pro_class.get_dict()

    @staticmethod
    def generate_properties(output, target):
        """ Write properties to a file.

        :param output:     Output directory.
        :param target:     Target. """

        pro_dict = Properties.get_properties(target)
        if os.path.exists(join(output, basename(target) + ".dir")):
            pro_file = open(join(output, basename(target) + '.dir', 'xcalibyte.properties'), "w")
            for item in pro_dict.items():
                pro_file.write(str(item[0]) + '=' + str(item[1]) + '\n')
            pro_file.close()

def parse_raw_cdb(build_dir):
    """ Parse raw compilation database.

    :param build_dir :     Build directory. """

    with open(join(build_dir, CDB_NAME), "r") as compilation_database:
        compilation_database = json.loads(compilation_database.read())
        for compilation in compilation_database:
            cpr_type = get_compiler_type(basename(compilation['arguments'][0]))
            if cpr_type == 'unknown':
                logging.warning('unknow compiler %s', compilation['arguments'][0])
                continue
            if cpr_type in ['c', 'cxx', 'as']:
                COMPILE_COMMANDS.append(Compilation.get_parsed_cmd(compilation, cpr_type))
            else:
                target, info_dict = Link.get_parsed_link(compilation, cpr_type)
                if not target:
                    continue
                LINK_COMMANDS[target] = info_dict
    logging.info(json.dumps(COMPILE_COMMANDS, indent=4))
    logging.info(json.dumps(LINK_COMMANDS, indent=4))

CNT = 0
def get_cmds(target, output):
    """ Gets all preprocessing and dependency commands under one target.

    :param target   :     Target.
    :param output   :     Output directory.
    :return pre_cmds:     Preprocess commands.
    :return dep_cmds:     Dependency commands. """

    pre_cmds = []
    dep_cmds = []
    loc = []
    for compile_dict in COMPILE_COMMANDS:
        obj = list(compile_dict.keys())[0]
        compile_dict = compile_dict[obj]
        if obj in LINK_COMMANDS[target]['files'] or \
           obj.replace('.tmp_', '') in LINK_COMMANDS[target]['files']:
            mkdir(join(output, basename(target) + '.dir', PREPROCESS))
            i_file = ''
            dep = ''
            if compile_dict['cpr_type'] == 'as':
                mkdir(join(output, basename(target) + '.dir', PREPROCESS))
                if basename(compile_dict['src_file']) == '':
                    continue
                command = ('cp ' + compile_dict['src_file'] + ' '
                           + join(output, basename(target) + '.dir', PREPROCESS,
                                  basename(compile_dict['src_file'])))
            else:
                # TODO: This really need to take compiler executable and options
                #       (e.g. -std=gnu++11) in to consideration.
                # input file extension should actually be the last to consider.
                FILE_LIST.append(normpath(compile_dict['src_file']))
                ext = '.i' if basename(compile_dict['src_file']).split('.')[-1] == 'c' \
                           and compile_dict['cpr_type'] == 'c' else '.ii'
                i_file = join(output, basename(target) + '.dir', PREPROCESS, \
                              basename(compile_dict['src_file']) + ext)
                if os.path.exists(i_file) or i_file in loc:
                    global CNT
                    i_file = (join(output, basename(target) + '.dir', PREPROCESS,
                                   basename(compile_dict['src_file']) + str(CNT) + ext))
                    logging.debug(basename(compile_dict['src_file']))
                    CNT += 1
                loc.append(i_file)
                global PREPROCESSER
                if PREPROCESSER != '':
                    command = (PREPROCESSER + ' -c -E ' + compile_dict['options'] +
                               compile_dict['src_file'] + ' -c -o ' + i_file)
                else:
                    command = (compile_dict['compiler'] + ' -E ' + compile_dict['options'] +
                               compile_dict['src_file'] + ' -o ' + i_file)
                dep = (compile_dict['compiler'] + ' -MM ' +
                       compile_dict['options'] + compile_dict['src_file'])
            pre_cmds.append([command, compile_dict['directory'], i_file])
            dep_cmds.append([dep, compile_dict['directory']])
    return pre_cmds, dep_cmds

def generate_i(build_dir, output):
    """ Generate .i files under the corresponding target.
        Generate properties.xcalibyte under the corresponding target.

    :param build_dir:     Build directory.
    :param output   :     Output directory. """

    parse_raw_cdb(build_dir)
    for target in LINK_COMMANDS.items():
        target = target[0]
        mkdir(join(output, basename(target) + '.dir', PREPROCESS))
        pre_cmds, dep_cmds = get_cmds(target, output)
        for pre_cmd in pre_cmds:
            pwd = os.getcwd()
            os.chdir(pre_cmd[1])
            logging.info(pre_cmd[0])
            os.system(pre_cmd[0])
            i_file_name = pre_cmd[2]
            tmp_cont = ''
            if os.path.exists(i_file_name):
                for line in open(i_file_name, 'r', encoding='utf-8').readlines():
                    if line[0] == '#' and line.count('\"') == 2 and line.count('<') == 0:
                        path = line[line.find('\"')+1:line.rfind('\"')]
                        line = line.replace(path, normpath(abspath(path))).replace('\\', '\\\\')
                    tmp_cont += line
                open(i_file_name, 'w', encoding='utf-8').write(tmp_cont)
            os.chdir(pwd)
        for dep_cmd in dep_cmds:
            pwd = os.getcwd()
            os.chdir(dep_cmd[1])
            logging.info(dep_cmd[0])
            dep_lst = (str(os.popen(dep_cmd[0]).read()).replace('\\\n', '')
                       .replace('\n', '').split(' ')[1:])
            dep_lst = [it for it in dep_lst if it != '']
            dep_lst = [normpath(abspath(it)) for it in dep_lst]
            FILE_LIST.extend(dep_lst)
            os.chdir(pwd)
        if pre_cmds:
            Properties.generate_properties(output, target)
    mkdir(output)
    open(join(output, 'xcalibyte.properties'), "w")

def generate_checksum(output):
    """ Generate checksum.sha1.

    :param output: Output directory. """

    with open(join(output, 'checksum.sha1'), "w") as checksum_sha1:
        for dir_name in os.walk(output):
            dirpath = dir_name[0]
            filenames = dir_name[2]
            for filename in filenames:
                if filename in ['checksum.sha1', 'xcalbuild.log']:
                    continue
                myfile = join(dirpath, filename)
                sha1 = hashlib.sha1(open(myfile, "rb").read()).hexdigest()
                checksum_sha1.write(sha1 + ' ' + myfile + '\n')

def log_time(start):
    """ Logging time.

    :param start:     Last log time.
    :return     :     Current time. """

    logging.debug('TIME: %s', str(time.time() - start))
    return time.time()

def main():
    """ Main function. """

    start = time.time()
    args = ArgParse.get_args()
    outputdir = args.outputdir
    args.outputdir = os.path.abspath(join(args.outputdir, PREPROCESS))

    for cln in get_clean_command(args.prebuild, ' '.join(args.build)):
        logging.info("clean command: %s", cln)
        os.system('cd ' + args.builddir + ' && ' + cln)
    if args.prebuild:
        os.system('cd ' + args.builddir + ' && ' + args.prebuild)
    retn = os.system('cd ' + args.builddir + ' && bear ' + ' '.join(args.build))
    if retn:
        logging.error(retn)
        sys.exit(1)

    start = log_time(start)

    generate_i(build_dir=args.builddir, output=args.outputdir)
    start = log_time(start)

    generate_checksum(args.outputdir)
    make_targz(args.outputdir)
    open(join(outputdir, SOURCE_FILES), 'w').write(json.dumps(list(set(FILE_LIST))))

    # logging.info("cleaning......")
    # for cln in get_clean_command(args.prebuild, ' '.join(args.build)):
    #     os.system('cd ' + args.builddir + ' && ' + cln)

    print("xcalbuild done(=_=)")
    logging.info("done(=_=)")

if __name__ == "__main__":
    main()
