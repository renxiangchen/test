README
========

InitHelper is taken from osxinj/bootstrap
https://github.com/scen/osxinj

MIT license. no change on source code.

NOTE: no idea why this is needed to be a standalone dll. should be reviewed later.
