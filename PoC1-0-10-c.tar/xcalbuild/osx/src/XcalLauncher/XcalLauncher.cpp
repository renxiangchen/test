/*
 *  Copyright (C) 2019-2020 XC5 Hong Kong Limited, Inc. All Rights Reserved.
 */

#include <stdio.h>
#include <assert.h>
#include <string.h>
#include <dlfcn.h>
#include <stdlib.h>
#include <unistd.h>
#include <signal.h>
#include <spawn.h>
#include <libproc.h>
#include <mach/mach.h>
extern "C" {
#include <Security/Authorization.h>
}
#include "injector.h"

static const unsigned char info_plist[]
__attribute__ ((section ("__TEXT,__info_plist"),used)) =
  "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n"
  "<!DOCTYPE plist PUBLIC \"-//Apple Computer//DTD PLIST 1.0//EN\""
  " \"http://www.apple.com/DTDs/PropertyList-1.0.dtd\">\n"
  "<plist version=\"1.0\">\n"
  "<dict>\n"
  "  <key>CFBundleIdentifier</key>\n"
  "  <string>com.xcalibyte.XcalLauncher</string>\n"
  "  <key>CFBundleName</key>\n"
  "  <string>XcalLauncher</string>\n"
  "  <key>CFBundleVersion</key>\n"
  "  <string>1.0</string>\n"
  "  <key>SecTaskAccess</key>\n"
  "  <array>\n"
  "    <string>allowed</string>\n"
  "    <string>debug</string>\n"
  "  </array>\n"
  "</dict>\n"
  "</plist>\n";

#if 0
// no idea how to get AuthorizationCreate/AuthorizationCopyRights linked
int taskport_right()
{
  OSStatus stat;
  AuthorizationItem taskport_item[] = {{"system.privilege.taskport:"}};
  AuthorizationRights rights = {1, taskport_item}, *out_rights = NULL;
  AuthorizationRef author;

  AuthorizationFlags auth_flags = kAuthorizationFlagExtendRights | kAuthorizationFlagPreAuthorize | kAuthorizationFlagInteractionAllowed | ( 1 << 5);

  stat = AuthorizationCreate (NULL, kAuthorizationEmptyEnvironment,auth_flags,&author);
  if (stat != errAuthorizationSuccess)
    return 0;

  stat = AuthorizationCopyRights ( author, &rights, kAuthorizationEmptyEnvironment, auth_flags,&out_rights);
  if (stat != errAuthorizationSuccess) {
    printf("XcalLauncher: fail to check taskport right. code=%d\n", stat);
    return 1;
  }
  return 0;
}
#endif

int main(int argc, char* argv[])
{
  if (argc < 2) {
    printf("XcalLauncher: usage [proc_name] [proc_arguments]\n");
    return 0;
  }

  // check taskport right
  //if (taskport_right())
  //  return 1;

  // get executable path
  int pid = getpid();
  char path[4096];
  int ret = proc_pidpath(pid, path, sizeof(path));
  assert(ret > 0 && ret < 4000);  // leave 96 for 'libXcalHelper.dylib'

  char *dirname = strrchr(path, '/');
  strcpy(dirname, "/libXcalHelper.dylib");
  printf("XcalLauncher: load helper from %s\n", path);

  // launch sub process
  int status;
  posix_spawnattr_t attr;
  status = posix_spawnattr_init(&attr);
  assert(status == 0);
  //status = posix_spawnattr_setflags(&attr, POSIX_SPAWN_START_SUSPENDED | POSIX_SPAWN_RESETIDS | POSIX_SPAWN_SETEXEC);
  //status = posix_spawnattr_setflags(&attr, POSIX_SPAWN_RESETIDS | POSIX_SPAWN_SETEXEC | 0x100);
  //status = posix_spawnattr_setflags(&attr, POSIX_SPAWN_SETEXEC | 0x100);
  status = posix_spawnattr_setflags(&attr, POSIX_SPAWN_RESETIDS | 0x100);
  assert(status == 0);

  // prepare arguments
  char** carg = (char**)malloc(argc * sizeof(char*));
  int i;
  for (i = 1; i < argc; ++i) {
    carg[i-1] = argv[i];
  }
  carg[i-1] = 0;
  status = posix_spawn(&pid, carg[0], NULL, &attr, carg, NULL);
  printf("XcalLauncher: child pid=%d\n", pid);
  
  // try task_for_pid
  mach_port_t task = 0;
  mach_error_t err = task_for_pid(mach_task_self(), pid, &task);
  if (err == 5)
    printf("XcalLauncher: could not access task for pid %d.\n", pid);
  
  Injector inj;
  inj.inject(pid, path);

  // continue run child process
  //kill(pid, SIGCONT);

  // wait child process terminates
  if (waitpid(pid, &status, 0) != -1)
    printf("XcalLauncher: sub process exited with code=%d\n", status);
  else
    perror("XcalLauncher: waitpid ");
 
  return 0;
}
