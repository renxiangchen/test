/*
 *  Copyright (C) 2019-2020 XC5 Hong Kong Limited, Inc. All Rights Reserved.
 */

#include <cstdio>
#include <unistd.h>
#include <sys/wait.h>
#include <spawn.h>
#include <string.h>

int pid;

void test_func() {
  printf("TestApp: test_func\n");
}

void dump_arg(int argc, char* argv[]) {
  printf("TestApp[%.4d] Run cmd:", pid);
  int i;
  for (i = 0; i < argc; ++i) {
    printf(" %s", argv[i]);
  }
  printf("\n");
}

void do_fork_exec(char* program) {
  char* argv[5];
  argv[0] = program;
  argv[4] = NULL;
  argv[1] = (char*)"posix";
  argv[2] = (char*)"posix-param-1";
  argv[3] = (char*)"posix-param-2";
  dump_arg(4, argv);
  pid_t cpid = fork();
  if (cpid == -1) {
    perror("fork");
  }
  else if (cpid == 0) {
    cpid = getpid();
    printf("TestApp[%.4d] In child: process pid=%d\n", pid, cpid);
    if (execvp(argv[0], argv) == -1)
      perror("execvp");
  }
  else {
    printf("TestApp[%.4d] In parent: child process pid=%d\n", pid, cpid);
    int status;
    if (waitpid(cpid, &status, NULL) != -1)
      printf("TestApp[%.4d] Child %d exited with status %d.\n", pid, cpid, status);
    else
      perror("waitpid");
  }
}

void do_posix_spawn(char* program) {
  char* argv[5];
  argv[0] = program;
  argv[4] = NULL;
  argv[1] = (char*)"fork";
  argv[2] = (char*)"fork-param-1";
  argv[3] = (char*)"fork-param-2";
  pid_t cpid = 0;
  dump_arg(4, argv);
  int status = posix_spawn(&cpid, argv[0], NULL, NULL, argv, NULL);
  if (status == 0) {
    printf("TestApp[%.4d] Created child process pid=%d\n", pid, cpid);
    if (waitpid(cpid, &status, NULL) != -1)
      printf("TestApp[%.4d] Child %d exited with status %d.\n", pid, cpid, status);
    else
      perror("waitpid");
  }
  else
    perror("posix_spawn");
}

void run_main(char* program) {
  do_posix_spawn(program);
  do_fork_exec(program);
}

void run_fork(int argc, char* argv[]) {
  dump_arg(argc, argv);
}

void run_posix(int argc, char* argv[]) {
  dump_arg(argc, argv);
}

int main(int argc, char* argv[])
{
    pid = getpid();
    printf("TestApp[%.4d] sleep 10s\n", pid);
    test_func();
    sleep(10);
    if (argc == 1) {
      printf("TestApp[%.4d] started without arguments\n", pid);
      run_main(argv[0]);
    }
    else if (strcmp(argv[1], "fork") == 0) {
      printf("TestApp[%.4d] creates child process with fork(%s).\n", pid, argv[1]);
      run_fork(argc, argv);
    }
    else if (strcmp(argv[1], "posix") == 0) {
      printf("TestApp[%.4d] creates child process with posix_spawn(%s).\n", pid, argv[1]);
      run_posix(argc, argv);
    }
    else {
      dump_arg(argc, argv);
      printf("TestApp[%.4d] unknown arg[1]: %s. Quit...\n", pid, argv[1]);
    }
    test_func();
    return 0;
}
