README
========

distorm is taken from distrom. this is used by funchook
https://github.com/gdabah/distorm/

BSD-3 license. no change on source code.
