/*
 *  Copyright (C) 2019-2020 XC5 Hong Kong Limited, Inc. All Rights Reserved.
 */

#include <stdio.h>
#include <assert.h>
#include <dlfcn.h>
#include <spawn.h>
#include <unistd.h>

extern "C" {
#include "funchook.h"
}

// execvp()
typedef void (*execvp_type)(const char *, const char **);
execvp_type execvp_func = 0;

// posix_spawn()
typedef int  (*posix_spawn_type)(pid_t *, const char *,
                                      const posix_spawn_file_actions_t *,
                                      const posix_spawnattr_t *,
                                      const char **, const char **);
posix_spawn_type posix_spawn_func = 0;

// dump argv
void dump_argv(const char **argv)
{
  const char **p = argv;
  while ((*p++) != 0)
    printf(" %s", *p);
  printf("\n");
}

// execvp wrapper
void my_execvp_func(const char * file, const char ** argv)
{
  printf("XcalHelper: my_execvp_func with %s arg:", file);
  dump_argv(argv);
  (*execvp_func)(file, argv);
}

// posix_spawn wrapper
void my_posix_spawn_func(pid_t * pid, const char * file, const posix_spawn_file_actions_t * actions,
                         const posix_spawnattr_t *attr, const char ** argv, const char ** env)
{
  printf("XcalHelper: my_posix_spawn_func with %s arg:", file);
  dump_argv(argv);
  (*posix_spawn_func)(pid, file, actions, attr, argv, env);
}

// global funchook object
static funchook_t *funchook;

// initializer
void install(void) __attribute__ ((constructor));
void install()
{
  printf("XcalHelper: install\n");

  funchook = funchook_create();
  assert (funchook != 0);

  execvp_func = (execvp_type)execvp;
  posix_spawn_func = (posix_spawn_type)posix_spawn;    

  printf("XcalHelper: execvp           = 0x%lx\n", (long)execvp);
  printf("XcalHelper: execvp_func      = 0x%lx\n", (long)execvp_func);
  printf("XcalHelper: posix_spawn      = 0x%lx\n", (long)posix_spawn);
  printf("XcalHelper: posix_spawn_func = 0x%lx\n", (long)posix_spawn_func);

  funchook_prepare(funchook, (void**)&execvp_func, (void*)my_execvp_func);
  funchook_prepare(funchook, (void**)&posix_spawn_func, (void*)my_posix_spawn_func);

  int r = funchook_install(funchook, 0);
  assert (r == 0);
}

// finalizer
void uninstall(void) __attribute__((destructor));
void uninstall()
{
  printf("XcalHelper: uninstall\n");

  if (funchook)
    funchook_destroy(funchook);
}

