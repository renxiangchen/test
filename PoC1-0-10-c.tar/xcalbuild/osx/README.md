# Xcalbuild/OSX

## Requirements

- Develop tools on OSX
- CMake
- Create a system certificate named 'gdb-cert' following steps on
  https://sourceware.org/gdb/wiki/PermissionsDarwin

  The cert name should be changed later and src/XCalLauncher/CMakeLists.txt codesign command should also be changed.

## Build and install

- cd build
- cmake ../src -DCMAKE_BUILD_TYPE=Debug|Release

## Run test

- cd bin
- ./XcalLauncher ./TestApp
  ...
  XcalHelper: my_posix_spawn_func with ./TestApp arg: fork fork-param-1 fork-param-2 (null)
  ...
  XcalHelper: my_execvp_func with ./TestApp arg: posix posix-param-1 posix-param-2 (null)
  ...

## Use

`python3 xcalbuild.py [options] <build-command>`

### options

- -i: directory of the source code
- -o: directory of the output
- -p: prebuild(?)command:
  - configure
  - cmake .
- build command:
  - aos make
  - make
  - scons
- -h: help

## Output

- preprocess.tar.gz
  - target1
    - preprocess
      - xxx.i
      - xxx.i
      - ...
    - xcalibyte.properties
  - target2
    - preprocess
      - xxx.i
      - xxx.i
      - ...
    - xcalibyte.properties
  - target...
  - xcalibyte.properties
  - checksum.sha1

- xcalbuild.log
