#!/bin/bash

INFO="[INFO]:"
WARN="[WARN]:"
ERROR="[ERROR]:"

AGENT_DIR=$(pwd)

find_py_ver(){
    USED_PY=$(which python)
    echo "${INFO} Verifying Python version..."
    PY_VERS=(python3.7 python3.6 python3.5 python3.4)
    for PY_VER in ${PY_VERS[@]}; do
      echo "${INFO} Checking ${PY_VER}..."
      which ${PY_VER} > /dev/null
      if [ $? = 0 ]; then
        echo "${INFO} Checking ${PY_VER}...found"
        echo "${INFO} Using ${PY_VER}"
        USED_PY=$(which ${PY_VER})
        break
      else
        echo "${INFO} Checking ${PY_VER}...not found"
      fi
    done

    if [ ! "${USED_PY}" ]; then
      echo "${WARN} Verifying Python version...failed"
      error_handling 1 "No python interpreter available"
    else
      if [ x"${USED_PY}" = x"$(which python)" ]; then
        printf "${ERROR} Please use at least python 3.4.0, current python version: "
        "${USED_PY}" -V
        error_handling 2 "Python version not compatible"
      fi
    fi
}

start() {
  if [ ! -z ${PYTHONPATH} ] ; then
      PYTHONPATH_EXTRA=":${PYTHONPATH}"
  fi
  export PYTHONPATH=${AGENT_DIR}/agent/commondef/src:${AGENT_DIR}/agent${PYTHONPATH_EXTRA}
  "${USED_PY}" "${AGENT_DIR}/agent/util/XcalAgentStart.py"
}

find_py_ver
start